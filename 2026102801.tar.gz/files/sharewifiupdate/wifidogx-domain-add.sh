#!/bin/sh
#==============================================================
# wifidogx-domain-add.sh
#
# 用途:
#   管理代理商白名单项, 支持批量新增与删除, 幂等且仅在确有变更时重启防火墙。
#   按类型自动分流:
#     - 域名 -> wifidogx.conf 的 config group 'sharewifi' 段 (list domain_name)
#     - IPv4 -> /sharewifiupdate/wifidog_update/iptable (aw-fw-setup.sh 会读入
#               set_wifidogx_inner_trust_domains 放行)
#
# 行为:
#   1. add 模式 (默认): 域名插在 sharewifi 段内最后一条 list domain_name 之后
#      (即 option g_desc 之前); IP 追加到 iptable; 已存在的项自动跳过。
#   2. del 模式 (-d): 仅删除 sharewifi 段内命中的 list domain_name 'x' 行, 以及
#      iptable 内命中的 IP; 其他内容保持不变; 不存在的项自动跳过。
#   3. 仅当文件确有变更且未指定 -N 时才重启防火墙。
#   4. 写入前自动备份为 <文件>.bak; 域名写回使用 cat 保留原属主与权限,
#      iptable 统一按 "每行一个 IP 后跟逗号" 规范化重写。
#
# 全部选项说明与实例:
#   -a              添加模式 (默认)。与 -d 互斥, 后出现者生效。
#                   例: wifidogx-domain-add.sh -a baidu.com
#   -d              删除模式。删除命中的白名单域名 / IP。
#                   例: wifidogx-domain-add.sh -d baidu.com
#   -c CONF         指定 wifidogx.conf 路径。
#                   (默认: /sharewifiupdate/wifidog_update/wifidogx.conf)
#                   例: wifidogx-domain-add.sh -c /tmp/wifidogx.conf -n baidu.com
#   -i IPT          指定 iptable 路径。
#                   (默认: /sharewifiupdate/wifidog_update/iptable)
#                   例: wifidogx-domain-add.sh -i /tmp/iptable 8.212.145.115
#   -s LIST         以分号/逗号/空格分隔的域名或 IP 列表。
#                   (与后台 whitelist_domain 字段同格式)
#                   例: wifidogx-domain-add.sh -s 'baidu.com;8.212.145.115'
#   -n              干跑 (dry-run): 只打印将要写入/删除的内容, 不改动文件。
#                   例: wifidogx-domain-add.sh -n -d baidu.com
#   -N              写入后不重启防火墙。
#                   例: wifidogx-domain-add.sh -N baidu.com
#   -q              安静模式: 仅输出错误信息。
#                   例: wifidogx-domain-add.sh -q baidu.com
#   -h              显示内置帮助并退出。
#                   例: wifidogx-domain-add.sh -h
#
# 常见组合实例:
#   # 1) 追加两个域名并重启防火墙
#   wifidogx-domain-add.sh baidu.com bilibili.com
#   # 2) 追加一个 IP (写入 iptable)
#   wifidogx-domain-add.sh 8.212.145.115
#   # 3) 按后台字段格式批量新增 (域名 + IP 混合)
#   wifidogx-domain-add.sh -s 'baidu.com;8.212.145.115'
#   # 4) 删除一个域名 / 一个 IP
#   wifidogx-domain-add.sh -d baidu.com
#   wifidogx-domain-add.sh -d 8.212.145.115
#   # 5) 干跑预览, 不改文件
#   wifidogx-domain-add.sh -n -c /tmp/wifidogx.conf -i /tmp/iptable baidu.com 8.212.145.115
#
# 依赖的外部命令:
#   getopts                      解析命令行选项
#   grep                         定位 config group 段 / 校验域名格式 / 判断 IP 是否已存在
#   awk                          按段读取与改写 wifidogx.conf / 重写 iptable
#   sed / tr                     归一化输入 (去空白 / 切分 iptable 分隔符)
#   cp                           写入前备份
#   cat                          覆盖写回, 保留原文件属主与权限
#   /etc/init.d/firewall restart 使白名单生效 (可用 -N 跳过)
#==============================================================

set -u

CONF_DEF='/sharewifiupdate/wifidog_update/wifidogx.conf'
IPTABLE_DEF='/sharewifiupdate/wifidog_update/iptable'
GROUP='sharewifi'

CONF="$CONF_DEF"
IPTABLE="$IPTABLE_DEF"
SEP_LIST=''
DO_RESTART=1
DRYRUN=0
QUIET=0
MODE='add'

log()  { [ "$QUIET" -eq 1 ] || printf '%s\n' "$*"; }
warn() { printf '[!] %s\n' "$*" >&2; }
err()  { printf '[-] %s\n' "$*" >&2; }

usage() {
        cat <<EOF
用法: $(basename "$0") [选项] <domain|ip> [domain|ip...]

管理代理商白名单: 域名写入 wifidogx.conf 的 config group '$GROUP' 段,
IPv4 写入 iptable。

选项:
  -a        添加模式 (默认)
  -d        删除模式
  -c CONF   wifidogx.conf 路径 (默认: $CONF_DEF)
  -i IPT    iptable 路径 (默认: $IPTABLE_DEF)
  -s LIST   域名/IP 列表, 以 ; , 空格 分隔 (与后台 whitelist_domain 字段同格式)
  -n        干跑, 只显示将要写入/删除的内容, 不改文件
  -N        写入后不重启防火墙
  -q        安静模式 (仅输出错误)
  -h        显示本帮助

示例:
  $(basename "$0") baidu.com bilibili.com
  $(basename "$0") 8.212.145.115
  $(basename "$0") -s 'baidu.com;8.212.145.115'
  $(basename "$0") -d baidu.com
  $(basename "$0") -d 8.212.145.115
  $(basename "$0") -n -c /tmp/wifidogx.conf -i /tmp/iptable baidu.com 8.212.145.115
EOF
        exit "${1:-0}"
}

# 域名合法性校验 (与后台写入 wifidogx.conf 的规则一致)
is_domain() {
        printf '%s' "$1" | grep -Eq '^[A-Za-z0-9*]([A-Za-z0-9*_-]*[A-Za-z0-9*])?(\.[A-Za-z0-9*]([A-Za-z0-9*_-]*[A-Za-z0-9*])?)*\.[A-Za-z]{2,}$'
}

# IPv4 合法性校验 (白名单中的 IP 写入 iptable)
is_ipv4() {
        case "$1" in
                ''|*[!0-9.]*) return 1 ;;
        esac
        printf '%s\n' "$1" | awk -F. '
                NF != 4 { exit 1 }
                { for (i = 1; i <= 4; i++) { if ($i == "" || $i > 255) exit 1 } }
        '
}

# 输出 iptable 内的所有 IP (按出现顺序去重, 每行一个, 无逗号)
iptable_ips() {
        [ -f "$IPTABLE" ] || return 0
        tr ',\r\n\t' '\n' < "$IPTABLE" \
                | sed 's/^[[:space:]]*//; s/[[:space:]]*$//' \
                | grep -v '^$' \
                | awk '!seen[$0]++'
}

# 判断 IP 是否已存在于 iptable
ip_exists_in_iptable() {
        iptable_ips | grep -Fxq -- "$1"
}

# 收集白名单项: 去首尾空白 / 去重, 按类型分别存入 DOMAINS / IPS
# (两者均为空格分隔, 两端各留一个空格便于匹配)
DOMAINS=' '
IPS=' '
collect_item() {
        d=$(printf '%s' "$1" | tr -d '\r\n' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')
        [ -z "$d" ] && return 0
        if is_ipv4 "$d"; then
                case "$IPS" in
                        *" $d "*) return 0 ;;
                esac
                IPS="$IPS$d "
                return 0
        fi
        if ! is_domain "$d"; then
                warn "忽略非法域名/IP: $d"
                return 0
        fi
        case "$DOMAINS" in
                *" $d "*) return 0 ;;
        esac
        DOMAINS="$DOMAINS$d "
        return 0
}

while getopts "adc:i:s:nNqh" opt; do
        case "$opt" in
                a) MODE='add' ;;
                d) MODE='del' ;;
                c) CONF="$OPTARG" ;;
                i) IPTABLE="$OPTARG" ;;
                s) SEP_LIST="$OPTARG" ;;
                n) DRYRUN=1 ;;
                N) DO_RESTART=0 ;;
                q) QUIET=1 ;;
                h) usage 0 ;;
                *) usage 1 ;;
        esac
done
shift $((OPTIND - 1))

for d in "$@"; do collect_item "$d"; done
if [ -n "$SEP_LIST" ]; then
        OLD_IFS="$IFS"
        IFS=';, '
        for d in $SEP_LIST; do collect_item "$d"; done
        IFS="$OLD_IFS"
fi

# ---- 域名部分: 计算待新增 / 删除的域名 ----
TARGET_LIST=''
TARGET_CNT=0
if [ "$DOMAINS" != ' ' ]; then
        [ -f "$CONF" ] || { err "配置文件不存在: $CONF"; exit 1; }
        if ! grep -Eq "^[[:space:]]*config[[:space:]]+group[[:space:]]+['\"]?$GROUP['\"]?[[:space:]]*$" "$CONF"; then
                err "未找到 config group '$GROUP' 段: $CONF"
                exit 1
        fi
        for d in $DOMAINS; do
                exists=0
                grep -qF "list domain_name '$d'" "$CONF" && exists=1
                if [ "$MODE" = 'add' ] && [ "$exists" -eq 1 ]; then
                        log "跳过 (已存在): $d"
                        continue
                fi
                if [ "$MODE" = 'del' ] && [ "$exists" -eq 0 ]; then
                        log "跳过 (不存在): $d"
                        continue
                fi
                TARGET_LIST="$TARGET_LIST$d
"
                TARGET_CNT=$((TARGET_CNT + 1))
        done
fi

# ---- IP 部分: 计算待新增 / 删除的 IP (写入 $IPTABLE) ----
TARGET_IPS=''
TARGET_IP_CNT=0
for ip in $IPS; do
        exists=0
        ip_exists_in_iptable "$ip" && exists=1
        if [ "$MODE" = 'add' ] && [ "$exists" -eq 1 ]; then
                log "跳过 (已存在): $ip"
                continue
        fi
        if [ "$MODE" = 'del' ] && [ "$exists" -eq 0 ]; then
                log "跳过 (不存在): $ip"
                continue
        fi
        TARGET_IPS="$TARGET_IPS$ip
"
        TARGET_IP_CNT=$((TARGET_IP_CNT + 1))
done

if [ "$TARGET_CNT" -eq 0 ] && [ "$TARGET_IP_CNT" -eq 0 ]; then
        if [ "$MODE" = 'add' ]; then
                log "没有新增项, 文件未修改"
        else
                log "没有可删除项, 文件未修改"
        fi
        exit 0
fi

if [ "$DRYRUN" -eq 1 ]; then
        if [ "$TARGET_CNT" -gt 0 ]; then
                if [ "$MODE" = 'add' ]; then
                        log "[干跑] 将向 $CONF 的 config group '$GROUP' 段新增 $TARGET_CNT 个域名:"
                else
                        log "[干跑] 将从 $CONF 的 config group '$GROUP' 段删除 $TARGET_CNT 个域名:"
                fi
                printf '%s\n' "$TARGET_LIST" | while read -r d; do
                        [ -n "$d" ] && printf "  \tlist domain_name '%s'\n" "$d"
                done
        fi
        if [ "$TARGET_IP_CNT" -gt 0 ]; then
                if [ "$MODE" = 'add' ]; then
                        log "[干跑] 将向 $IPTABLE 新增 $TARGET_IP_CNT 个 IP:"
                else
                        log "[干跑] 将从 $IPTABLE 删除 $TARGET_IP_CNT 个 IP:"
                fi
                printf '%s\n' "$TARGET_IPS" | while read -r ip; do
                        [ -n "$ip" ] && printf '  %s\n' "$ip"
                done
        fi
        exit 0
fi

CHANGED=0

# ---- 应用域名变更 (写入 wifidogx.conf) ----
if [ "$TARGET_CNT" -gt 0 ]; then
        BAK="$CONF.bak"
        TMP="$CONF.tmp.$$"
        cp -f "$CONF" "$BAK" || { err "备份失败: $BAK"; exit 1; }

        if [ "$MODE" = 'add' ]; then
                # 旧写法: 脚本仅支持新增白名单域名
                # 新写法: 保留新增逻辑不变, 并通过 -d 支持删除
                awk -v grp="$GROUP" -v list="$TARGET_LIST" '
function flush(   i, j, n, last, indent, arr) {
        if (cnt == 0) { return }
        last = 1
        for (i = 1; i <= cnt; i++) {
                if (buf[i] ~ /^[[:space:]]*list[[:space:]]+domain_name[[:space:]]/) { last = i }
        }
        indent = "\t"
        if (buf[last] ~ /^[[:space:]]*list[[:space:]]/) {
                match(buf[last], /^[[:space:]]*/)
                indent = substr(buf[last], 1, RLENGTH)
        }
        for (i = 1; i <= cnt; i++) {
                print buf[i]
                if (i == last) {
                        n = split(list, arr, "\n")
                        for (j = 1; j <= n; j++) {
                                if (arr[j] != "") { print indent "list domain_name \047" arr[j] "\047" }
                        }
                }
        }
        cnt = 0
}
{
        line = $0
        if (line ~ /^[[:space:]]*config[[:space:]]+/) {
                if (in_sec) { flush(); in_sec = 0 }
                if (line ~ /^[[:space:]]*config[[:space:]]+group[[:space:]]/ && index(line, grp) > 0) { in_sec = 1 }
        }
        if (in_sec) { cnt++; buf[cnt] = line } else { print line }
}
END { if (in_sec) { flush() } }
' "$CONF" > "$TMP" || { err "处理失败, 文件未修改"; rm -f "$TMP"; exit 1; }
        else
                awk -v grp="$GROUP" -v list="$TARGET_LIST" '
BEGIN {
        n = split(list, arr, "\n")
        for (i = 1; i <= n; i++) {
                if (arr[i] != "") { remove[arr[i]] = 1 }
        }
}
function trim_domain(s) {
        gsub(/^[[:space:]]+/, "", s)
        gsub(/[[:space:]]+$/, "", s)
        gsub(/^\047/, "", s)
        gsub(/\047$/, "", s)
        return s
}
function flush(   i, tmp) {
        if (cnt == 0) { return }
        for (i = 1; i <= cnt; i++) {
                tmp = buf[i]
                if (tmp ~ /^[[:space:]]*list[[:space:]]+domain_name[[:space:]]+/) {
                        sub(/^[[:space:]]*list[[:space:]]+domain_name[[:space:]]+/, "", tmp)
                        tmp = trim_domain(tmp)
                        if (tmp in remove) { continue }
                }
                print buf[i]
        }
        cnt = 0
}
{
        line = $0
        if (line ~ /^[[:space:]]*config[[:space:]]+/) {
                if (in_sec) { flush(); in_sec = 0 }
                if (line ~ /^[[:space:]]*config[[:space:]]+group[[:space:]]/ && index(line, grp) > 0) { in_sec = 1 }
        }
        if (in_sec) { cnt++; buf[cnt] = line } else { print line }
}
END { if (in_sec) { flush() } }
' "$CONF" > "$TMP" || { err "处理失败, 文件未修改"; rm -f "$TMP"; exit 1; }
        fi

        # 用 cat 覆盖写回, 保持原文件属主与权限不变
        cat "$TMP" > "$CONF" || { err "写入失败: $CONF"; rm -f "$TMP"; exit 1; }
        rm -f "$TMP"
        CHANGED=1
fi

# ---- 应用 IP 变更 (写入 iptable, 统一规范化为每行一个 "IP,") ----
if [ "$TARGET_IP_CNT" -gt 0 ]; then
        IPBAK="$IPTABLE.bak"
        IPTMP="$IPTABLE.tmp.$$"
        if [ -f "$IPTABLE" ]; then
                cp -f "$IPTABLE" "$IPBAK" || { err "备份失败: $IPBAK"; exit 1; }
        fi
        if [ "$MODE" = 'add' ]; then
                { iptable_ips; printf '%s\n' "$TARGET_IPS"; } \
                        | awk 'NF && !seen[$0]++' | sed 's/$/,/' > "$IPTMP" \
                        || { err "处理失败, 文件未修改"; rm -f "$IPTMP"; exit 1; }
        else
                iptable_ips | awk -v list="$TARGET_IPS" '
                        BEGIN { n = split(list, a, "\n"); for (i = 1; i <= n; i++) { if (a[i] != "") rm[a[i]] = 1 } }
                        { if (!($0 in rm)) print $0 }
                ' | sed 's/$/,/' > "$IPTMP" \
                        || { err "处理失败, 文件未修改"; rm -f "$IPTMP"; exit 1; }
        fi
        cat "$IPTMP" > "$IPTABLE" || { err "写入失败: $IPTABLE"; rm -f "$IPTMP"; exit 1; }
        rm -f "$IPTMP"
        CHANGED=1
fi

if [ "$CHANGED" -eq 1 ] && [ "$DO_RESTART" -eq 1 ]; then
        if [ -x /etc/init.d/firewall ]; then
                log "重启防火墙使白名单生效..."
                /etc/init.d/firewall restart
        else
                warn "未找到 /etc/init.d/firewall, 请手动重启防火墙"
        fi
fi

if [ "$MODE" = 'add' ]; then
        log "完成: 新增域名 $TARGET_CNT 个, 新增 IP $TARGET_IP_CNT 个"
else
        log "完成: 删除域名 $TARGET_CNT 个, 删除 IP $TARGET_IP_CNT 个"
fi

# aw-fw-setup.sh 在存在 /etc/config/wifidogx 时优先读它, 此时写本文件不会生效
if [ "$TARGET_CNT" -gt 0 ] && [ -f /etc/config/wifidogx ]; then
        warn "检测到 /etc/config/wifidogx 存在, 固件可能优先读取该文件, 本次写入可能不生效"
fi

exit 0
