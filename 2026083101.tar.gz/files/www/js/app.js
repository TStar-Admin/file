(function(){
'use strict';

var API = '/cgi-bin/api';
var token = localStorage.getItem('token');

function $(sel){ return document.querySelector(sel); }
function $$(sel){ return document.querySelectorAll(sel); }
function escapeHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }

function ensureApp(){
  var app = $('#app');
  if(!app){
    app = document.createElement('div');
    app.id = 'app';
    document.body.appendChild(app);
  }
  return app;
}

function toast(msg, type){
  type = type || 'info';
  var el = document.createElement('div');
  el.className = 'toast ' + type;
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(function(){ el.remove(); }, 3000);
}

function api(method, params, cb){
  params = params || {};
  if(token) params.token = token;
  var xhr = new XMLHttpRequest();
  xhr.open('POST', API, true);
  xhr.setRequestHeader('Content-Type', 'application/json');
  xhr.onreadystatechange = function(){
    if(xhr.readyState !== 4) return;
    try {
      var res = JSON.parse(xhr.responseText);
      if(res.status === 'error'){
        if(res.code === 401){ logout(); }
        toast(res.message, 'error');
        if(cb) cb(null);
      } else {
        if(cb) cb(res);
      }
    } catch(e){
      toast('Request failed: ' + e.message, 'error');
      if(cb) cb(null);
    }
  };
  xhr.onerror = function(){
    toast('Network error', 'error');
    if(cb) cb(null);
  };
  xhr.send(JSON.stringify({ method: method, params: params }));
}

function renderLogin(){
  var app = ensureApp();
  app.innerHTML =
    '<div class="app">' +
    '<div class="header"><h2>ShareWiFi</h2></div>' +
    '<div id="loginStatus"></div>' +
    '<div class="login-card">' +
    '<h1>Login</h1>' +
    '<div class="form-group"><label>Password</label>' +
    '<input type="password" id="loginPwd" placeholder="Enter router password"></div>' +
    '<button class="btn btn-primary" id="loginBtn">Login</button>' +
    '<p style="margin-top:16px;font-size:.8rem;color:#6b7280;text-align:center">Default password is empty</p>' +
    '<div class="login-help">' +
    '<p>Default password is : empty ; if not accepted, check your ShareWiFi management APP to get the updated password.</p>' +
    '<p>If you were automatically redirected to this page, it means your billing router\'s WAN connection has encountered a problem. Please check the network cable or whether your ISP has blocked your router.</p>' +
    '<p>You can still try using WWAN to wirelessly connect your billing router to your ISP modem and continue operating your ShareWiFi. This is an advanced feature exclusive to ShareWiFi.</p>' +
    '<p>Kung awtomatiko kang na-redirect sa page na ito, nangangahulugan itong may problema ang WAN connection ng iyong billing router. Pakisuri ang iyong network cable o kung na-block ng iyong ISP ang iyong router. Maaari mo pa ring subukang gamitin ang WWAN upang ikonekta nang wireless ang iyong billing router sa ISP modem at ipagpatuloy ang operasyon ng iyong ShareWiFi. Ito ay isang advanced na tampok na eksklusibo lamang sa ShareWiFi.</p>' +
    '</div>' +
    '</div></div>';
  $('#loginBtn').onclick = doLogin;
  $('#loginPwd').onkeydown = function(e){ if(e.key==='Enter') doLogin(); };
  $('#loginPwd').focus();
  loadLoginStatus();
}

function loadLoginStatus(){
  var xhr = new XMLHttpRequest();
  xhr.open('POST', API, true);
  xhr.setRequestHeader('Content-Type', 'application/json');
  xhr.onreadystatechange = function(){
    if(xhr.readyState !== 4) return;
    try {
      var res = JSON.parse(xhr.responseText);
      if(res.status === 'ok' && res.interfaces){
        var el = $('#loginStatus');
        if(!el) return;
        var html = '<div class="card"><h3>Network Status</h3><ul class="status-list">';
        res.interfaces.forEach(function(iface){
          html += '<li class="status-item"><span><span class="status-dot '+(iface.up?'up':'down')+'"></span>'+iface.name.toUpperCase()+'</span>';
          html += '<span>'+(iface.up?(iface.ip||'Connected'):'Disconnected')+'</span></li>';
        });
        html += '</ul></div>';
        el.innerHTML = html;
      }
    } catch(e){}
  };
  xhr.send(JSON.stringify({method:'network_status', params:{}}));
}

function doLogin(){
  var pwd = $('#loginPwd').value;
  api('login', { username: 'root', password: pwd }, function(res){
    if(res && res.token){
      token = res.token;
      localStorage.setItem('token', token);
      renderApp();
    }
  });
}

function logout(){
  token = null;
  localStorage.removeItem('token');
  renderLogin();
}

function renderApp(){
  var app = ensureApp();
  app.innerHTML =
    '<div class="app">' +
    '<div class="header"><h2>ShareWiFi</h2><button class="logout" id="logoutBtn">Logout</button></div>' +
    '<div id="statusArea"></div>' +
    '<div id="wiredSection"></div>' +
    '<div id="wirelessSection"></div>' +
    '</div>';
  $('#logoutBtn').onclick = logout;
  loadStatus();
  renderWired();
  renderWireless();
}

function loadStatus(){
  api('network_status', {}, function(res){
    if(!res) return;
    var el = $('#statusArea');
    if(!el) return;
    var html = '<div class="card"><h3>Network Status</h3><ul class="status-list">';
    res.interfaces.forEach(function(iface){
      html += '<li class="status-item"><span><span class="status-dot '+(iface.up?'up':'down')+'"></span>'+iface.name.toUpperCase()+'</span>';
      html += '<span>'+(iface.up?(iface.ip||'Connected'):'Disconnected')+'</span></li>';
    });
    html += '</ul></div>';
    el.innerHTML = html;
  });
}

function renderWired(){
  var el = $('#wiredSection');
  if(!el) return;
  el.innerHTML =
    '<div class="card">' +
    '<h3>Wired WAN <span class="section-tag primary">Primary</span></h3>' +
    '<div class="form-group"><label>Protocol</label>' +
    '<select id="wiredProto">' +
    '<option value="dhcp">Auto IP (DHCP)</option>' +
    '<option value="static">Static IP</option>' +
    '<option value="pppoe">PPPoE</option>' +
    '</select></div>' +
    '<div id="wiredFields"></div>' +
    '<button class="btn btn-primary" id="wiredSave">Apply</button>' +
    '</div>';
  $('#wiredProto').onchange = renderWiredFields;
  $('#wiredSave').onclick = saveWired;
  renderWiredFields();
  loadWiredStatus();
}

function renderWiredFields(){
  var proto = $('#wiredProto').value;
  var el = $('#wiredFields');
  if(!el) return;
  if(proto === 'dhcp'){
    el.innerHTML =
      '<div class="form-group"><label>WAN MAC</label><div class="input-row"><input type="text" id="wiredMac" placeholder="AA:BB:CC:DD:EE:FF"><button type="button" class="btn btn-sm btn-inline" id="wiredRandom">Random</button></div></div>' +
      '<div class="form-group"><label>Hostname</label><input type="text" id="wiredHostname" placeholder="Device hostname"></div>' +
      '<div class="form-group"><label>DHCP Option 60</label><select id="wiredVendor">' +
      '<option value="">iOS (no Option 60)</option>' +
      '<option value="android-dhcp-14">Android 14</option>' +
      '<option value="android-dhcp-13">Android 13</option>' +
      '<option value="MSFT 5.0">Windows</option>' +
      '<option value="">OpenWrt default</option>' +
      '</select></div>';
    $('#wiredRandom').onclick = randomizeAll;
  } else if(proto === 'pppoe'){
    el.innerHTML =
      '<div class="form-group"><label>Username</label><input type="text" id="pppoeUser" placeholder="PPPoE username"></div>' +
      '<div class="form-group"><label>Password</label><input type="password" id="pppoePwd" placeholder="PPPoE password"></div>' +
      '<div class="form-group"><label>Service Name (optional)</label><input type="text" id="pppoeService" placeholder="ISP service name"></div>' +
      '<div class="form-group"><label>MTU (optional)</label><input type="text" id="pppoeMtu" placeholder="1492"></div>';
  } else {
    el.innerHTML =
      '<div class="form-group"><label>IP Address</label><input type="text" id="staticIp" placeholder="192.168.1.100"></div>' +
      '<div class="form-group"><label>Netmask</label><input type="text" id="staticMask" placeholder="255.255.255.0"></div>' +
      '<div class="form-group"><label>Gateway</label><input type="text" id="staticGw" placeholder="192.168.1.1"></div>' +
      '<div class="form-group"><label>DNS Server</label><input type="text" id="staticDns" placeholder="8.8.8.8"></div>' +
      '<div class="form-group"><label>WAN MAC</label><input type="text" id="wiredMac" placeholder="AA:BB:CC:DD:EE:FF"></div>';
  }
}

function loadWiredStatus(){
  api('dhcp_status', {}, function(dhcp){
    api('pppoe_status', {}, function(pppoe){
      var proto = 'dhcp';
      if(pppoe && pppoe.proto === 'pppoe') proto = 'pppoe';
      else if(dhcp && dhcp.proto === 'static') proto = 'static';
      $('#wiredProto').value = proto;
      renderWiredFields();
      if(proto === 'dhcp' && dhcp){
        if($('#wiredMac')) $('#wiredMac').value = dhcp.mac || '';
        if($('#wiredHostname')) $('#wiredHostname').value = dhcp.hostname || '';
        if($('#wiredVendor')) $('#wiredVendor').value = dhcp.vendorid || '';
      } else if(proto === 'pppoe' && pppoe){
        if($('#pppoeUser')) $('#pppoeUser').value = pppoe.username || '';
        if($('#pppoePwd')) $('#pppoePwd').value = pppoe.password || '';
      }
    });
  });
}

function saveWired(){
  var proto = $('#wiredProto').value;
  if(!confirm('Network will restart. Continue?')) return;
  if(proto === 'dhcp'){
    api('dhcp_config', {
      mac: $('#wiredMac') ? $('#wiredMac').value : '',
      hostname: $('#wiredHostname') ? $('#wiredHostname').value : '',
      vendorid: $('#wiredVendor') ? $('#wiredVendor').value : ''
    }, function(res){ if(res) toast('DHCP applied. Restarting...', 'success'); });
  } else if(proto === 'pppoe'){
    api('pppoe_config', {
      username: $('#pppoeUser') ? $('#pppoeUser').value : '',
      password: $('#pppoePwd') ? $('#pppoePwd').value : '',
      mtu: $('#pppoeMtu') ? $('#pppoeMtu').value : '',
      server: $('#pppoeService') ? $('#pppoeService').value : ''
    }, function(res){ if(res) toast('PPPoE applied. Restarting...', 'success'); });
  } else {
    api('static_config', {
      ip: $('#staticIp') ? $('#staticIp').value : '',
      netmask: $('#staticMask') ? $('#staticMask').value : '',
      gateway: $('#staticGw') ? $('#staticGw').value : '',
      dns: $('#staticDns') ? $('#staticDns').value : '',
      mac: $('#wiredMac') ? $('#wiredMac').value : ''
    }, function(res){ if(res) toast('Static IP applied. Restarting...', 'success'); });
  }
}

function randomizeAll(){
  var mac = '02';
  for(var i=0;i<5;i++) mac += ':' + ('0'+Math.floor(Math.random()*256).toString(16).toUpperCase()).slice(-2);
  var brands = ['Lenovo','ASUS','DELL','HP','Acer','MSI','Gigabyte','Intel'];
  var models = ['Desktop','PC','Workstation','Tower','Station','Pro','Elite','Ultra'];
  var hostname = brands[Math.floor(Math.random()*brands.length)] + '-' + models[Math.floor(Math.random()*models.length)];
  var vendor = 'MSFT 5.0';
  if($('#wiredMac')) $('#wiredMac').value = mac;
  if($('#wiredHostname')) $('#wiredHostname').value = hostname;
  if($('#wiredVendor')) $('#wiredVendor').value = vendor;
  toast('Randomized', 'success');
}

function renderWireless(){
  var el = $('#wirelessSection');
  if(!el) return;
  el.innerHTML =
    '<div class="card"><h3>Wireless WAN <span class="section-tag backup">Backup</span></h3>' +
    '<div class="form-group"><label>Select Network</label>' +
    '<div class="scan-row">' +
    '<select id="wwanSelect"><option value="">-- Select Network --</option></select>' +
    '<button type="button" class="btn btn-sm btn-scan" id="wwanScanBtn">Scan</button>' +
    '</div>' +
    '<div class="scan-info" id="scanInfo"></div></div>' +
    '<div class="form-group"><label>Password</label><input type="password" id="wwanPwd" placeholder="WiFi password"></div>' +
    '<div class="form-group"><label>Hostname</label><div class="input-row"><input type="text" id="wwanHostname" placeholder="Device hostname"><button type="button" class="btn btn-sm btn-inline" id="wwanRandom">Random</button></div></div>' +
    '<div class="form-group"><label>DHCP Option 60</label><select id="wwanVendor">' +
    '<option value="">iOS (no Option 60)</option>' +
    '<option value="android-dhcp-14">Android 14</option>' +
    '<option value="android-dhcp-13">Android 13</option>' +
    '<option value="MSFT 5.0">Windows</option>' +
    '<option value="">OpenWrt default</option>' +
    '</select></div>' +
    '<button class="btn btn-primary" id="wwanSave">Apply</button></div>';
  $('#wwanScanBtn').onclick = doWifiScan;
  $('#wwanRandom').onclick = randomizeWWAN;
  $('#wwanSave').onclick = saveWWAN;
  loadCachedScan();
  loadWWANStatus();
  // 刷新页面时若连接进行中，恢复 "Connecting…" 态并继续轮询
  api('wifi_connect_status', {}, function(r){
    if(r && r.state === 'pending'){
      setConnecting(true, 'Connecting to ' + (r.ssid || 'WWAN') + '…');
      pollWifiConnectStatus();
    }
  });
}

function randomizeWWAN(){
  var isAndroid = Math.random() < 0.5;
  var hostname, vendor;
  if(isAndroid){
    var brands = ['Xiaomi','OPPO','vivo','HUAWEI','Samsung','OnePlus','Realme','Redmi'];
    var models = ['Galaxy','Note','Pro','Plus','Ultra','Lite','Max','Mini'];
    hostname = brands[Math.floor(Math.random()*brands.length)] + '-' + models[Math.floor(Math.random()*models.length)];
    var dhcpOptions = ['android-dhcp-14','android-dhcp-13'];
    vendor = dhcpOptions[Math.floor(Math.random()*dhcpOptions.length)];
  } else {
    var iosModels = ['iPhone','iPad'];
    var iosVersions = ['15','16','17','18'];
    hostname = iosModels[Math.floor(Math.random()*iosModels.length)] + ' ' + iosVersions[Math.floor(Math.random()*iosVersions.length)];
    vendor = '';
  }
  if($('#wwanHostname')) $('#wwanHostname').value = hostname;
  var sel = $('#wwanVendor');
  if(sel){
    if(vendor === ''){
      sel.selectedIndex = 0;
    } else {
      sel.value = vendor;
    }
  }
  toast('Randomized', 'success');
}

function formatTimeAgo(ts){
  if(!ts) return '';
  var diff = Math.floor(Date.now()/1000) - ts;
  if(diff < 5) return 'Just now';
  if(diff < 60) return diff + 's ago';
  return Math.floor(diff/60) + 'm ago';
}

function updateScanInfo(ts, connectedSsid){
  var el = $('#scanInfo');
  if(!el) return;
  var parts = [];
  if(ts) parts.push('<span class="scan-ts">Scanned ' + formatTimeAgo(ts) + '</span>');
  if(connectedSsid) parts.push('<span class="scan-connected">Connected: ' + escapeHtml(connectedSsid) + '</span>');
  el.innerHTML = parts.join(' &middot; ');
}

function doWifiScan(){
  var btn = $('#wwanScanBtn');
  var sel = $('#wwanSelect');
  if(!btn || btn.disabled) return;

  btn.disabled = true;
  btn.textContent = 'Scanning...';
  btn.classList.add('btn-scanning');
  var info = $('#scanInfo');

  var allNetworks = [];

  function renderResults(){
    if(allNetworks.length === 0){
      if(info) info.innerHTML = '<span class="scan-ts text-danger">No networks found. Try again.</span>';
      btn.disabled = false;
      btn.textContent = 'Scan';
      btn.classList.remove('btn-scanning');
      return;
    }
    allNetworks.sort(function(a, b){ return b.signal - a.signal; });
    var html = '<option value="">-- Select Network --</option>';
    allNetworks.forEach(function(n, i){
      html += '<option value="'+i+'" data-ssid="'+escapeHtml(n.ssid)+'" data-enc="'+escapeHtml(n.encryption)+'" data-radio="'+escapeHtml(n.radio)+'">' +
        '[' + escapeHtml(n.radioLabel) + '] ' + escapeHtml(n.ssid) + ' (' + n.signal + 'dBm)' +
        '</option>';
    });
    sel.innerHTML = html;

    var now = Math.floor(Date.now()/1000);
    window._scanTimestamp = now;
    window._scanNetworks = allNetworks;
    updateScanInfo(now, window._connectedSsid);

    btn.disabled = false;
    btn.textContent = 'Scan';
    btn.classList.remove('btn-scanning');
  }

  if(info) info.innerHTML = '<span class="scan-ts scanning-msg">Scanning 2.4G...</span>';

  api('wifi_scan', { radio: 'radio0', force: true }, function(res){
    if(res && res.networks && !res.busy){
      res.networks.forEach(function(n){ n.radio = 'radio0'; n.radioLabel = '2.4G'; allNetworks.push(n); });
    }

    if(info) info.innerHTML = '<span class="scan-ts scanning-msg">Scanning 5G...</span>';

    api('wifi_scan', { radio: 'radio1', force: true }, function(res){
      if(res && res.networks && !res.busy){
        res.networks.forEach(function(n){ n.radio = 'radio1'; n.radioLabel = '5G'; allNetworks.push(n); });
      }
      renderResults();
    });
  });
}

function loadCachedScan(){
  api('wifi_scan_cached', {}, function(res){
    if(!res) return;
    var sel = $('#wwanSelect');
    if(!sel) return;

    var networks = res.networks || [];
    var html = '<option value="">-- Select Network --</option>';
    networks.forEach(function(n, i){
      html += '<option value="'+i+'" data-ssid="'+escapeHtml(n.ssid)+'" data-enc="'+escapeHtml(n.encryption)+'" data-radio="'+escapeHtml(n.radio)+'">' +
        '[' + escapeHtml(n.radioLabel) + '] ' + escapeHtml(n.ssid) + ' (' + n.signal + 'dBm)' +
        '</option>';
    });
    sel.innerHTML = html;

    window._scanTimestamp = res.timestamp || 0;
    window._scanNetworks = networks;
    updateScanInfo(res.timestamp, window._connectedSsid);

    if(res.scanning){
      var btn = $('#wwanScanBtn');
      if(btn){
        btn.disabled = true;
        btn.textContent = 'Scanning...';
        btn.classList.add('btn-scanning');
      }
    }
  });
}

function loadWWANStatus(){
  api('wwan_status', {}, function(res){
    if(!res) return;
    if($('#wwanHostname')) $('#wwanHostname').value = res.hostname || '';
    if($('#wwanVendor')) $('#wwanVendor').value = res.vendorid || '';
    window._connectedSsid = res.ssid || '';
    updateScanInfo(window._scanTimestamp, window._connectedSsid);

    if(res.ssid && window._scanNetworks && window._scanNetworks.length > 0){
      var sel = $('#wwanSelect');
      if(!sel) return;
      for(var i = 0; i < window._scanNetworks.length; i++){
        if(window._scanNetworks[i].ssid === res.ssid){
          sel.selectedIndex = i + 1;
          break;
        }
      }
    }
  });
}

function setConnecting(on, label){
  var b = $('#wwanSave');
  if(!b) return;
  if(on){
    b.disabled = true;
    b.classList.add('btn-scanning');
    b.textContent = label || 'Connecting…';
  } else {
    b.disabled = false;
    b.classList.remove('btn-scanning');
    b.textContent = 'Apply';
  }
}

var _connectPollTimer = null;
function pollWifiConnectStatus(){
  if(_connectPollTimer) clearInterval(_connectPollTimer);
  _connectPollTimer = setInterval(function(){
    api('wifi_connect_status', {}, function(res){
      if(!res || res.state === 'idle' || res.state === 'pending') return;
      clearInterval(_connectPollTimer); _connectPollTimer = null;
      setConnecting(false);
      if(res.state === 'success'){
        toast('Connected to ' + (res.ssid || 'WWAN'), 'success');
        loadWWANStatus();
        loadCachedScan();
      } else {
        var msg = res.message || 'Connection failed. Please retry.';
        if(res.reason === 'signal') msg = 'Network out of range or signal too weak. Try the other radio.';
        toast(msg, 'error');
        loadCachedScan();
      }
    });
  }, 2500);
}

function saveWWAN(){
  var sel = $('#wwanSelect');
  var hasNetwork = sel && sel.value;
  var hostname = $('#wwanHostname').value;
  var vendorid = $('#wwanVendor').value;
  if(hasNetwork){
    var opt = sel.options[sel.selectedIndex];
    var ssid = opt.dataset.ssid;
    var enc = opt.dataset.enc;
    var radio = opt.dataset.radio;
    if(enc !== 'none' && !$('#wwanPwd').value){
      toast('Password required', 'error'); return;
    }
    if(enc === 'none'){
      if(!confirm('This is an unsecured network. Anyone in range can see your traffic. Make sure you trust this network, and do NOT connect to a ShareWiFi portal SSID or this router will lose internet access. Continue?')) return;
    }
    setConnecting(true, 'Connecting to ' + ssid + '…');
    api('wifi_connect', {
      ssid: ssid,
      password: $('#wwanPwd').value,
      radio: radio,
      encryption: enc,
      hostname: hostname,
      vendorid: vendorid
    }, function(res){
      if(res && res.status === 'ok'){
        toast('Connecting…', 'info');
        pollWifiConnectStatus();
      } else {
        setConnecting(false);
      }
    });
  } else {
    api('wwan_config', {
      hostname: hostname,
      vendorid: vendorid
    }, function(res){
      if(res) toast('WWAN applied. Restarting...', 'success');
    });
  }
}

function init(){
  ensureApp();
  if(token){
    api('dhcp_status', {}, function(res){
      if(res && res.status === 'ok') renderApp();
      else { token = null; localStorage.removeItem('token'); renderLogin(); }
    });
  } else {
    renderLogin();
  }
}

if(document.readyState === 'loading'){
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
})();
