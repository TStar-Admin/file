#!/bin/sh
#==============================================================
# wifidogx-trust-add.sh
# 批量放行 wifidogx 信任客户端: 把多个 MAC 一次性加入
# nft set "set_wifidogx_trust_clients_out" (table inet fw4)
#
# 规则: ether saddr @set_wifidogx_trust_clients_out accept
#       源 MAC 命中该 set 即放行, 无需 wifidogx 认证
#
# 支持逐元素 timeout:
#   -t 指定默认 timeout (不带 = 的 MAC 用它)
#   任意 MAC 可用 MAC=timeout 单独指定该 MAC 的放行时长
#
# 用法:
#   wifidogx-trust-add.sh [-t 默认超时] <mac1>[=t1] [mac2][=t2] ...
#   wifidogx-trust-add.sh [-t 默认超时] -f <文件|->   # 每行: MAC 或 MAC=timeout
#
# 示例:
#   wifidogx-trust-add.sh 16:72:c2:1a:aa:7d 20:e7:c8:15:26:5c
#   wifidogx-trust-add.sh -t 7d 16:72:c2:1a:aa:7d
#   wifidogx-trust-add.sh 02:00:00:00:00:01=1h 02:00:00:00:00:64=240d
#   wifidogx-trust-add.sh -t 1d -f /tmp/macs.txt
#==============================================================

set -eu

#---------------- 默认配置 (与实际环境一致) ----------------
DEF_TIMEOUT="1d"                       # 默认放行时长 (set 自身默认也是 1d)
NFT_FAMILY="inet"                      # nft family
NFT_TABLE="fw4"                        # wifidogx 信任 set 所在表
NFT_SET="set_wifidogx_trust_clients_out"

#---------------- 颜色输出 ----------------
if [ -t 1 ]; then
	C_RED='\033[0;31m'; C_GRN='\033[0;32m'; C_YEL='\033[1;33m'
	C_CYN='\033[0;36m'; C_DIM='\033[2m'; C_NC='\033[0m'
else
	C_RED=''; C_GRN=''; C_YEL=''; C_CYN=''; C_DIM=''; C_NC=''
fi
log()  { printf "${C_GRN}[+]${C_NC} %s\n" "$*"; }
warn() { printf "${C_YEL}[!]${C_NC} %s\n" "$*" >&2; }
err()  { printf "${C_RED}[-]${C_NC} %s\n" "$*" >&2; }
info() { printf "${C_CYN}[*]${C_NC} %s\n" "$*"; }

#---------------- 帮助 ----------------
usage() {
	cat <<EOF
用法: $(basename "$0") [选项] <mac1>[=timeout1] [mac2][=timeout2] ...
      $(basename "$0") [选项] -f <文件|->

批量放行 wifidogx 信任客户端 (向 nft set 添加多个 MAC)。
支持逐元素 timeout: MAC 后接 "=timeout" 单独指定该 MAC 的放行时长;
不带 = 的 MAC 用 -t 指定的默认 timeout。

选项:
  -t TIMEOUT  默认放行时长 (无 = 的 MAC 用此), 如 1d/8h/30m/3600s (默认: $DEF_TIMEOUT)
  -f FILE     从文件读取 MAC (每行: MAC 或 MAC=timeout; # 为注释; '-' 表示 stdin)
  -s SET      nft set 名称  (默认: $NFT_SET)
  -T TABLE    nft 表名      (默认: $NFT_TABLE, 留空则自动检测)
  -F FAMILY   nft family    (默认: $NFT_FAMILY)
  -n          干跑模式, 只打印 nft 命令不执行
  -q          安静模式 (仅输出错误)
  -S MS       逐条放行, 每条后 sleep MS 毫秒 (如 -S 200); 仅输出成功条数
  -h          显示本帮助

timeout 单位: s(秒) m(分) h(时) d(天) w(周); 支持组合如 1h30m20s / 2d12h / 1w3d; 纯数字按秒

示例:
  $(basename "$0") 16:72:c2:1a:aa:7d 20:e7:c8:15:26:5c
  $(basename "$0") -t 7d 16:72:c2:1a:aa:7d
  $(basename "$0") 02:00:00:00:00:01=1h 02:00:00:00:00:40=60d 02:00:00:00:00:64=240d
  $(basename "$0") -t 1d -f /tmp/trust_macs.txt
  $(basename "$0") -S 200 02:00:00:00:00:01=1h 02:00:00:00:00:02=30m   # 逐条放行, 间隔200ms
  echo "02:00:00:00:00:01=1h" | $(basename "$0") -f -
EOF
	exit "${1:-0}"
}

#---------------- MAC 校验 ----------------
# 仅接受 xx:xx:xx:xx:xx:xx (hex, 冒号分隔)
is_mac() {
	case "$1" in
		*[!0-9a-fA-F:]*) return 1 ;;
		*::*|:*|*:)     return 1 ;;
	esac
	printf '%s' "$1" | grep -Eqi '^([0-9a-f]{2}:){5}[0-9a-f]{2}$'
}

#---------------- timeout 校验 ----------------
# 接受 nft 时间语法 (nft_strtotime 按段累加):
#   - 纯数字(秒):     3600
#   - 单单位:         30m / 8h / 7d / 240d
#   - 组合累加:       1h30m20s / 2d12h / 1w3d / 90m
#   单位: s(秒) m(分) h(时) d(天) w(周)
# 拒绝: 1d2(数字无单位) / h1(单位在前) / 空 等
is_timeout() {
	[ -n "$1" ] || return 1
	printf '%s' "$1" | grep -Eq '^[0-9]+$|^([0-9]+[smhdw])+$'
}

#---------------- 收集 MAC (解析 =timeout, 去重, 小写, 校验) ----------------
MACS=""          # 空格分隔, 去重判断用
ELEMS=""         # 换行分隔, 每行 "mac timeout"
MAC_CNT=0

add_mac() {
	raw="$1"
	# 分离 mac 和 可选 timeout
	case "$raw" in
		*=*)
			mp="${raw%%=*}"
			tp="${raw#*=}"
			;;
		*)
			mp="$raw"
			tp="$TIMEOUT"
			;;
	esac
	# trim + 去 \r (兼容 Windows CRLF)
	mp=$(printf '%s' "$mp" | tr -d '\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
	tp=$(printf '%s' "$tp" | tr -d '\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
	# mac 小写化
	mac=$(printf '%s' "$mp" | tr 'A-F' 'a-f')
	# timeout 单位小写化 (纯数字不变)
	t=$(printf '%s' "$tp" | tr 'A-Z' 'a-z')
	if ! is_mac "$mac"; then
		warn "忽略无效 MAC: '$raw'"
		return 1
	fi
	if ! is_timeout "$t"; then
		warn "忽略无效 timeout: '$tp' (in '$raw')"
		return 1
	fi
	# 去重 (空格分隔列表, 两端留空格便于匹配)
	case " $MACS " in
		*" $mac "*) warn "跳过重复 MAC: $mac"; return 1 ;;
	esac
	MACS="$MACS $mac"
	MAC_CNT=$((MAC_CNT + 1))
	ELEMS="$ELEMS$mac $t
"
	[ "${QUIET:-0}" -eq 0 ] && log "已收集: $mac (timeout $t)"
	return 0
}

#---------------- 参数解析 ----------------
TIMEOUT="$DEF_TIMEOUT"
MAC_FILE=""
QUIET=0
DRYRUN=0
SLEEP_MS=""

while getopts "t:f:s:T:F:nqS:h" opt 2>/dev/null; do
	case "$opt" in
		t) TIMEOUT="$OPTARG" ;;
		f) MAC_FILE="$OPTARG" ;;
		s) NFT_SET="$OPTARG" ;;
		T) NFT_TABLE="$OPTARG" ;;
		F) NFT_FAMILY="$OPTARG" ;;
		n) DRYRUN=1 ;;
		q) QUIET=1 ;;
		S) SLEEP_MS="$OPTARG" ;;
		h) usage 0 ;;
		\?) usage 1 ;;
	esac
done
shift $((OPTIND - 1))

#---------------- 校验默认 timeout ----------------
if ! is_timeout "$TIMEOUT"; then
	err "默认 timeout 格式错误: '$TIMEOUT' (示例: 1d / 8h / 30m / 3600s)"
	exit 1
fi

#---------------- 校验 sleep 毫秒 (-S) ----------------
if [ -n "$SLEEP_MS" ]; then
	case "$SLEEP_MS" in
		*[!0-9]*) err "-S 需要毫秒整数, 如 -S 200"; exit 1 ;;
	esac
	QUIET=1   # 逐条模式: 过程静默, 仅最终输出成功数
fi

#---------------- 1) 从命令行参数收集 ----------------
for m in "$@"; do
	add_mac "$m" || true
done

#---------------- 2) 从文件/stdin 收集 ----------------
if [ -n "$MAC_FILE" ]; then
	if [ "$MAC_FILE" = "-" ]; then
		# stdin
		while read -r line || [ -n "$line" ]; do
			line="${line%%#*}"                  # 去注释
			[ -z "$(printf '%s' "$line" | tr -d '[:space:]')" ] && continue
			add_mac "$line" || true
		done
	elif [ -r "$MAC_FILE" ]; then
		while read -r line || [ -n "$line" ]; do
			line="${line%%#*}"
			[ -z "$(printf '%s' "$line" | tr -d '[:space:]')" ] && continue
			add_mac "$line" || true
		done < "$MAC_FILE"
	else
		err "无法读取文件: $MAC_FILE"
		exit 1
	fi
fi

# trim 首尾空格
MACS="${MACS# }"
MACS="${MACS% }"

if [ -z "$MACS" ]; then
	err "未提供任何有效 MAC 地址"
	usage 1
fi

#---------------- 自动定位表 ----------------
if [ -n "$NFT_TABLE" ]; then
	# 用户/默认指定了表, 校验 set 是否真的在里面
	if ! nft list table "$NFT_FAMILY" "$NFT_TABLE" 2>/dev/null | grep -Eqi "^[[:space:]]*set[[:space:]]+$NFT_SET[[:space:]]*\{"; then
		warn "表 '$NFT_FAMILY $NFT_TABLE' 中未找到 set '$NFT_SET', 尝试自动检测..."
		NFT_TABLE=""
	fi
fi

if [ -z "$NFT_TABLE" ]; then
	info "自动检测 set '$NFT_SET' 所在表..."
	detected=$(nft -a list ruleset 2>/dev/null | awk -v want="$NFT_SET" '
		/^[[:space:]]*table[[:space:]]/ { fam = $2; tbl = $3 }
		/^[[:space:]]*set[[:space:]]/ {
			name = $2
			sub(/[[:space:]].*/, "", name)
			if (name == want) { printf "%s %s", fam, tbl; found = 1; exit }
		}
		END { if (!found) exit 2 }') || detected=""
	if [ -z "$detected" ]; then
		err "未找到包含 set '$NFT_SET' 的表"
		err "请确认 wifidogx 已运行且已生成 nft 规则, 或用 -T/-F 显式指定"
		exit 1
	fi
	NFT_FAMILY="${detected%% *}"
	NFT_TABLE="${detected#* }"
fi

# 统计 per-element timeout 分布 (方便核对)
N_DISTINCT_TO=$(printf '%s\n' "$ELEMS" | awk 'NF{print $2}' | sort -u | wc -l | tr -d ' ')
[ "${QUIET:-0}" -eq 0 ] && info "目标: $NFT_FAMILY $NFT_TABLE -> $NFT_SET  (共 $MAC_CNT 个 MAC, $N_DISTINCT_TO 种不同 timeout)"

#---------------- 构造 nft 批量 add element 命令 ----------------
# 每个元素用自己的 timeout: { mac1 timeout t1, mac2 timeout t2, ... }
elem=""
while read -r m t; do
	[ -z "$m" ] && continue
	[ -n "$elem" ] && elem="$elem, "
	elem="$elem$m timeout $t"
done <<EOF
$ELEMS
EOF
NFT_CMD="add element $NFT_FAMILY $NFT_TABLE $NFT_SET { $elem }"

#---------------- 干跑 ----------------
if [ "$DRYRUN" -eq 1 ]; then
	info "[干跑] 将执行:"
	printf "  ${C_DIM}nft '%s'${C_NC}\n" "$NFT_CMD"
	exit 0
fi

#---------------- 逐条模式 (-S): 每条单独 add + sleep, 极简输出 ----------------
if [ -n "$SLEEP_MS" ]; then
	# sleep 方式自适应 (部分 BusyBox sleep 不支持小数, 如 "invalid number '0.2'"):
	#   优先 sleep 小数 -> usleep 微秒 -> sleep 整数秒(向上取整)
	_do_sleep() {
		if [ "${_SLEEP_FANCY:-0}" = 1 ]; then
			sleep "$(awk -v m="$1" 'BEGIN{printf "%g", m/1000}')" || true
		elif [ "${_HAS_USLEEP:-0}" = 1 ]; then
			usleep "$(( $1 * 1000 ))" || true
		else
			sleep "$(( ($1 + 999) / 1000 ))" || true
		fi
	}
	if sleep 0.001 2>/dev/null; then _SLEEP_FANCY=1; else _SLEEP_FANCY=0; fi
	if command -v usleep >/dev/null 2>&1; then _HAS_USLEEP=1; else _HAS_USLEEP=0; fi
	ok=0; fail=0; n=0
	while read -r m t; do
		[ -z "$m" ] && continue
		n=$((n + 1))
		if nft "add element $NFT_FAMILY $NFT_TABLE $NFT_SET { $m timeout $t }" 2>/dev/null; then
			ok=$((ok + 1))
		else
			fail=$((fail + 1))
		fi
		if [ "$n" -lt "$MAC_CNT" ]; then _do_sleep "$SLEEP_MS"; fi
	done <<EOF
$ELEMS
EOF
	printf "成功 %d 条\n" "$ok"
	if [ "$fail" -gt 0 ]; then printf "失败 %d 条\n" "$fail" >&2; exit 1; fi
	exit 0
fi

#---------------- 执行: 先尝试一次性批量添加 ----------------
ok=0; fail=0
if nft "$NFT_CMD" 2>&1; then
	ok=$MAC_CNT
	log "成功批量放行 $ok 个 MAC"
else
	warn "批量添加失败, 退化为逐个添加..."
	while read -r m t; do
		[ -z "$m" ] && continue
		if nft "add element $NFT_FAMILY $NFT_TABLE $NFT_SET { $m timeout $t }" 2>/dev/null; then
			log "  + $m ($t)"
			ok=$((ok + 1))
		else
			err "  x $m ($t)"
			fail=$((fail + 1))
		fi
	done <<EOF
$ELEMS
EOF
fi

#---------------- 结果汇总 ----------------
if [ "$fail" -gt 0 ]; then
	err "完成: 成功 $ok, 失败 $fail"
	exit 1
fi

[ "$QUIET" -eq 0 ] && info "完成: 全部 $ok 个 MAC 已放行"
exit 0
