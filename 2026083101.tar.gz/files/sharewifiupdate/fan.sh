#!/bin/sh

# ==========================================================
# OpenWrt 两线风扇软件PWM控制
#
# 用法：
#
# 固定模式：
#   sh fan.sh fixed 50
#
# 温控模式：
#   sh fan.sh auto
# ==========================================================

# 软件PWM周期，单位秒
PERIOD=10

# 如果知道准确路径，可以直接填写，例如：
# PWM_FILE="/sys/class/hwmon/hwmon2/pwm1"
PWM_FILE=""

# 如果知道准确温度文件，可以填写：
# TEMP_FILE="/sys/class/thermal/thermal_zone0/temp"
TEMP_FILE=""

MODE="$1"
FIXED_DUTY="$2"

LAST_DUTY="-1"


find_pwm()
{
    if [ -n "$PWM_FILE" ] && [ -e "$PWM_FILE" ]; then
        return 0
    fi

    for f in /sys/class/hwmon/hwmon*/pwm1
    do
        if [ -e "$f" ]; then
            PWM_FILE="$f"
            return 0
        fi
    done

    echo "错误：找不到 /sys/class/hwmon/hwmon*/pwm1"
    exit 1
}


fan_on()
{
    echo 255 > "$PWM_FILE"
}


fan_off()
{
    echo 0 > "$PWM_FILE"
}


get_temp()
{
    if [ -n "$TEMP_FILE" ] && [ -r "$TEMP_FILE" ]; then
        VALUE="$(cat "$TEMP_FILE" 2>/dev/null)"

        if [ -z "$VALUE" ]; then
            return 1
        fi

        if [ "$VALUE" -gt 1000 ] 2>/dev/null; then
            VALUE=$((VALUE / 1000))
        fi

        echo "$VALUE"
        return 0
    fi


    MAX_TEMP=""

    for f in /sys/class/thermal/thermal_zone*/temp
    do
        [ -r "$f" ] || continue

        VALUE="$(cat "$f" 2>/dev/null)"
        [ -n "$VALUE" ] || continue

        if [ "$VALUE" -gt 1000 ] 2>/dev/null; then
            VALUE=$((VALUE / 1000))
        fi

        [ "$VALUE" -ge 0 ] 2>/dev/null || continue
        [ "$VALUE" -le 150 ] 2>/dev/null || continue

        if [ -z "$MAX_TEMP" ]; then
            MAX_TEMP="$VALUE"
        elif [ "$VALUE" -gt "$MAX_TEMP" ]; then
            MAX_TEMP="$VALUE"
        fi
    done

    if [ -z "$MAX_TEMP" ]; then
        return 1
    fi

    echo "$MAX_TEMP"
    return 0
}


get_duty()
{
    TEMP="$1"

    if [ "$TEMP" -lt 45 ]; then
        echo 0
    elif [ "$TEMP" -lt 50 ]; then
        echo 30
    elif [ "$TEMP" -lt 55 ]; then
        echo 50
    elif [ "$TEMP" -lt 60 ]; then
        echo 70
    else
        echo 100
    fi
}


run_pwm()
{
    DUTY="$1"

    # 防止参数异常
    case "$DUTY" in
        ''|*[!0-9]*)
            DUTY=100
            ;;
    esac

    if [ "$DUTY" -lt 0 ]; then
        DUTY=0
    fi

    if [ "$DUTY" -gt 100 ]; then
        DUTY=100
    fi


    if [ "$DUTY" -eq 0 ]; then
        fan_off
        sleep "$PERIOD"
        return
    fi


    if [ "$DUTY" -eq 100 ]; then
        fan_on
        sleep "$PERIOD"
        return
    fi


    # 根据百分比自动计算开启时间
    ON_TIME=$((PERIOD * DUTY / 100))
    OFF_TIME=$((PERIOD - ON_TIME))


    # 至少开启1秒
    if [ "$ON_TIME" -lt 1 ]; then
        ON_TIME=1
        OFF_TIME=$((PERIOD - 1))
    fi


    fan_on
    sleep "$ON_TIME"

    fan_off
    sleep "$OFF_TIME"
}


cleanup()
{
    # 程序退出时全速运行，避免设备过热
    fan_on
    exit 0
}


find_pwm

echo "PWM设备：$PWM_FILE"


case "$MODE" in

    fixed)

        if [ -z "$FIXED_DUTY" ]; then
            echo "请指定占空比，例如："
            echo "sh fan.sh fixed 50"
            exit 1
        fi

        echo "固定模式"
        echo "占空比：${FIXED_DUTY}%"
        echo "周期：${PERIOD}秒"

        trap cleanup INT TERM

        while true
        do
            run_pwm "$FIXED_DUTY"
        done

        ;;


    auto)

        echo "自动温控模式"
        echo "周期：${PERIOD}秒"

        trap cleanup INT TERM

        while true
        do
            TEMP="$(get_temp)"

            if [ $? -ne 0 ] || [ -z "$TEMP" ]; then
                DUTY=100
                echo "温度读取失败 -> 风扇100%"
            else
                DUTY="$(get_duty "$TEMP")"

                if [ "$DUTY" != "$LAST_DUTY" ]; then
                    echo "温度：${TEMP} C -> 风扇：${DUTY}%"
                fi
            fi

            LAST_DUTY="$DUTY"

            run_pwm "$DUTY"
        done

        ;;


    *)

        echo "用法："
        echo ""
        echo "固定模式："
        echo "  sh fan.sh fixed 50"
        echo ""
        echo "自动温控："
        echo "  sh fan.sh auto"
        echo ""
        exit 1

        ;;

esac