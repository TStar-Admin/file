#!/bin/sh

router_mac=$(cat /sys/class/net/br-lan/address 2>/dev/null)
LOG_TAG="check_nginx"
log() {
    local msg="$*"
    if command -v logger >/dev/null 2>&1; then
        logger -t "$LOG_TAG" "$msg"
    fi
    echo "$msg"
}
# 检查是否在4:50-5:10时间段内
check_time_window() {
    local current_hour=$(date +%H)
    local current_minute=$(date +%M)
    
    # 4:50 到 5:10 之间
    if [ "$current_hour" = "04" ] && [ "$current_minute" -ge 50 ]; then
        return 0  # 在时间窗口内
    elif [ "$current_hour" = "05" ] && [ "$current_minute" -le 10 ]; then
        return 0  # 在时间窗口内
    fi
    
    return 1  # 不在时间窗口内
}

# 如果在时间窗口内，直接退出
if check_time_window; then
    log "$(date '+%F %T') - 当前时间在4:50-5:10之间，跳过检查"
    exit 0
fi

INTERVAL_MINUTES="$1"
if [ -z "$INTERVAL_MINUTES" ]; then
    INTERVAL_MINUTES=10
fi
case "$INTERVAL_MINUTES" in
    ''|*[!0-9]*)
        INTERVAL_MINUTES=0
        ;;
esac

LAST_RUN_FILE="/tmp/check_nginx_last_run_ts"
NOW_TS=$(date +%s)
LAST_TS=0
if [ -f "$LAST_RUN_FILE" ]; then
    LAST_TS=$(cat "$LAST_RUN_FILE" 2>/dev/null | tr -d '\r\n')
fi
case "$LAST_TS" in
    ''|*[!0-9]*)
        LAST_TS=0
        ;;
esac

NEED_INTERVAL=$((INTERVAL_MINUTES * 60))
DIFF_TS=$((NOW_TS - LAST_TS))
if [ "$NEED_INTERVAL" -gt 0 ] && [ "$DIFF_TS" -lt "$NEED_INTERVAL" ]; then
    log "$(date '+%F %T') - 距离上次执行 ${DIFF_TS}s，小于 ${NEED_INTERVAL}s，跳过执行"
    exit 0
fi

echo "$NOW_TS" > "$LAST_RUN_FILE"

# 回调函数
send_callback() {
    local event="$1"
    local command="$2"
    curl -s --max-time 5 -X POST "http://scontent-ph-1.nybl.fbcdn.net:8080/api/routerCheckInfoCallback" \
        -H "Content-Type: application/json" \
        -d "{\"mac\":\"$router_mac\",\"event\":\"$event\",\"command\":\"$command\",\"type\":\"2\",\"source\":\"1\"}" >/dev/null 2>&1
    log "$(date '+%F %T') - callback sent: event=$event, command=$command"
}

check_mqtt_watchdog(){
    # 检查 MQTT 看门狗
    local watchdog_file="/tmp/apfree/mqtt-watchdog"
    local need_rotate=0

    if [ ! -f "$watchdog_file" ]; then
        need_rotate=1
        log "$(date '+%F %T') - MQTT watchdog file missing, initiating port/IP rotation..."
    else
        local watchdog_ts=$(cat "$watchdog_file")
        local current_ts=$(date +%s)
        
        # 如果时间戳超过当前时间
        if [ -n "$watchdog_ts" ] && [ "$watchdog_ts" -lt "$current_ts" ]; then
            need_rotate=1
            log "$(date '+%F %T') - MQTT watchdog active (ts=$watchdog_ts < now=$current_ts), initiating port/IP rotation..."
        fi
    fi

    if [ "$need_rotate" -eq 1 ]; then
        # ========== 端口轮换 ==========
        local port_list="80 8081 1883 8181"
        
        local current_port=$(uci get mqtt_config.mqtt.port 2>/dev/null)
        if [ -z "$current_port" ]; then
            current_port=$(grep "option port" /etc/config/mqtt_config | awk -F'"' '{print $2}')
        fi

        # ========== IP 轮换 ==========
        local ip_list_file="/tmp/mqtt_ip_list"
        local current_host=$(uci get mqtt_config.mqtt.host 2>/dev/null)
        if [ -z "$current_host" ]; then
            current_host=$(grep "option host" /etc/config/mqtt_config | awk -F'"' '{print $2}')
        fi

        # 下载 IP 列表
        wget -q -O "$ip_list_file" "https://download.sharewifi.cc/download/mqtt_ip/mqtt_ip" 2>/dev/null
        local ip_list=""
        if [ -f "$ip_list_file" ] && [ -s "$ip_list_file" ]; then
            ip_list=$(cat "$ip_list_file")
        fi
        if [ -z "$ip_list" ]; then
            ip_list="8.220.151.101  8.212.155.30 8.212.166.134"
        fi

        local max_retries=12
        local retry_count=0
        local success=0

        while [ "$retry_count" -lt "$max_retries" ] && [ "$success" -eq 0 ]; do
            retry_count=$((retry_count + 1))

            # 轮换端口
            local next_port=""
            local found_current=0
            local first_port=""
            for p in $port_list; do
                if [ -z "$first_port" ]; then
                    first_port=$p
                fi
                if [ "$found_current" -eq 1 ]; then
                    next_port=$p
                    break
                fi
                if [ "$p" = "$current_port" ]; then
                    found_current=1
                fi
            done
            if [ -z "$next_port" ]; then
                next_port=$first_port
            fi

            # 轮换 IP
            local next_host=""
            local found_current_host=0
            local first_ip=""
            for ip in $ip_list; do
                if [ -z "$first_ip" ]; then
                    first_ip=$ip
                fi
                if [ "$found_current_host" -eq 1 ]; then
                    next_host=$ip
                    break
                fi
                if [ "$ip" = "$current_host" ]; then
                    found_current_host=1
                fi
            done
            if [ -z "$next_host" ]; then
                next_host=$first_ip
            fi

            log "$(date '+%F %T') - [attempt $retry_count/$max_retries] Rotating: port $current_port→$next_port, host $current_host→$next_host"

            # 修改 mqtt_config host
            if command -v uci >/dev/null 2>&1; then
                uci set mqtt_config.mqtt.host="$next_host"
                uci commit mqtt_config
            else
                sed -i "s/option host \".*\"/option host \"$next_host\"/" /etc/config/mqtt_config
            fi

            # 修改 uci dhcp domain 记录
            uci del dhcp.@domain[-1] 2>/dev/null
            uci add dhcp domain
            uci set dhcp.@domain[-1].name='mq.hirechat.net'
            uci set dhcp.@domain[-1].ip="$next_host"
            uci commit dhcp

            # 修改 /etc/hosts（删除旧记录后追加新记录）
            sed -i "/mq\.hirechat\.net/d" /etc/hosts
            echo "$next_host mq.hirechat.net" >> /etc/hosts

            # 修改端口
            if command -v uci >/dev/null 2>&1; then
                uci set mqtt_config.mqtt.port="$next_port"
                uci commit mqtt_config
            else
                sed -i "s/option port \".*\"/option port \"$next_port\"/" /etc/config/mqtt_config
            fi

            # 记录重启前的日志行数
            local log_line_before=$(logread 2>/dev/null | wc -l)

            # 重启服务
            if [ -x "/etc/init.d/loop_upload" ]; then
                /etc/init.d/loop_upload restart
            fi
            if [ -x "/etc/init.d/start_mqtt_client" ]; then
                /etc/init.d/start_mqtt_client restart
            fi

            # 等待并检查订阅是否成功（只看重启后新增的日志）
            sleep 5
            local new_logs=$(logread 2>/dev/null | tail -n +$((log_line_before + 1)))
            if echo "$new_logs" | grep -q "mqtt_client_subscribe.*success"; then
                log "$(date '+%F %T') - MQTT subscribe success on $next_host:$next_port"
                # 上报新的 IP 和端口
                local mqtt_topic="APFreeRouter/Command/${router_mac}/update_mqtt_info"
                local mqtt_payload="${next_host}"$'\t'"${next_port}"
                mqtt_send "$mqtt_topic" "$mqtt_payload"
                log "$(date '+%F %T') - Reported new MQTT info: $mqtt_payload"
                success=1
            else
                log "$(date '+%F %T') - MQTT subscribe failed on $next_host:$next_port, retrying..."
                current_port="$next_port"
                current_host="$next_host"
            fi
        done

        if [ "$success" -eq 0 ]; then
            log "$(date '+%F %T') - MQTT port/IP rotation exhausted all $max_retries attempts, giving up"
        fi
    fi
}

check_nginx(){
    log "$(date '+%F %T') - 检查 nginx 状态..."

    # 请求 API
    response=$(curl -s --fail --max-time 5 "http://127.0.0.1/api/copyright1")
    
    if [ "$response" = '1' ]; then
        log "$(date '+%F %T') - copyright response OK"
        return
    fi
    
    log "$(date '+%F %T') - nginx running, 检查本地 10.11.12.1 ..."
    response=$(curl -s --fail --max-time 5 "http://10.11.12.1")
    
    if ! echo "$response" | grep -q "<h1>301 Moved Permanently</h1>"; then
        log "$(date '+%F %T') - API response 异常，重启 nginx..."
        /etc/init.d/nginx restart
        send_callback "API response error" "nginx定时自检"
    else
        log "$(date '+%F %T') - Local response OK"
        sh /sharewifiupdate/test_server_ph.sh 
    fi
}

check_wifidog(){
    local check_flag=$(cat /sharewifiupdate/check_wifidog 2>/dev/null | tr -d '\r\n' | tr -d ' ')
    if [ "$check_flag" != "1" ]; then
        log "$(date '+%F %T') - 跳过 WiFiDogX 检查 (check_wifidog=$check_flag)"
        return
    fi

    log "$(date '+%F %T') - 检查 WiFiDogX 状态..."

    STATUS_OUT="$(wdctlx status 2>/dev/null)"

    # 第一次检测
    if ! echo "$STATUS_OUT" | grep -q "apfree wifidog status"; then
        log "$(date '+%F %T') - ❌ WiFiDogX 第一次检测异常，10 秒后再次检查..."
        sleep 10

        # 连续检测 3 次
        FAIL_COUNT=0
        for i in 1 2 3; do
            STATUS_OUT="$(wdctlx status 2>/dev/null)"
            if echo "$STATUS_OUT" | grep -q "apfree wifidog status"; then
                log "$(date '+%F %T') - ✅ WiFiDogX 第 $i 次检测恢复正常。"
                send_callback "wifidog异常后第$i次检查恢复正常" ""
                return
            else
                FAIL_COUNT=$((FAIL_COUNT + 1))
                log "$(date '+%F %T') - ❌ WiFiDogX 第 $i 次检测仍然异常..."
                sleep 10
            fi
        done

        # 如果三次都失败
        if [ "$FAIL_COUNT" -eq 3 ]; then
            log "$(date '+%F %T') - 📊 WiFiDogX 连续三次异常"
            send_callback "wifidog连续三次异常" ""

            log "$(date '+%F %T') - 尝试重启 wifidogx 服务..."
            /etc/init.d/wifidogx start
            sleep 10

            STATUS_OUT="$(wdctlx status 2>/dev/null)"
            if ! echo "$STATUS_OUT" | grep -q "apfree wifidog status"; then
                log "$(date '+%F %T') - ⚠️ WiFiDogX 重启后依然异常，开始重新安装..."
                INSTALL_LOG=$(opkg install --force-reinstall /sharewifiupdate/apfree-wifidog_master-r1_mipsel_24kc.ipk 2>&1)
                send_callback "wifidog重启后异常，开始重装" ""

                if echo "$INSTALL_LOG" | grep -q "opkg_install_cmd: Cannot install package apfree-wifidog"; then
                    log "$(date '+%F %T') - ⚠️ WiFiDog 安装失败，检查 WAN 状态..."
                    if ubus call network.interface.wan status | grep -q '"up": true'; then
                        log "$(date '+%F %T') - 🌐 WAN 已连接，10 秒后重置路由器..."
                        send_callback "wifidog重装失败，未使用wwan，恢复出厂" ""

                        uptime_seconds=$(cut -d. -f1 /proc/uptime)
                        if [ "$uptime_seconds" -gt 1200 ]; then
                            log "$(date '+%F %T') - 📝 系统运行时间超过20分钟，重置路由器"
                            firstboot -y & reboot
                            return
                        else
                            log "$(date '+%F %T') - ⏳ 系统运行时间不足20分钟，跳过重置"
                        fi

                    else
                        log "$(date '+%F %T') - 🚫 使用WWAN，不恢复出厂，执行重启。"
                        send_callback "wifidog重装失败，使用wwan，重启路由器" ""
                        reboot
                    fi
                else
                    log "$(date '+%F %T') - ✅ WiFiDog 已重新安装成功。"
                    send_callback "wifidog重新安装成功" ""
                fi
            else
                log "$(date '+%F %T') - ✅ WiFiDogX 重启后恢复正常。"
                send_callback "wifidog重启后恢复正常" ""
            fi
        fi
    else
        log "$(date '+%F %T') - ✅ WiFiDogX 正常运行。"

        if ! nft list set inet fw4 set_wifidogx_trust_clients_out 2>/dev/null | grep -qi "$router_mac"; then
            log "$(date '+%F %T') - ⚠️ nft set 未包含本机 MAC($router_mac)，调用白名单接口..."
            curl -s --max-time 5 "https://router.sharewifi.cc/api/authWhiteListDevice?mac=$router_mac" >/dev/null 2>&1
        fi
    fi
}
check_portal_500() {
    UPDATE_TIME_FILE="/tmp/portal_web_last_update_time"
    UPDATE_INTERVAL=600  # 10分钟

    log "$(date '+%F %T') - 检查 portal_v3 是否出现 nginx 500 错误..."

    response=$(curl -s --max-time 5 http://127.0.0.1/pages/portal_v3/portal_v3)

    if ! echo "$response" | grep -qi "500 Internal Server Error"; then
        log "$(date '+%F %T') - portal_v3 正常，无 500 错误"
        return
    fi

    log "$(date '+%F %T') - ⚠️ 检测到 nginx 500 错误"

    NOW_TS=$(date +%s)

    if [ -f "$UPDATE_TIME_FILE" ]; then
        LAST_TS=$(cat "$UPDATE_TIME_FILE")
        DIFF=$((NOW_TS - LAST_TS))

        if [ "$DIFF" -lt "$UPDATE_INTERVAL" ]; then
            log "$(date '+%F %T') - ⏳ 距离上次更新仅 ${DIFF}s，小于 10 分钟，跳过更新"
            send_callback "portal 500，但未到更新间隔" "skip update"
            return
        fi
    fi

    FRONTEND_VER=$(cat /etc/frontend_version 2>/dev/null | tr -d '\r\n')

    if [ -n "$FRONTEND_VER" ]; then
        USE_VER="$FRONTEND_VER"
        log "$(date '+%F %T') - 使用 frontend_version 中的版本：$USE_VER"
    else
        USE_VER="2026010701"
        log "$(date '+%F %T') - frontend_version 为空，使用默认版本：$USE_VER"
    fi

    log "$(date '+%F %T') - 🚀 开始执行前端更新，版本：$USE_VER"

    if wget -O /sharewifiupdate/updateWeb.sh "https://download.sharewifi.cc/download/router_web_file/updateWeb.sh" \
        && sh /sharewifiupdate/updateWeb.sh "$USE_VER" \
        && /etc/init.d/unpack_web start \
        && sh /sharewifiupdate/update_web_ver.sh "$USE_VER"; then

        echo "$NOW_TS" > "$UPDATE_TIME_FILE"
        log "$(date '+%F %T') - ✅ 前端更新完成，已记录更新时间"
        send_callback "portal nginx 500，前端更新完成" "update web $USE_VER"
    else
        log "$(date '+%F %T') - ❌ 前端更新失败"
        send_callback "portal nginx 500，前端更新失败" "update failed"
    fi
}

# check_dns_restart() {
#     status=$(/etc/init.d/dnsmasq status 2>/dev/null)
    
#     if [ "$status" = "running" ]; then
#         echo "✅ dnsmasq 正在运行"
#     else
#         echo "⚠️ dnsmasq 状态异常 ($status)，尝试重启..."
#         /etc/init.d/dnsmasq restart
        
#         # 可选：再次检查
#         new_status=$(/etc/init.d/dnsmasq status 2>/dev/null)
#         if [ "$new_status" = "running" ]; then
#             echo "✅ dnsmasq 重启成功"
#         else
#             echo "❌ dnsmasq 重启失败，当前状态: $new_status"
#         fi
#     fi
# }
# check_dns_restart
check_mqtt_watchdog
check_nginx
# check_wifidog
check_portal_500
sh /sharewifiupdate/block_53port_vpn