#!/bin/sh
TASK_FILE="/sharewifiupdate/timer_tasks.txt"

if [ $# -lt 2 ]; then
    echo "Usage: AddTimer <seconds_from_now> <command>"
    exit 1
fi

DELAY=$1
shift
CMD="$*"
EXEC_TIME=$(( $(date +%s) + DELAY ))

# 确保文件存在
[ -f "$TASK_FILE" ] || touch "$TASK_FILE"

# 删除相同命令的旧行（按 | 分隔，第二个字段精确匹配），然后追加新任务
awk -F'|' -v cmd="$CMD" '$2 != cmd { print }' "$TASK_FILE" > "$TASK_FILE.tmp"
echo "$EXEC_TIME|$CMD" >> "$TASK_FILE.tmp"
mv "$TASK_FILE.tmp" "$TASK_FILE"

echo "Task added: will run at $(date -d @$EXEC_TIME) -> $CMD"
