#!/bin/sh

BOARD_NAME=$(cat /tmp/sysinfo/board_name)

# Ĭ�� LED ·��
Y_LED_NET="/sys/class/leds/yellow:net/brightness"
B_LED_NET="/sys/class/leds/blue:net/brightness"

# ���ͬʱ���� jcg �� q20�����л� LED ·��
if echo "$BOARD_NAME" | grep -qi "jcg" && echo "$BOARD_NAME" | grep -qi "q20"; then
    Y_LED_NET="/sys/class/leds/red:status/brightness"
    B_LED_NET="/sys/class/leds/blue:status/brightness"
fi

case "$1" in
    connecting)
        echo "1" > $B_LED_NET
        echo "0" > $Y_LED_NET
        ;;
    connected)
        echo "1" > $Y_LED_NET
        echo "1" > $B_LED_NET
        ;;
    *)
        echo "Usage: $0 {connecting|connected}"
        exit 1
        ;;
esac
