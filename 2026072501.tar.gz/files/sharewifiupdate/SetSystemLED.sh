#!/bin/sh

STATE="$1"
BOARD_NAME=$(cat /tmp/sysinfo/board_name)

# Ĭ�� LED ·��
Y_SYS="/sys/class/leds/yellow:sys/brightness"
B_SYS="/sys/class/leds/blue:sys/brightness"

# ������� jcg �Ұ��� q20 ���޸� LED ·��
if echo "$BOARD_NAME" | grep -qi "jcg" && echo "$BOARD_NAME" | grep -qi "q20"; then
    Y_SYS="/sys/class/leds/red:status/brightness"
    B_SYS="/sys/class/leds/blue:status/brightness"
fi

PID_FILE="/tmp/led_flash.pid"

case "$STATE" in
    connecting)
        echo 0 > $Y_SYS
        echo 1 > $B_SYS
        ;;

    connected)
        echo 1 > $Y_SYS
        echo 1 > $B_SYS
        ;;

    updating)
        if [ -f $PID_FILE ]; then
            kill $(cat $PID_FILE) 2>/dev/null
            rm -f $PID_FILE
        fi

        (
            while true; do
                echo 0 > $Y_SYS
                echo 0 > $B_SYS
                sleep 1
                echo 1 > $Y_SYS
                echo 1 > $B_SYS
                sleep 1
            done
        ) &
        echo $! > $PID_FILE
        ;;

    stop)
        if [ -f $PID_FILE ]; then
            kill $(cat $PID_FILE) 2>/dev/null
            rm -f $PID_FILE
            echo "Flashing stopped."
            echo 1 > $Y_SYS
            echo 1 > $B_SYS
        else
            echo "No flashing process running."
        fi
        ;;

    *)
        echo "Usage: $0 {connecting|connected|updating|stop}"
        exit 1
        ;;
esac
