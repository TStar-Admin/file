#!/bin/sh
# ---------------------------------------------------------------------------
# aw-fw-setup-0722(ttl).sh
#
# Standalone firewall setup for Nginx-based Captive Portal.
# Replaces wifidogx's nft_fw_init() with Nginx as the redirect target.
#
# Changes from aw-fw-setup-0720.sh:
#   - FIX: TTL 检测与 TTL 改写分离处理
#     * TTL 检测 (Anti-NAT) 保留在 nat prerouting 阶段，检查原始 TTL
#     * TTL 改写 (set 64) 移至 mangle postrouting 阶段，在检测通过后执行
#     * 修复了之前 mangle prerouting 先改写 TTL 导致 Anti-NAT 检测失效的问题
#   - HTTP redirect: 2060 -> 2080 (Nginx)
#   - HTTPS redirect: 8443 -> 9443 (Nginx)
#
# Usage:
#   sh aw-fw-setup-0722(ttl).sh [-c CONFIG] [-r] [-D]
#     -c CONFIG  config path (UCI or classic format)
#     -r         teardown only.
#     -D         skip DNS resolution of trusted domain groups.
# ---------------------------------------------------------------------------

set -u

CONFIG_FILE=""
TEARDOWN_ONLY=0
SKIP_DOMAINS=0

# Nginx 监听端口
NGINX_HTTP_PORT=2080
NGINX_HTTPS_PORT=9443
IPTABLE_FILE="/sharewifiupdate/wifidog_update/iptable"

while getopts "c:rDh" opt; do
    case "$opt" in
        c) CONFIG_FILE="$OPTARG" ;;
        r) TEARDOWN_ONLY=1 ;;
        D) SKIP_DOMAINS=1 ;;
        *) sed -n '2,35p' "$0"; exit 1 ;;
    esac
done

[ "$(id -u)" -eq 0 ] || { echo "must run as root" >&2; exit 1; }
command -v nft >/dev/null 2>&1 || { echo "nft not found" >&2; exit 1; }
command -v ip  >/dev/null 2>&1 || { echo "ip not found"  >&2; exit 1; }

# ---------------------------------------------------------------------------
# 1. Locate config
# ---------------------------------------------------------------------------
if [ -z "$CONFIG_FILE" ]; then
    for c in /etc/config/wifidogx \
             /etc/wifidogx/wifidogx.conf \
             /etc/wifidog/wifidogx.conf \
             /sharewifiupdate/wifidog_update/wifidogx.conf\
             "$(dirname "$0")/wifidogx.conf"; do
        [ -f "$c" ] && CONFIG_FILE="$c" && break
    done
fi
[ -n "$CONFIG_FILE" ] && [ -f "$CONFIG_FILE" ] || {
    echo "no config found (use -c PATH)" >&2; exit 1; }

echo "[*] using config: $CONFIG_FILE"

# ---------------------------------------------------------------------------
# 2. Parse config -> a flat KEY=VALUE temp file
# ---------------------------------------------------------------------------
TMP="$(mktemp /tmp/awfw.XXXXXX)"
trap 'rm -f "$TMP" "$TMP.gw"' EXIT INT TERM

is_uci=0
grep -Eq '^[[:space:]]*config[[:space:]]+[A-Za-z_]+' "$CONFIG_FILE" && is_uci=1

if [ "$is_uci" -eq 1 ]; then
    echo "[*] format: UCI"
    awk '
        function unq(s) { gsub(/^['\''"]|['\''"]$/,"",s); return s }
        function value() {
            v=""
            for (i=3; i<=NF; i++) v = (v=="") ? $i : v" "$i
            return unq(v)
        }

        /^[[:space:]]*config[[:space:]]+/ {
            sec_type=$2
            sec_name=(NF>=3) ? $3 : ""
            sec_name=unq(sec_name)
            in_common  = (sec_type=="wifidogx" || sec_type=="wifidog")
            in_gateway = (sec_type=="gateway")
            in_group   = (sec_type=="group")
            cur_group  = sec_name
            cur_section = sec_type
            cur_v4=""
            next
        }

        /^[[:space:]]*option[[:space:]]+/ {
            key=$2; v=value()
            if (in_common) {
                if (key=="gateway_interface")       print "IF=" v
                else if (key=="external_interface") print "EXT=" v
                else if (key=="auth_server_hostname") print "AS=" v
                else if (key=="auth_server_mode")   print "ASM=" v
                else if (key=="enable_dns_forward") print "DNS=" v
                else if (key=="enable_dhcp_cpi")    print "DHCP=" v
                else if (key=="enable_anti_nat")    print "ANTI=" v
                else if (key=="ttl_values")         print "TTL=" v
                else if (key=="anti_nat_permit_macs") print "ANM=" v
                else if (key=="trusted_maclist")    print "TM=" v
                else if (key=="trusted_local_maclist") print "TLM=" v
            } else if (in_gateway) {
                if (key=="gateway_name")            print "IF=" v
                else if (key=="gateway_subnetv4") {
                    a=v; sub(/\/.*/,"",a)
                    print "IFV4_PEND=" a
                }
            }
            next
        }

        /^[[:space:]]*list[[:space:]]+/ {
            key=$2; v=value()
            if (in_common && key=="app_white_list")    print "AWL=" v
            else if (in_group && key=="domain_name") {
                print "GDOM=" cur_group ":" v
            }
            next
        }
    ' "$CONFIG_FILE" > "$TMP"
else
    echo "[*] format: classic (wifidogx.conf)"
    awk '
        function trim(s) { sub(/^[[:space:]]+/,"",s); sub(/[[:space:]]+$/,"",s); return s }
        /^[[:space:]]*(#|$)/ { next }
        {
            line=trim($0)
            if (in_gw) {
                if (line=="}") {
                    if (gi!="") print "IF=" gi
                    if (gv4!="") print "GW_V4_FOR=" gi "=" gv4
                    if (gv6!="") print "GW_V6_FOR=" gi "=" gv6
                    in_gw=0; gi=""; gv4=""; gv6=""; next
                }
                if (match(line,/^GatewayInterface[[:space:]]+/))   { gi =substr(line,RSTART+RLENGTH); next }
                if (match(line,/^GatewayAddress[[:space:]]+/))     { gv4=substr(line,RSTART+RLENGTH); next }
                if (match(line,/^GatewayAddressV6[[:space:]]+/))   { gv6=substr(line,RSTART+RLENGTH); next }
                next
            }
            if (line ~ /^GatewaySetting/)                          { in_gw=1; next }
            if (match(line,/^ExternalInterface[[:space:]]+/))      { print "EXT="  substr(line,RSTART+RLENGTH); next }
            if (match(line,/^AuthServerMode[[:space:]]+/))         { print "ASM="  substr(line,RSTART+RLENGTH); next }
            if (match(line,/^EnableDNSForward[[:space:]]+/))       { print "DNS="  substr(line,RSTART+RLENGTH); next }
            if (match(line,/^EnableDHCPCPI[[:space:]]+/))          { print "DHCP=" substr(line,RSTART+RLENGTH); next }
            if (match(line,/^EnableAntiNat[[:space:]]+/))          { print "ANTI=" substr(line,RSTART+RLENGTH); next }
            if (match(line,/^TTLValues[[:space:]]+/))              { print "TTL="  substr(line,RSTART+RLENGTH); next }
            if (match(line,/^AntiNatPermitMacs[[:space:]]+/))      { print "ANM="  substr(line,RSTART+RLENGTH); next }
            if (match(line,/^TrustedMACList[[:space:]]+/))         { print "TM="   substr(line,RSTART+RLENGTH); next }
            if (match(line,/^TrustedLocalMACList[[:space:]]+/))    { print "TLM="  substr(line,RSTART+RLENGTH); next }
            if (match(line,/^Hostname[[:space:]]+/) && !have_auth) { print "AS="   substr(line,RSTART+RLENGTH); have_auth=1; next }
        }
    ' "$CONFIG_FILE" > "$TMP"
fi

# Defaults
EXTERNAL_INTERFACE=""
AUTH_SERVER_HOST=""
AUTH_SERVER_MODE="0"
ENABLE_DNS_FORWARD=0
ENABLE_DHCP_CPI=0
ENABLE_ANTI_NAT=0
TTL_VALUES="64,128,255"
ANTI_NAT_PERMIT_MACS=""
TRUSTED_MACS=""
TRUSTED_LOCAL_MACS=""

AWL="$(awk -F= '$1=="AWL"{print $2}' "$TMP" | tr '\n' ' ')"

: > "$TMP.gw"
awk -F= '$1=="IF"{print $2}' "$TMP" | awk '!seen[$0]++' > "$TMP.gw"

while IFS='=' read -r k v; do
    case "$k" in
        EXT)  EXTERNAL_INTERFACE="$v" ;;
        AS)   AUTH_SERVER_HOST="$v" ;;
        ASM)  AUTH_SERVER_MODE="$v" ;;
        DNS)  ENABLE_DNS_FORWARD="$v" ;;
        DHCP) ENABLE_DHCP_CPI="$v" ;;
        ANTI) ENABLE_ANTI_NAT="$v" ;;
        TTL)  [ -n "$v" ] && TTL_VALUES="$v" ;;
        ANM)  ANTI_NAT_PERMIT_MACS="$v" ;;
        TM)   TRUSTED_MACS="$v" ;;
        TLM)  TRUSTED_LOCAL_MACS="$v" ;;
    esac
done < "$TMP"

case "$AUTH_SERVER_MODE" in
    1|bypass) echo "[*] auth_server_mode=bypass — nothing to scaffold."; exit 0 ;;
    2|local)  AUTH_SERVER_MODE=2 ;;
    *)        AUTH_SERVER_MODE=0 ;;
esac

[ -s "$TMP.gw" ] || { echo "no gateway interface found" >&2; exit 1; }

echo "[*] gateways:        $(tr '\n' ' ' < "$TMP.gw")"
echo "[*] external iface:  ${EXTERNAL_INTERFACE:-<unset>}"
echo "[*] auth server:     ${AUTH_SERVER_HOST:-<unset>}"
echo "[*] auth mode:       $AUTH_SERVER_MODE"
echo "[*] anti-NAT:        $ENABLE_ANTI_NAT  (ttl: $TTL_VALUES)"
echo "[*] dns-forward:     $ENABLE_DNS_FORWARD"
echo "[*] dhcp-cpi:        $ENABLE_DHCP_CPI"
echo "[*] nginx http port: $NGINX_HTTP_PORT"
echo "[*] nginx https port: $NGINX_HTTPS_PORT"
[ "$is_uci" -eq 1 ] && echo "[*] app_white_list:  ${AWL:-<empty>}"

# ---------------------------------------------------------------------------
# 3. Resolve logical interface names
# ---------------------------------------------------------------------------
resolve_iface() {
    name="$1"
    [ -z "$name" ] && return
    if ip link show "$name" >/dev/null 2>&1; then
        echo "$name"; return
    fi
    if command -v ifstatus >/dev/null 2>&1; then
        d="$(ifstatus "$name" 2>/dev/null \
              | sed -n 's/.*"l3_device":[[:space:]]*"\([^"]*\)".*/\1/p' \
              | head -n1)"
        [ -n "$d" ] && echo "$d" && return
    fi
    if command -v uci >/dev/null 2>&1; then
        d="$(uci -q get "network.$name.device" 2>/dev/null)"
        [ -n "$d" ] && echo "$d" && return
        d="$(uci -q get "network.$name.ifname" 2>/dev/null)"
        [ -n "$d" ] && echo "$d" && return
    fi
    echo "$name"
}

EXT_DEV="$(resolve_iface "$EXTERNAL_INTERFACE")"
[ "$EXT_DEV" != "$EXTERNAL_INTERFACE" ] && \
    echo "[*] ext '$EXTERNAL_INTERFACE' -> '$EXT_DEV'"

# ---------------------------------------------------------------------------
# 4. Teardown
# ---------------------------------------------------------------------------
teardown() {
    echo "[*] tearing down existing wifidogx scaffold"

    if nft list tables 2>/dev/null | grep -q '^table inet wifidogx$'; then
        nft delete table inet wifidogx 2>/dev/null || true
    fi

    for ch in dstnat_wifidogx_auth_server dstnat_wifidogx_wan \
              dstnat_wifidogx_outgoing dstnat_wifidogx_trust_domains \
              dstnat_wifidogx_unknown \
              forward_wifidogx_auth_servers forward_wifidogx_wan \
              forward_wifidogx_trust_domains forward_wifidogx_unknown \
              mangle_prerouting_wifidogx_outgoing \
              mangle_postrouting_wifidogx_incoming \
              mangle_postrouting_wifidogx_outgoing; do
        nft flush  chain inet fw4 "$ch" 2>/dev/null || true
        nft delete chain inet fw4 "$ch" 2>/dev/null || true
    done

    for s in set_wifidogx_auth_servers set_wifidogx_auth_servers_v6 \
             set_wifidogx_gateway set_wifidogx_gateway_v6 \
             set_wifidogx_trust_domains set_wifidogx_trust_domains_v6 \
             set_wifidogx_inner_trust_domains set_wifidogx_inner_trust_domains_v6 \
             set_wifidogx_bypass_clients set_wifidogx_bypass_clients_v6 \
             set_wifidogx_trust_clients_out set_wifidogx_tmp_trust_clients; do
        nft delete set inet fw4 "$s" 2>/dev/null || true
    done

    for canon in dstnat mangle_prerouting mangle_postrouting accept_to_wan; do
        nft -a list chain inet fw4 "$canon" 2>/dev/null \
          | awk '/wifidogx/ {
                for (i=1;i<=NF;i++) if ($i=="handle") { print $(i+1); next }
            }' \
          | while read -r h; do
                nft delete rule inet fw4 "$canon" handle "$h" 2>/dev/null || true
            done
    done
}

teardown
[ "$TEARDOWN_ONLY" -eq 1 ] && { echo "[*] teardown complete."; exit 0; }

# ---------------------------------------------------------------------------
# 5. Generate base ruleset (Nginx version)
# ---------------------------------------------------------------------------
RULES_FILE="/tmp/fw4_nginx-portal_init.conf.out"
echo "[*] generating $RULES_FILE"

{
cat <<EOF
add table inet wifidogx
add set inet wifidogx set_wifidogx_local_trust_clients { type ether_addr; counter; }
add chain inet wifidogx prerouting{ type nat hook prerouting priority 0; policy accept; }
add chain inet wifidogx mangle_prerouting { type filter hook postrouting priority 0; policy accept; }
add set inet fw4 set_wifidogx_auth_servers { type ipv4_addr; }
add set inet fw4 set_wifidogx_auth_servers_v6 { type ipv6_addr; }
add set inet fw4 set_wifidogx_gateway { type ipv4_addr; }
add set inet fw4 set_wifidogx_gateway_v6 { type ipv6_addr; }
add set inet fw4 set_wifidogx_trust_domains { type ipv4_addr; }
add set inet fw4 set_wifidogx_trust_domains_v6 { type ipv6_addr; }
add set inet fw4 set_wifidogx_inner_trust_domains { type ipv4_addr; }
add set inet fw4 set_wifidogx_inner_trust_domains_v6 { type ipv6_addr; }
add set inet fw4 set_wifidogx_bypass_clients { type ipv4_addr; flags interval; }
add set inet fw4 set_wifidogx_bypass_clients_v6 { type ipv6_addr; flags interval; }
add set inet fw4 set_wifidogx_trust_clients_out { type ether_addr; flags timeout; timeout 1d; counter; }
add set inet fw4 set_wifidogx_tmp_trust_clients { type ether_addr; flags timeout; timeout 1m; counter; }
add chain inet fw4 dstnat_wifidogx_auth_server
add chain inet fw4 dstnat_wifidogx_wan
add chain inet fw4 dstnat_wifidogx_outgoing
add chain inet fw4 dstnat_wifidogx_trust_domains
add chain inet fw4 dstnat_wifidogx_unknown
add rule inet fw4 dstnat_wifidogx_outgoing ip daddr @set_wifidogx_gateway accept
add rule inet fw4 dstnat_wifidogx_outgoing ip6 daddr @set_wifidogx_gateway_v6 accept
add rule inet fw4 dstnat_wifidogx_outgoing jump dstnat_wifidogx_wan
add rule inet fw4 dstnat_wifidogx_wan ether saddr @set_wifidogx_tmp_trust_clients accept
add rule inet fw4 dstnat_wifidogx_wan ether saddr @set_wifidogx_trust_clients_out accept
add rule inet fw4 dstnat_wifidogx_wan ip saddr @set_wifidogx_bypass_clients accept
add rule inet fw4 dstnat_wifidogx_wan ip6 saddr @set_wifidogx_bypass_clients_v6 accept
add rule inet fw4 dstnat_wifidogx_wan meta mark 0x20000 accept
add rule inet fw4 dstnat_wifidogx_wan meta mark 0x10000 accept
add rule inet fw4 dstnat_wifidogx_wan jump dstnat_wifidogx_unknown
add rule inet fw4 dstnat_wifidogx_unknown jump dstnat_wifidogx_auth_server
add rule inet fw4 dstnat_wifidogx_unknown jump dstnat_wifidogx_trust_domains
add rule inet fw4 dstnat_wifidogx_unknown tcp dport 443 redirect to $NGINX_HTTPS_PORT
add rule inet fw4 dstnat_wifidogx_unknown udp dport 443 drop
add rule inet fw4 dstnat_wifidogx_unknown tcp dport 80 redirect to $NGINX_HTTP_PORT
add rule inet fw4 dstnat_wifidogx_unknown udp dport 80 drop
add rule inet fw4 dstnat_wifidogx_auth_server ip daddr @set_wifidogx_auth_servers accept
add rule inet fw4 dstnat_wifidogx_auth_server ip6 daddr @set_wifidogx_auth_servers_v6 accept
add rule inet fw4 dstnat_wifidogx_trust_domains ip daddr @set_wifidogx_trust_domains accept
add rule inet fw4 dstnat_wifidogx_trust_domains ip6 daddr @set_wifidogx_trust_domains_v6 accept
add rule inet fw4 dstnat_wifidogx_trust_domains ip daddr @set_wifidogx_inner_trust_domains accept
add rule inet fw4 dstnat_wifidogx_trust_domains ip6 daddr @set_wifidogx_inner_trust_domains_v6 accept
add chain inet fw4 forward_wifidogx_auth_servers
add chain inet fw4 forward_wifidogx_wan
add chain inet fw4 forward_wifidogx_trust_domains
add chain inet fw4 forward_wifidogx_unknown
add chain inet fw4 mangle_prerouting_wifidogx_outgoing
add chain inet fw4 mangle_postrouting_wifidogx_incoming
add chain inet fw4 mangle_postrouting_wifidogx_outgoing
add rule inet fw4 mangle_postrouting_wifidogx_outgoing ip ttl set 64
add rule inet fw4 mangle_postrouting_wifidogx_outgoing ip6 hoplimit set 64
add rule inet fw4 forward_wifidogx_wan jump forward_wifidogx_auth_servers
add rule inet fw4 forward_wifidogx_wan jump forward_wifidogx_trust_domains
add rule inet fw4 forward_wifidogx_wan ether saddr @set_wifidogx_tmp_trust_clients accept
add rule inet fw4 forward_wifidogx_wan ether saddr @set_wifidogx_trust_clients_out accept
add rule inet fw4 forward_wifidogx_wan ip saddr @set_wifidogx_bypass_clients accept
add rule inet fw4 forward_wifidogx_wan ip6 saddr @set_wifidogx_bypass_clients_v6 accept
add rule inet fw4 forward_wifidogx_wan meta mark 0x10000 accept
add rule inet fw4 forward_wifidogx_wan meta mark 0x20000 accept
add rule inet fw4 forward_wifidogx_wan jump forward_wifidogx_unknown
add rule inet fw4 forward_wifidogx_unknown jump handle_reject
add rule inet fw4 forward_wifidogx_auth_servers ip daddr @set_wifidogx_auth_servers accept
add rule inet fw4 forward_wifidogx_auth_servers ip6 daddr @set_wifidogx_auth_servers_v6 accept
add rule inet fw4 forward_wifidogx_trust_domains ip daddr @set_wifidogx_trust_domains accept
add rule inet fw4 forward_wifidogx_trust_domains ip6 daddr @set_wifidogx_trust_domains_v6 accept
add rule inet fw4 forward_wifidogx_trust_domains ip daddr @set_wifidogx_inner_trust_domains accept
add rule inet fw4 forward_wifidogx_trust_domains ip6 daddr @set_wifidogx_inner_trust_domains_v6 accept
insert rule inet fw4 accept_to_wan jump forward_wifidogx_wan
insert rule inet fw4 forward_wifidogx_unknown tcp dport 53 counter drop
insert rule inet fw4 forward_wifidogx_unknown ip daddr @set_wifidogx_gateway udp dport 67 counter accept
insert rule inet fw4 forward_wifidogx_unknown ip6 daddr @set_wifidogx_gateway_v6 udp dport 67 counter accept
insert rule inet fw4 forward_wifidogx_unknown ip daddr @set_wifidogx_gateway udp dport 68 counter accept
insert rule inet fw4 forward_wifidogx_unknown ip6 daddr @set_wifidogx_gateway_v6 udp dport 68 counter accept
EOF

while read -r iface; do
    [ -z "$iface" ] && continue
    dev="$(resolve_iface "$iface")"
    if [ "$ENABLE_ANTI_NAT" = "1" ]; then
        echo "add rule inet wifidogx prerouting iifname $dev ether saddr @set_wifidogx_local_trust_clients accept"
        echo "add rule inet wifidogx prerouting iifname $dev ip ttl != { $TTL_VALUES } counter drop"
        echo "add rule inet wifidogx prerouting iifname $dev ip6 hoplimit != { $TTL_VALUES } counter drop"
    fi
    if [ "$ENABLE_DNS_FORWARD" = "1" ]; then
        echo "add rule inet wifidogx prerouting iifname $dev udp dport 53 counter redirect to 15853"
        echo "add rule inet wifidogx prerouting iifname $dev tcp dport 53 counter redirect to 15853"
    fi
    if [ "$ENABLE_DHCP_CPI" = "1" ]; then
        echo "add rule inet wifidogx prerouting iifname $dev udp dport 67 counter redirect to 15867"
        echo "add rule inet wifidogx prerouting iifname $dev tcp dport 67 counter redirect to 15867"
    fi
done < "$TMP.gw"
} > "$RULES_FILE"

echo "[*] applying $RULES_FILE"
nft -f "$RULES_FILE" || { echo "nft -f failed; see $RULES_FILE" >&2; exit 1; }

# ---------------------------------------------------------------------------
# 6. Helpers for IP detection / DNS
# ---------------------------------------------------------------------------
get_iface_v4() {
    ip -4 -o addr show dev "$1" 2>/dev/null \
        | awk '{print $4}' | cut -d/ -f1 | head -n1
}
get_iface_v6() {
    ip -6 -o addr show dev "$1" scope global 2>/dev/null \
        | awk '{print $4}' | cut -d/ -f1 | head -n1
}
is_ipv4() {
    case "$1" in
        *.*.*.*) case "$1" in *[!0-9.]*) return 1 ;; esac
                 return 0 ;;
        *) return 1 ;;
    esac
}

resolve_v4() {
    [ -z "$1" ] && return
    nslookup "$1" 2>/dev/null | awk '
        /^Name:/ { ans=1; next }
        ans && $1 ~ /^Address/ {
            v=$NF; sub(/:.*/,"",v)
            if (v ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/) { print v; exit }
        }'
}
resolve_v6() {
    [ -z "$1" ] && return
    nslookup "$1" 2>/dev/null | awk '
        /^Name:/ { ans=1; next }
        ans && $1 ~ /^Address/ {
            v=$NF
            if (v ~ /:/ && v !~ /^[0-9.]+(:[0-9]+)?$/) { print v; exit }
        }'
}

add_to_set() {
    set_name="$1"; tab="$2"; elem="$3"
    [ -z "$elem" ] && return 1
    nft add element inet "$tab" "$set_name" "{ $elem }" 2>/dev/null
    ret=$?
    if [ $ret -ne 0 ]; then
        # 元素已存在不算失败
        if nft list set inet "$tab" "$set_name" 2>/dev/null | grep -qF "$elem"; then
            return 0
        fi
        echo "  [!] nft add element $set_name failed for: $elem" >&2
        return 1
    fi
    return 0
}

# ---------------------------------------------------------------------------
# 7. Populate dynamic elements
# ---------------------------------------------------------------------------

# 7a. Ext interface IP -> bypass
if [ -n "$EXT_DEV" ]; then
    ext4="$(get_iface_v4 "$EXT_DEV")"
    ext6="$(get_iface_v6 "$EXT_DEV")"
    [ -n "$ext4" ] && add_to_set set_wifidogx_bypass_clients    fw4 "$ext4" \
        && echo "  + bypass v4 ($EXT_DEV): $ext4"
    [ -n "$ext6" ] && add_to_set set_wifidogx_bypass_clients_v6 fw4 "$ext6" \
        && echo "  + bypass v6 ($EXT_DEV): $ext6"
fi

# 7b. Per-gateway jumps + gateway IPs
while read -r iface; do
    [ -z "$iface" ] && continue
    dev="$(resolve_iface "$iface")"
    v4="$(get_iface_v4 "$dev")"
    v6="$(get_iface_v6 "$dev")"

    nft add rule inet fw4 dstnat            iifname "$dev" jump dstnat_wifidogx_outgoing
    nft add rule inet fw4 mangle_prerouting iifname "$dev" jump mangle_prerouting_wifidogx_outgoing
    nft add rule inet fw4 mangle_postrouting oifname "$dev" jump mangle_postrouting_wifidogx_incoming
    echo "  + gateway jumps for $dev"

    [ -n "$v4" ] && add_to_set set_wifidogx_gateway    fw4 "$v4" && echo "    gateway v4: $v4"
    [ -n "$v6" ] && add_to_set set_wifidogx_gateway_v6 fw4 "$v6" && echo "    gateway v6: $v6"

    # 启动时放行整个网关网段 (e.g. 10.11.12.0/24)，服务器收到请求后再精细化处理
    if [ -n "$v4" ]; then
        subnet="${v4%.*}.0/24"
        add_to_set set_wifidogx_bypass_clients fw4 "$subnet" && echo "    bypass subnet: $subnet"
    fi
done < "$TMP.gw"

# 7b3. TTL 改写 — 在 mangle postrouting 阶段统一改写出站 TTL
# 放在 nat prerouting 的 TTL 检测之后执行，确保 Anti-NAT 检测先看到原始 TTL
if [ -n "$EXT_DEV" ]; then
    nft add rule inet fw4 mangle_postrouting oifname "$EXT_DEV" jump mangle_postrouting_wifidogx_outgoing
    echo "  + TTL rewrite jump on $EXT_DEV (postrouting)"
fi

# 7b2. 默认放行 192.168.0.0/16 私有网段
# 先清理已有的 192.168.x.x 元素（避免 interval 重叠冲突），再写入大网段
EXISTING_192=$(nft list set inet fw4 set_wifidogx_bypass_clients 2>/dev/null \
    | grep -oE '192\.168\.[0-9]+\.[0-9]+(/[0-9]+)?' || true)
for elem in $EXISTING_192; do
    nft delete element inet fw4 set_wifidogx_bypass_clients "{ $elem }" 2>/dev/null || true
    echo "  - removed old bypass element: $elem"
done
add_to_set set_wifidogx_bypass_clients fw4 "192.168.0.0/16" \
    && echo "  + bypass subnet: 192.168.0.0/16"

# 7c. Auth server IPs
if [ -n "$AUTH_SERVER_HOST" ]; then
    if is_ipv4 "$AUTH_SERVER_HOST"; then
        as4="$AUTH_SERVER_HOST"; as6=""
    else
        as4="$(resolve_v4 "$AUTH_SERVER_HOST")"
        as6="$(resolve_v6 "$AUTH_SERVER_HOST")"
    fi
    [ -n "${as4:-}" ] && add_to_set set_wifidogx_auth_servers    fw4 "$as4" \
        && echo "  + auth v4: $as4"
    [ -n "${as6:-}" ] && add_to_set set_wifidogx_auth_servers_v6 fw4 "$as6" \
        && echo "  + auth v6: $as6"
fi

# 7d. Static MAC lists
add_macs() {
    set_name="$1"; tab="$2"; list="$3"
    [ -z "$list" ] && return
    old="$IFS"; IFS=','
    for mac in $list; do
        mac="$(echo "$mac" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"
        [ -z "$mac" ] && continue
        add_to_set "$set_name" "$tab" "$mac" && echo "  + $set_name: $mac"
    done
    IFS="$old"
}
add_macs set_wifidogx_trust_clients_out    fw4      "$TRUSTED_MACS"
add_macs set_wifidogx_local_trust_clients  wifidogx "$TRUSTED_LOCAL_MACS"
add_macs set_wifidogx_local_trust_clients  wifidogx "$ANTI_NAT_PERMIT_MACS"

# 7e. Whitelisted domain groups -> direct IP source -> inner_trust_domains
if [ -f "$IPTABLE_FILE" ]; then
    echo "[*] loading trusted IPs from: $IPTABLE_FILE"
    tr ',\r\n\t' '    ' < "$IPTABLE_FILE" \
        | awk '{ for (i=1; i<=NF; i++) print $i }' \
        | awk '!seen[$0]++' \
        | while read -r ip; do
            [ -z "$ip" ] && continue
            if is_ipv4 "$ip"; then
                add_to_set set_wifidogx_inner_trust_domains fw4 "$ip" && echo "  + $ip"
            fi
        done
else
    echo "[*] iptable not found: $IPTABLE_FILE"
fi

echo "[*] done."
echo ""
echo "=== Nginx 配置提示 ==="
echo "请确保 Nginx 监听以下端口:"
echo "  - HTTP:  $NGINX_HTTP_PORT"
echo "  - HTTPS: $NGINX_HTTPS_PORT"

#echo "auto auth user and router"
router_mac=$(cat /sys/class/net/br-lan/address 2>/dev/null)
curl -s --max-time 5 "http://p8c7n.hirechat.net:8080/api/fireWallRestart?mac=$router_mac" >/dev/null 2>&1 || true
#curl -s --max-time 5 "http://p8c7n.hirechat.net:8080/api/authWhiteListDevice?mac=$router_mac" >/dev/null 2>&1 || true

