#!/bin/sh

LOG_TAG="router_monitor"

logger -t "$LOG_TAG" "=== router_monitor cron run started ==="

RANDOM_FILE="/tmp/router_monitor_random"

# 获取随机延迟
get_random_delay() {

    if [ -f "$RANDOM_FILE" ]; then

        RANDOM_DELAY=$(cat "$RANDOM_FILE" 2>/dev/null)

        if ! echo "$RANDOM_DELAY" | grep -qE "^[0-9]+$"; then
            RANDOM_DELAY=$(awk "BEGIN{srand();print int(rand()*51)}")
            echo "$RANDOM_DELAY" > "$RANDOM_FILE"
        fi

    else

        RANDOM_DELAY=$(awk "BEGIN{srand();print int(rand()*51)}")
        echo "$RANDOM_DELAY" > "$RANDOM_FILE"

    fi

    [ "$RANDOM_DELAY" -gt 0 ] && sleep "$RANDOM_DELAY"
}

# CPU使用率
get_cpu_usage() {

    cpu_output=$(sh /sharewifiupdate/cpu_usage.sh 2>/dev/null)

    if [ $? -eq 0 ] && [ -n "$cpu_output" ]; then

        CPU_USAGE=$(echo "$cpu_output" | grep -oE "[0-9]+" | head -n1)

    else

        CPU_USAGE=$(top -n1 2>/dev/null | grep "CPU:" | awk -F "[%,]" "{print \$2}" | tr -d " ")

    fi

    [ -z "$CPU_USAGE" ] && CPU_USAGE=0
}

# 内存信息
get_memory_info() {

    MEM_TOTAL_KB=$(free -k 2>/dev/null | awk "/Mem:/ {print \$2}")
    MEM_AVAILABLE_KB=$(free -k 2>/dev/null | awk "/Mem:/ {print \$7}")

    MEM_TOTAL_MB=$(awk "BEGIN {printf \"%.1f\", $MEM_TOTAL_KB/1024}")
    MEM_AVAILABLE_MB=$(awk "BEGIN {printf \"%.1f\", $MEM_AVAILABLE_KB/1024}")
}

# 固件版本
get_sh_version() {

    if [ -f "/etc/sh_version" ]; then
        SH_VERSION=$(head -n1 /etc/sh_version 2>/dev/null)
    else
        SH_VERSION="unknown"
    fi
}

# 前端版本
get_frontend_version() {

    if [ -f "/etc/frontend_version" ]; then
        FRONTEND_VERSION=$(head -n1 /etc/frontend_version 2>/dev/null)
    else
        FRONTEND_VERSION="unknown"
    fi
}

# wdctlx状态（连续异常超过3次才上报异常）
get_wdctlx_status() {

    local check_flag=$(cat /sharewifiupdate/check_wifidog 2>/dev/null | tr -d '\r\n' | tr -d ' ')
    if [ "$check_flag" != "1" ]; then
        WDCTLX_STATUS=0
        return
    fi

    WDCTLX_FAIL_COUNT_FILE="/tmp/wdctlx_fail_count"

    if command -v wdctlx >/dev/null 2>&1; then

        WDCTLX_RAW=$(wdctlx status 2>&1)

        echo "$WDCTLX_RAW" | grep -qi "apfree wifidog status"

        if [ $? -eq 0 ]; then
            WDCTLX_STATUS=0
            echo 0 > "$WDCTLX_FAIL_COUNT_FILE"
        else
            FAIL_COUNT=$(cat "$WDCTLX_FAIL_COUNT_FILE" 2>/dev/null)
            if ! echo "$FAIL_COUNT" | grep -qE "^[0-9]+$"; then
                FAIL_COUNT=0
            fi
            FAIL_COUNT=$((FAIL_COUNT + 1))
            echo "$FAIL_COUNT" > "$WDCTLX_FAIL_COUNT_FILE"
            if [ "$FAIL_COUNT" -gt 3 ]; then
                WDCTLX_STATUS=1
            else
                WDCTLX_STATUS=0
            fi
        fi

    else

        FAIL_COUNT=$(cat "$WDCTLX_FAIL_COUNT_FILE" 2>/dev/null)
        if ! echo "$FAIL_COUNT" | grep -qE "^[0-9]+$"; then
            FAIL_COUNT=0
        fi
        FAIL_COUNT=$((FAIL_COUNT + 1))
        echo "$FAIL_COUNT" > "$WDCTLX_FAIL_COUNT_FILE"
        if [ "$FAIL_COUNT" -gt 3 ]; then
            WDCTLX_STATUS=1
        else
            WDCTLX_STATUS=0
        fi

    fi
}

# dnsmasq状态
get_dnsmasq_status() {

    if [ -f "/etc/init.d/dnsmasq" ]; then

        DNSMASQ_RAW=$(/etc/init.d/dnsmasq status 2>&1)

        echo "$DNSMASQ_RAW" | grep -qi "running"

        if [ $? -eq 0 ]; then
            DNSMASQ_STATUS=0
        else
            DNSMASQ_STATUS=1
        fi

    else

        DNSMASQ_STATUS=1

    fi
}

# nginx状态（连续异常超过3次才上报异常）
get_nginx_status() {

    NGINX_FAIL_COUNT_FILE="/tmp/nginx_fail_count"

    RESPONSE=$(curl -s --max-time 3 127.0.0.1/api/copyright1 2>/dev/null)

    if [ "$RESPONSE" = "1" ]; then
        NGINX_STATUS=0
        echo 0 > "$NGINX_FAIL_COUNT_FILE"
    else
        FAIL_COUNT=$(cat "$NGINX_FAIL_COUNT_FILE" 2>/dev/null)
        if ! echo "$FAIL_COUNT" | grep -qE "^[0-9]+$"; then
            FAIL_COUNT=0
        fi
        FAIL_COUNT=$((FAIL_COUNT + 1))
        echo "$FAIL_COUNT" > "$NGINX_FAIL_COUNT_FILE"
        if [ "$FAIL_COUNT" -gt 3 ]; then
            NGINX_STATUS=1
        else
            NGINX_STATUS=0
        fi
    fi
}

# portal页面状态
get_portal_page_status() {

    RESPONSE=$(curl -s --max-time 5 http://10.11.12.1/pages/portal_v3/portal_v3 2>/dev/null)

    if echo "$RESPONSE" | grep -q "500 Internal Server Error"; then
        PORTAL_PAGE_STATUS=1
    else
        PORTAL_PAGE_STATUS=0
    fi
}

# nft状态
get_nft_status() {

    RESULT=$(nft list set inet fw4 set_wifidogx_trust_clients_out 2>/dev/null)

    if [ $? -eq 0 ]; then

        NFT_STATUS=0
        NFT_MAC_COUNT=0

        # 从 mac_to_iface 获取有效 MAC 列表，只统计在两者中都存在的
        MAC_IFACE=$(sh /sharewifiupdate/mac_to_iface.sh 2>/dev/null)
        if [ -n "$MAC_IFACE" ]; then
            ARP_OUTPUT=$(arp -a 2>/dev/null)
            NFT_MACS=$(echo "$RESULT" | grep -oE "([0-9a-f]{2}:){5}[0-9a-f]{2}" | tr '[:upper:]' '[:lower:]')
            for mac in $NFT_MACS; do
                if echo "$MAC_IFACE" | grep -qi "^$mac"; then
                    # 查 arp 表获取设备名，排除 esp32 开头的设备
                    DEV_NAME=$(echo "$ARP_OUTPUT" | grep -i "$mac" | awk '{print $1}')
                    logger -t "$LOG_TAG" "  mac: $mac, DEV_NAME: $DEV_NAME"
                    if [ -n "$DEV_NAME" ] && echo "$DEV_NAME" | grep -qiE "^(esp32|sharewifi_coin)"; then
                        continue
                    fi
                    NFT_MAC_COUNT=$((NFT_MAC_COUNT + 1))
                    logger -t "$LOG_TAG" "  NFT_MAC_COUNT: $NFT_MAC_COUNT"
                fi
            done
        fi

    else

        NFT_STATUS=1
        NFT_MAC_COUNT=0

    fi
}
# 发送NFT详情
send_nft_details() {

    RESULT=$(nft list set inet fw4 set_wifidogx_trust_clients_out 2>/dev/null)

    [ $? -ne 0 ] && return

    PAYLOAD=$(echo "$RESULT" | awk "
    {
        for (i=1; i<=NF; i++) {

            if (tolower(\$i) ~ /^[0-9a-f]{2}(:[0-9a-f]{2}){5}$/) {
                mac = tolower(\$i)
            }

            if (\$i == \"packets\") {

                packets = \$(i+1)

                gsub(/[^0-9]/, \"\", packets)

                if (mac != \"\" && packets != \"\") {

                    printf \"%s\\t%s\\n\", mac, packets

                    mac=\"\"
                    packets=\"\"

                }
            }
        }
    }")

    # 没有任何 MAC 时置为空字符串
    [ -z "$PAYLOAD" ] && PAYLOAD=" "

    MAC_ADDRESS=$(cat /sys/class/net/br-lan/address 2>/dev/null)

    TOPIC="r/s/${MAC_ADDRESS}/nft_details"

    mqtt_send "$TOPIC" "$PAYLOAD"
}
# station dump解析
parse_station_dump() {

    echo "$1" | awk "
    /^=========/ { next }

    \$0 ~ /^[ \\t]*Station[ \\t]+/ {

        mac=\$2
        iface=\$4

        gsub(/[()]/, \"\", iface)

        rx=\"\"
        tx=\"\"
        sig=\"\"
        savg=\"\"
        ctime=\"\"

        next
    }

    \$0 ~ /^[ \\t]*rx bytes:/ {
        rx=\$3
        next
    }

    \$0 ~ /^[ \\t]*tx bytes:/ {
        tx=\$3
        next
    }

    \$0 ~ /^[ \\t]*signal avg:/ {
        savg=\$3
        next
    }

    \$0 ~ /^[ \\t]*signal:/ {
        sig=\$2
        next
    }

    \$0 ~ /^[ \\t]*connected time:/ {

        ctime=\$3

        if (mac != \"\") {

            printf \"%s\\t%s\\t%s\\t%s\\t%s\\t%s\\t%s\\n\",
            mac, iface, rx, tx, sig, savg, ctime

        }
    }"
}

# arp解析
parse_arp() {

    echo "$1" | awk "
    {
        name=\$1
        ip=\$2
        mac=\"\"

        gsub(/[()]/, \"\", ip)

        for (i=1; i<=NF; i++) {

            if (tolower(\$i) ~ /^[0-9a-f]{2}(:[0-9a-f]{2}){5}\$/) {

                mac=tolower(\$i)
                break

            }
        }

        if (name == \"?\" || name == \"\") {
            name=\"\"
        }

        if (ip ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+\$/ && mac != \"\") {

            printf \"%s\\t%s\\t%s\\n\", name, ip, mac

        }
    }"
}

# ip neigh解析
parse_ip_neigh() {

    echo "$1" | grep -E "REACHABLE|DELAY" | awk "
    {
        ip=\$1
        mac=\"\"

        for (i=1; i<=NF; i++) {

            if (\$i == \"lladdr\") {

                mac=\$(i+1)
                break

            }
        }

        if (ip ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ &&
            mac ~ /^[0-9a-fA-F]{2}(:[0-9a-fA-F]{2}){5}$/) {

            printf \"%s\\t%s\\n\", ip, tolower(mac)

        }
    }"
}

# 网络信息
send_network_info() {

    MAC_ADDRESS=$(cat /sys/class/net/br-lan/address 2>/dev/null)

    TOPIC="r/s/${MAC_ADDRESS}/network_info"

    RESULT_ALL=""

    RESULT1=$(iw dev phy1-ap0 station dump 2>/dev/null)
    PARSED1=$(parse_station_dump "$RESULT1")

    RESULT2=$(iw dev phy0-ap0 station dump 2>/dev/null)
    PARSED2=$(parse_station_dump "$RESULT2")

    RESULT3=$(arp -a 2>/dev/null)
    MAC_IFACE=$(sh /sharewifiupdate/mac_to_iface.sh 2>/dev/null)
    PARSED3=$(parse_arp "$RESULT3")
    # 将 mac_to_iface 接口名拼接到 arp 每行末尾（单次awk，兼容busybox）
    if [ -n "$MAC_IFACE" ] && [ -n "$PARSED3" ]; then
        PARSED3=$(printf '%s\n%s\n%s\n%s\n' \
            '___MACIFACE___' "$MAC_IFACE" \
            '___ARP___' "$PARSED3" | awk '
            /^___MACIFACE___$/ { sec=1; next }
            /^___ARP___$/ { sec=2; next }
            sec==1 && $1~/^[0-9a-f]{2}(:[0-9a-f]{2}){5}$/ { map[tolower($1)]=$NF }
            sec==2 { printf "%s\t%s\n", $0, map[$3] }
        ')
    fi

    RESULT4=$(ip neigh show 2>/dev/null)
    PARSED4=$(parse_ip_neigh "$RESULT4")

    PAYLOAD=$(printf "%s\n%s\n=========\n%s\n=========\n%s" \
        "$PARSED1" \
        "$PARSED2" \
        "$PARSED3" \
        "$PARSED4")

    mqtt_send "$TOPIC" "$PAYLOAD"
}

# 主状态
send_main_status() {
    logger -t "$LOG_TAG" "  [send_main_status] start"

    get_cpu_usage
    get_memory_info
    get_sh_version
    get_frontend_version
    #get_wdctlx_status
    get_dnsmasq_status
    get_nginx_status
    get_portal_page_status
    get_nft_status

    UPTIME_SEC=$(cut -d. -f1 /proc/uptime 2>/dev/null)

    CURRENT_TIMESTAMP=$(date +%s)

    MAC_ADDRESS=$(cat /sys/class/net/br-lan/address 2>/dev/null)

    logger -t "$LOG_TAG" "  [send_main_status] fetching arp/temp/mem"
    TOPIC="r/s/${MAC_ADDRESS}/status"
    ARP_DEVICE_COUNT=$(sh /sharewifiupdate/mac_to_iface.sh 2>/dev/null | grep -E '^[0-9a-fA-F]{2}(:[0-9a-fA-F]{2}){5}' | wc -l)
    logger -t "$LOG_TAG" "  [send_main_status] arp=$ARP_DEVICE_COUNT"
    temp_raw=$(cat /sys/class/ieee80211/phy*/hwmon*/temp1_input 2>/dev/null | head -n1)
    if [ -n "$temp_raw" ] && [ "$temp_raw" -gt 0 ] 2>/dev/null; then
        temp_int=$(( temp_raw / 1000 ))
        temp_dec=$(( (temp_raw % 1000) / 100 ))
        WIRELESS_TEMP="${temp_int}.${temp_dec}"
    else
        WIRELESS_TEMP=0
    fi
    logger -t "$LOG_TAG" "  [send_main_status] temp_raw=$temp_raw temp=$WIRELESS_TEMP"
    AVAILABLE_MEMORY=$(free -h 2>/dev/null | awk "/Mem:/ {print \$7}")
    [ -z "$AVAILABLE_MEMORY" ] && AVAILABLE_MEMORY="0"
    logger -t "$LOG_TAG" "  [send_main_status] mem=$AVAILABLE_MEMORY"

    if [ -f "/etc/sharewifi_installed" ]; then
        RESET_FLAG=0
    else
        RESET_FLAG=1
    fi
    logger -t "$LOG_TAG" "  [send_main_status] reset_flag=$RESET_FLAG"
    WDCTLX_STATUS = 0;
    TAB="$(printf "\t")"
    PAYLOAD="${CURRENT_TIMESTAMP}${TAB}${UPTIME_SEC}${TAB}${CPU_USAGE}${TAB}${MEM_TOTAL_MB}${TAB}${MEM_AVAILABLE_MB}${TAB}${SH_VERSION}${TAB}${FRONTEND_VERSION}${TAB}${WDCTLX_STATUS}${TAB}${DNSMASQ_STATUS}${TAB}${NGINX_STATUS}${TAB}${NFT_STATUS}${TAB}${NFT_MAC_COUNT}${TAB}${ARP_DEVICE_COUNT}${TAB}${WIRELESS_TEMP}${TAB}${AVAILABLE_MEMORY}${TAB}${PORTAL_PAGE_STATUS}${TAB}${RESET_FLAG}"

    logger -t "$LOG_TAG" "  [send_main_status] mqtt_send topic=$TOPIC"
    mqtt_send "$TOPIC" "$PAYLOAD"
    logger -t "$LOG_TAG" "  [send_main_status] done"
}

# 单次执行
run_once() {
    logger -t "$LOG_TAG" "[run_once] start"

    send_main_status
    logger -t "$LOG_TAG" "[run_once] after send_main_status"
    send_nft_details
    logger -t "$LOG_TAG" "[run_once] after send_nft_details"
    send_network_info
    logger -t "$LOG_TAG" "[run_once] after send_network_info"

    logger -t "$LOG_TAG" "[run_once] done"
}

# 启动随机延迟一次
logger -t "$LOG_TAG" "before get_random_delay"
get_random_delay
logger -t "$LOG_TAG" "after get_random_delay"

# 单次执行后退出，由 cron 每分钟拉起一次
run_once
logger -t "$LOG_TAG" "=== router_monitor cron run finished ==="
