#!/bin/sh

# One line for the backend: 0 = healthy, 1 = wireless problem, 2 = unable to check.
# This script only reads state. It never changes the wireless configuration.

LC_ALL=C
export LC_ALL

finish() {
	printf '%s\n' "$1"
	exit 0
}

for command in uci ubus jsonfilter iw; do
	command -v "$command" >/dev/null 2>&1 || finish 2
done

config="$(uci -q show wireless 2>/dev/null)" || finish 2
[ -n "$config" ] || finish 2

status="$(ubus -S call network.wireless status 2>/dev/null)" || finish 2
[ -n "$status" ] || finish 2

radios="$(printf '%s\n' "$config" | sed -n 's/^wireless\.\([^.=]*\)=wifi-device$/\1/p')"
ifaces="$(printf '%s\n' "$config" | sed -n 's/^wireless\.\([^.=]*\)=wifi-iface$/\1/p')"
[ -n "$radios" ] || finish 2

for radio in $radios; do
	radio_disabled="$(uci -q get "wireless.$radio.disabled" 2>/dev/null)"
	configured_ap=0
	want_ap=0
	want_sta=0
	for iface in $ifaces; do
		[ "$(uci -q get "wireless.$iface.device" 2>/dev/null)" = "$radio" ] || continue
		iface_disabled="$(uci -q get "wireless.$iface.disabled" 2>/dev/null)"
		case "$(uci -q get "wireless.$iface.mode" 2>/dev/null)" in
			ap|'')
				configured_ap=$((configured_ap + 1))
				[ "$iface_disabled" = 1 ] || want_ap=$((want_ap + 1))
				;;
			sta)
				[ "$iface_disabled" = 1 ] || want_sta=$((want_sta + 1))
				;;
		esac
	done

	# If a radio has APs configured but every SSID is disabled, report it.
	[ "$configured_ap" -gt 0 ] && [ "$want_ap" -eq 0 ] && finish 1
	if [ "$radio_disabled" = 1 ]; then
		[ "$want_ap" -gt 0 ] || [ "$want_sta" -gt 0 ] && finish 1
		continue
	fi

	[ "$want_ap" -gt 0 ] || [ "$want_sta" -gt 0 ] || continue

	up="$(jsonfilter -s "$status" -e "@.$radio.up" 2>/dev/null)" || finish 2
	pending="$(jsonfilter -s "$status" -e "@.$radio.pending" 2>/dev/null)" || finish 2
	[ -n "$up" ] || finish 2
	[ "$pending" = true ] && finish 2
	[ "$up" = true ] || finish 1

	names="$(jsonfilter -s "$status" -e "@.$radio.interfaces[*].ifname" 2>/dev/null)" || finish 2
	actual_ap=0
	actual_sta=0
	for ifname in $names; do
		info="$(iw dev "$ifname" info 2>/dev/null)" || finish 1
		type="$(printf '%s\n' "$info" | awk '$1 == "type" { print $2; exit }')"
		case "$type" in
			AP)
				# An AP interface without a configured SSID is not broadcasting.
				printf '%s\n' "$info" | awk '$1 == "ssid" { found = 1 } END { exit !found }' || finish 1
				actual_ap=$((actual_ap + 1))
				;;
			managed)
				actual_sta=$((actual_sta + 1))
				link="$(iw dev "$ifname" link 2>/dev/null)" || finish 2
				case "$link" in
					*'Connected to '*) ;;
					*) finish 1 ;;
				esac
				;;
		esac
	done

	[ "$actual_ap" -ge "$want_ap" ] || finish 1
	[ "$actual_sta" -ge "$want_sta" ] || finish 1
done

finish 0
