#!/bin/sh
#opkg install --force-reinstall /sharewifiupdate/apfree-wifidog_master-r1_mipsel_24kc.ipk
opkg install --force-reinstall /sharewifiupdate/mt7981-wo-firmware_20240513-r1_aarch64_cortex-a53.ipk

sleep 1
/etc/init.d/dnsmasq restart
sleep 1
/etc/init.d/uhttpd restart
sleep 1
/etc/init.d/nginx restart
sleep 1

#sleep 1
#/etc/init.d/network restart
chmod 777 /www/cgi-bin/*
chmod 777 /www/portal.html
chmod 777 /www/internet_offline.html
chmod 777 /www/index.html
chmod 744 /sharewifiupdate/kickOffline.sh
chmod 744 /sharewifiupdate/wifiDogReload.sh
chmod 744 /sharewifiupdate/heartbeat.sh
chmod 744 /sharewifiupdate/updateDNS.sh
chmod 744 /sharewifiupdate/fixFw4WAN_Bug.sh
chmod 744 /sharewifiupdate/ubinfoCheck.sh
chmod 744 /sharewifiupdate/mqtt-led.sh
chmod 744 /etc/config/clean_log.sh

chmod +x /sharewifiupdate/reboot.sh
chmod +x /sharewifiupdate/del_dns_entry.sh 
chmod +x /sharewifiupdate/del_bt_rule
chmod +x /sharewifiupdate/limit_bandwidth.sh
chmod +x /sharewifiupdate/remove_limit_bandwidth.sh
chmod +x /sharewifiupdate/list_limit_bandwidth.sh
chmod +x /sharewifiupdate/getSpeed.sh
chmod +x /sharewifiupdate/cpu_usage.sh
chmod +x /sharewifiupdate/fix_router.sh
chmod +x /sharewifiupdate/del_bypass_user
chmod +x /etc/init.d/updateDNS
chmod +x /sharewifiupdate/check_portal_wifidog.sh
chmod +x /www/cgi-bin/cmd
chmod +x /etc/init.d/*
chmod +x /sharewifiupdate/wifidog-update/*
chmod +x /sharewifiupdate/admin-ssid.sh
sleep 1
/etc/init.d/dnsmasq reload
sleep 1
/etc/init.d/uhttpd restart
sleep 1
/etc/init.d/nginx restart
sleep 1
/etc/init.d/wifidogx stop
/etc/init.d/wifidogx start

/etc/init.d/https-dns-proxy stop
/etc/init.d/https-dns-proxy disable
/etc/init.d/odhcpd stop
/etc/init.d/odhcpd disable

# /etc/init.d/openwisp-config  disable
# /etc/init.d/openwisp-config  stop


/etc/init.d/updateDNS start
/etc/init.d/updateDNS enable

/etc/init.d/router_monitor stop
/etc/init.d/router_monitor disable

chmod +x /etc/init.d/unpack_web
/etc/init.d/unpack_web start
/etc/init.d/unpack_web enable

#/etc/init.d/init_firewall start
/etc/init.d/init_firewall enable
/etc/init.d/firewall restart

# chmod +x /etc/init.d/mqtt_init_led
# /etc/init.d/mqtt_init_led start
# /etc/init.d/mqtt_init_led enable

# chmod +x /etc/init.d/init_intreface 
# /etc/init.d/init_intreface  start
# /etc/init.d/init_intreface  enable

chmod +x /etc/init.d/change_wan_mac 
/etc/init.d/change_wan_mac  disable
/etc/init.d/wifidogx stop
/etc/init.d/wifidogx disable
# www挂载到tmp目录
mkdir -p /tmp/www
echo "/www /tmp/www none defaults,bind 0 0" >> /etc/fstab mount -a

uci set wireless.radio0.channel='auto'
uci set wireless.radio1.channel='auto'
uci set wireless.radio1.country='US'
uci set wireless.radio1.mu_beamformer='1'
uci set wireless.radio1.mu_beamformer='1'
uci set wireless.radio1.frag='1000'
uci set wireless.radio1.beacon_int='20'
uci set wireless.default_radio1.isolate='1'
uci set wireless.radio0.country='US'
uci set wireless.radio0.mu_beamformer='1'
uci set wireless.radio0.frag='1000'
uci set wireless.radio0.beacon_int='20'
uci set wireless.default_radio0.isolate='1'
uci set wireless.default_radio0.txpower='33'
uci set wireless.default_radio1.txpower='33'
uci set wireless.default_radio1.disassoc_low_ack='1'
uci set wireless.default_radio0.disassoc_low_ack='1'
uci add_list wireless.radio1.channels='36'
uci add_list wireless.radio1.channels='40'
uci add_list wireless.radio1.channels='44'
uci add_list wireless.radio1.channels='48'
uci add_list wireless.radio1.channels='52'
uci add_list wireless.radio1.channels='56'
uci add_list wireless.radio1.channels='60'
uci add_list wireless.radio1.channels='64'
uci add_list wireless.radio1.channels='149'
uci add_list wireless.radio1.channels='153'
uci add_list wireless.radio1.channels='157'
uci add_list wireless.radio1.channels='161'
uci add_list wireless.radio1.channels='165'
uci delete wireless.radio0.distance
uci delete wireless.radio1.distance
uci commit wireless
wifi reload

#wdctlx add domain xendit.co
#wdctlx add domain checkout.xendit.co



sh  /sharewifiupdate/fixFw4WAN_Bug.sh
sh  /sharewifiupdate/google_diag.sh
# sh /sharewifiupdate/wifiDogReload.sh


rm -r /sharewifiupdate/download/*
rm /root/log/messages
sync


# 先检查是否已存在该路径配置
if ! uci show firewall | grep -q '/sharewifiupdate/wifidog_update/aw-fw-setup.sh'; then
    # 只有在不存在时才执行添加操作
    uci set firewall.@defaults[0].flow_offloading_hw='0'
    uci -q set firewall.mywifidog_include=include
    uci -q set firewall.mywifidog_include.path='/sharewifiupdate/wifidog_update/aw-fw-setup.sh'
    uci -q set firewall.mywifidog_include.type='script'
    uci -q set firewall.mywifidog_include.fw4_compatible='1'
    uci commit firewall
    service firewall restart
    echo "配置已添加并重启防火墙"
else
    echo "配置已存在，无需重复添加"
fi










