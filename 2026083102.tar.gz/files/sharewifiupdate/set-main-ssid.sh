#!/bin/sh
#
# 模式 1：设置加密主 WiFi，并删除 Owner/Admin WiFi。
#   sh set-main-ssid.sh <主SSID> <主SSID密码>
#   sh set-main-ssid.sh --ssid <主SSID> --password <主SSID密码>
#
# 模式 2：设置开放主 WiFi，删除 Admin，并创建独立的加密 Owner WiFi。
#   sh set-main-ssid.sh <主SSID（不加密）> <Owner SSID> <Owner密码>
#

set -e

OPERATION=""
MAIN_SSID=""
MAIN_PASSWORD=""
OWNER_SSID=""
OWNER_PASSWORD=""
OWNER_IFACE_NAME="owner"
OWNER_PWD_FILE="/etc/ShareWifi_owner_pwd.txt"
LEGACY_IFACE_NAME="admin"
LEGACY_PWD_FILE="/etc/ShareWifi_admin_pwd.txt"
SETUP_DONE="/etc/admin-ssid-setup.done"
EXPLICIT_OPERATION=""
NEW_SSID=""
NEW_SSID_2G=""
NEW_SSID_5G=""
NEW_PASSWORD=""
NEW_PASS_2G=""
NEW_PASS_5G=""
NEW_GATEWAY=""
OWNER_SSID_2G=""
OWNER_SSID_5G=""
OWNER_PASS_2G=""
OWNER_PASS_5G=""
OWNER_GATEWAY_REQUESTED=""

usage() {
    echo "用法:" >&2
    echo "  $0 <主SSID> <主SSID密码>" >&2
    echo "  $0 --ssid <主SSID> --password <主SSID密码>" >&2
    echo "  $0 <主SSID（不加密）> <Owner SSID> <Owner密码>" >&2
    echo "  $0                         # 自动创建 Owner" >&2
    echo "  $0 --guest-disable         # 关闭 Guest SSID（保留配置）" >&2
    echo "  $0 --guest-enable          # 开启 Guest SSID" >&2
    echo "  $0 --guest-modify --ssid <名>" >&2
    echo "  $0 --owner-disable         # 关闭 Owner SSID（保留配置）" >&2
    echo "  $0 --owner-enable          # 开启 Owner SSID" >&2
    echo "  $0 --owner-modify [--ssid <名>] [--ssid2g <名>] [--ssid5g <名>]" >&2
    echo "                [--pass <密码>] [--pass2g <密码>] [--pass5g <密码>]" >&2
    echo "                [--gateway <IP>]" >&2
    echo "  $0 --teardown              # 删除 Owner 和旧版 Admin" >&2
}

request_operation() {
    REQUESTED="$1"
    if [ -n "$EXPLICIT_OPERATION" ] && [ "$EXPLICIT_OPERATION" != "$REQUESTED" ]; then
        echo "错误：不能同时指定多个操作。" >&2
        exit 1
    fi
    EXPLICIT_OPERATION="$REQUESTED"
}

validate_ssid() {
    VALUE="$1"
    LABEL="$2"
    VALUE_LEN=$(printf '%s' "$VALUE" | wc -c | tr -d ' ')
    if [ -z "$VALUE" ]; then
        echo "错误：${LABEL} 不能为空。" >&2
        exit 1
    fi
    if [ "$VALUE_LEN" -gt 32 ]; then
        echo "错误：${LABEL} 不能超过 32 字节。" >&2
        exit 1
    fi
}

validate_password() {
    VALUE="$1"
    LABEL="$2"
    VALUE_LEN=$(printf '%s' "$VALUE" | wc -c | tr -d ' ')
    if [ "$VALUE_LEN" -lt 8 ] || [ "$VALUE_LEN" -gt 63 ]; then
        echo "错误：${LABEL}长度必须为 8～63 个字符。" >&2
        exit 1
    fi
}

find_main_ifaces() {
    MAIN_IFACES=""
    EXISTING_IFACES=$(uci show wireless 2>/dev/null | awk -F'[.=]' '/=wifi-iface/{print $2}')
    for sec in $EXISTING_IFACES; do
        CUR_NET=$(uci -q get wireless."${sec}".network || echo "")
        case " $CUR_NET " in
            *" lan "*) MAIN_IFACES="${MAIN_IFACES} ${sec}" ;;
        esac
    done

    if [ -z "$MAIN_IFACES" ]; then
        echo "错误：未找到绑定到 lan 的主 WiFi 接口，未修改任何配置。" >&2
        exit 1
    fi
}

delete_managed_wifi() {
    TARGET_NETWORK="$1"
    TARGET_LABEL="$2"
    echo "[*] 删除旧 ${TARGET_LABEL} WiFi..."

    # 匿名 section 删除后编号会前移，因此每次重新查询并只删除一个。
    while :; do
        TARGET_SEC=""
        TARGET_SSID_CURRENT=""
        CURRENT_IFACES=$(uci show wireless 2>/dev/null | awk -F'[.=]' '/=wifi-iface/{print $2}')
        for sec in $CURRENT_IFACES; do
            CUR_NET=$(uci -q get wireless."${sec}".network || echo "")
            case " $CUR_NET " in
                *" ${TARGET_NETWORK} "*)
                    TARGET_SEC="$sec"
                    TARGET_SSID_CURRENT=$(uci -q get wireless."${sec}".ssid || echo "")
                    break
                    ;;
            esac
        done
        [ -n "$TARGET_SEC" ] || break
        echo "  删除 wifi-iface: ${TARGET_SEC} (SSID=${TARGET_SSID_CURRENT})"
        uci delete wireless."${TARGET_SEC}"
    done
}

delete_managed_services() {
    TARGET_NETWORK="$1"

    for net_sec in "${TARGET_NETWORK}" "${TARGET_NETWORK}_br"; do
        if uci -q get network."${net_sec}" >/dev/null 2>&1; then
            echo "  删除 network: ${net_sec}"
            uci delete network."${net_sec}"
        fi
    done

    if uci -q get dhcp."${TARGET_NETWORK}" >/dev/null 2>&1; then
        echo "  删除 dhcp: ${TARGET_NETWORK}"
        uci delete dhcp."${TARGET_NETWORK}"
    fi

    while :; do
        TARGET_ZONE=""
        FW_ZONES=$(uci show firewall 2>/dev/null | awk -F'[.=]' '/=zone$/{print $2}')
        for zone in $FW_ZONES; do
            ZONE_NAME=$(uci -q get firewall."${zone}".name || echo "")
            if [ "$ZONE_NAME" = "$TARGET_NETWORK" ]; then
                TARGET_ZONE="$zone"
                break
            fi
        done
        [ -n "$TARGET_ZONE" ] || break
        echo "  删除 firewall zone: ${TARGET_ZONE}"
        uci delete firewall."${TARGET_ZONE}"
    done

    # 清理其他 zone 中可能残留的 network 引用。
    FW_ZONES=$(uci show firewall 2>/dev/null | awk -F'[.=]' '/=zone$/{print $2}')
    for zone in $FW_ZONES; do
        uci -q del_list firewall."${zone}".network="${TARGET_NETWORK}" || true
    done

    while :; do
        TARGET_FORWARDING=""
        FW_FORWARDINGS=$(uci show firewall 2>/dev/null | awk -F'[.=]' '/=forwarding$/{print $2}')
        for forwarding in $FW_FORWARDINGS; do
            FORWARDING_SRC=$(uci -q get firewall."${forwarding}".src || echo "")
            if [ "$FORWARDING_SRC" = "$TARGET_NETWORK" ]; then
                TARGET_FORWARDING="$forwarding"
                break
            fi
        done
        [ -n "$TARGET_FORWARDING" ] || break
        echo "  删除 firewall forwarding: ${TARGET_FORWARDING}"
        uci delete firewall."${TARGET_FORWARDING}"
    done
}

delete_managed_state_files() {
    rm -f /etc/admin-ssid-setup.done /etc/ShareWifi_admin_pwd.txt "$OWNER_PWD_FILE"
}

delete_aw_firewall_include() {
    while :; do
        TARGET_INCLUDE=""
        FW_INCLUDES=$(uci show firewall 2>/dev/null | awk -F'[.=]' '/=include$/{print $2}')
        for include_sec in $FW_INCLUDES; do
            INCLUDE_PATH=$(uci -q get firewall."${include_sec}".path || echo "")
            if [ "$INCLUDE_PATH" = "/sharewifiupdate/wifidog_update/aw-fw-setup.sh" ]; then
                TARGET_INCLUDE="$include_sec"
                break
            fi
        done
        [ -n "$TARGET_INCLUDE" ] || break
        echo "  删除 firewall include: ${TARGET_INCLUDE} (/sharewifiupdate/wifidog_update/aw-fw-setup.sh)"
        uci delete firewall."${TARGET_INCLUDE}"
    done
}

ensure_aw_firewall_include() {
    TARGET_INCLUDE=""
    FW_INCLUDES=$(uci show firewall 2>/dev/null | awk -F'[.=]' '/=include$/{print $2}')
    for include_sec in $FW_INCLUDES; do
        INCLUDE_PATH=$(uci -q get firewall."${include_sec}".path || echo "")
        if [ "$INCLUDE_PATH" = "/sharewifiupdate/wifidog_update/aw-fw-setup.sh" ]; then
            TARGET_INCLUDE="$include_sec"
            break
        fi
    done

    if [ -z "$TARGET_INCLUDE" ]; then
        TARGET_INCLUDE=$(uci add firewall include)
        echo "  添加 firewall include: ${TARGET_INCLUDE}"
    else
        echo "  firewall include 已存在: ${TARGET_INCLUDE}"
    fi

    uci set firewall."${TARGET_INCLUDE}".path='/sharewifiupdate/wifidog_update/aw-fw-setup.sh'
    uci set firewall."${TARGET_INCLUDE}".type='script'
    uci set firewall."${TARGET_INCLUDE}".fw4_compatible='1'
}

lan_has_open_wifi() {
    LAN_IFACES=$(uci show wireless 2>/dev/null | awk -F'[.=]' '/=wifi-iface/{print $2}')
    for sec in $LAN_IFACES; do
        CUR_NET=$(uci -q get wireless."${sec}".network || echo "")
        case " $CUR_NET " in
            *" lan "*) ;;
            *) continue ;;
        esac
        CUR_DISABLED=$(uci -q get wireless."${sec}".disabled || echo "0")
        [ "$CUR_DISABLED" = "1" ] && continue
        CUR_ENCRYPTION=$(uci -q get wireless."${sec}".encryption || echo "")
        case "$CUR_ENCRYPTION" in
            ""|none) return 0 ;;
        esac
    done
    return 1
}

set_wifi_state() {
    TARGET_NETWORK="$1"
    DISABLED_VALUE="$2"
    TARGET_LABEL="$3"
    MATCHED=0
    CURRENT_IFACES=$(uci show wireless 2>/dev/null | awk -F'[.=]' '/=wifi-iface/{print $2}')
    for sec in $CURRENT_IFACES; do
        CUR_NET=$(uci -q get wireless."${sec}".network || echo "")
        case " $CUR_NET " in
            *" ${TARGET_NETWORK} "*) ;;
            *) continue ;;
        esac
        uci set wireless."${sec}".disabled="$DISABLED_VALUE"
        MATCHED=$((MATCHED + 1))
        echo "  已更新 wifi-iface: ${sec}"
    done

    if [ "$MATCHED" -eq 0 ]; then
        echo "错误：未找到 ${TARGET_LABEL} WiFi 接口。" >&2
        exit 1
    fi

    sync_aw_firewall_include
    commit_and_reload
}

modify_guest() {
    find_main_ifaces
    echo "[*] 修改 Guest SSID..."
    for sec in $MAIN_IFACES; do
        uci set wireless."${sec}".ssid="$NEW_SSID"
        echo "  已更新 wifi-iface: ${sec}"
    done
    sync_aw_firewall_include
    commit_and_reload
    echo "[*] Guest SSID 修改完成。"
}

sync_aw_firewall_include() {
    if lan_has_open_wifi; then
        ensure_aw_firewall_include
    else
        delete_aw_firewall_include
    fi
}

set_main_encrypted() {
    echo "[*] 设置加密主 WiFi..."
    for sec in $MAIN_IFACES; do
        uci set wireless."${sec}".mode='ap'
        uci set wireless."${sec}".disabled='0'
        uci set wireless."${sec}".ssid="$MAIN_SSID"
        # 统一使用 psk2，兼容目标设备的无线驱动。
        uci set wireless."${sec}".encryption='psk2'
        uci set wireless."${sec}".key="$MAIN_PASSWORD"
        echo "  已更新 wifi-iface: ${sec}"
    done
}

set_main_open() {
    echo "[*] 设置开放主 WiFi..."
    for sec in $MAIN_IFACES; do
        uci set wireless."${sec}".mode='ap'
        uci set wireless."${sec}".disabled='0'
        uci set wireless."${sec}".ssid="$MAIN_SSID"
        uci set wireless."${sec}".encryption='none'
        uci -q delete wireless."${sec}".key || true
        echo "  已更新 wifi-iface: ${sec}"
    done
}

radio_band() {
    RADIO_NAME="$1"
    RADIO_BAND=$(uci -q get wireless."${RADIO_NAME}".band || echo "")
    if [ -n "$RADIO_BAND" ]; then
        case "$RADIO_BAND" in
            2g|2) echo "2G" ;;
            5g|5) echo "5G" ;;
            *) echo "2G" ;;
        esac
        return
    fi

    RADIO_HWMODE=$(uci -q get wireless."${RADIO_NAME}".hwmode || echo "")
    case "$RADIO_HWMODE" in
        11a|11ac|11ax) echo "5G" ;;
        *) echo "2G" ;;
    esac
}

generate_unused_gateway() {
    ATTEMPT=0
    while [ "$ATTEMPT" -lt 100 ]; do
        RAND_DIGITS=$(tr -dc '0-9' < /dev/urandom | dd bs=1 count=4 2>/dev/null)
        [ -z "$RAND_DIGITS" ] && RAND_DIGITS="1234"
        CANDIDATE_OCTET=$(awk -v n="$RAND_DIGITS" 'BEGIN { print 10 + (n % 90) }')
        if ! uci show network 2>/dev/null | grep -Fq ".ipaddr='192.168.${CANDIDATE_OCTET}."; then
            echo "192.168.${CANDIDATE_OCTET}.1"
            return 0
        fi
        ATTEMPT=$((ATTEMPT + 1))
    done
    return 1
}

create_owner_wifi() {
    if [ -n "$OWNER_GATEWAY_REQUESTED" ]; then
        OWNER_GATEWAY="$OWNER_GATEWAY_REQUESTED"
    else
        OWNER_GATEWAY=$(generate_unused_gateway) || {
            echo "错误：无法找到未占用的 192.168.X.0/24 网段。" >&2
            exit 1
        }
    fi

    uci set network.owner_br=device
    uci set network.owner_br.type='bridge'
    uci set network.owner_br.name='br-owner'
    uci set network.owner=interface
    uci set network.owner.proto='static'
    uci set network.owner.device='br-owner'
    uci set network.owner.ipaddr="$OWNER_GATEWAY"
    uci set network.owner.netmask='255.255.255.0'

    OWNER_IDX=0
    OWNER_SSID_LIST=""
    FIRST_OWNER_PASS=""
    for radio in $RADIO_DEVS; do
        BAND=$(radio_band "$radio")
        RADIO_OWNER_SSID="$OWNER_SSID"
        RADIO_OWNER_PASS="$OWNER_PASSWORD"
        case "$BAND" in
            2G)
                [ -n "$OWNER_SSID_2G" ] && RADIO_OWNER_SSID="$OWNER_SSID_2G"
                [ -n "$OWNER_PASS_2G" ] && RADIO_OWNER_PASS="$OWNER_PASS_2G"
                ;;
            5G)
                [ -n "$OWNER_SSID_5G" ] && RADIO_OWNER_SSID="$OWNER_SSID_5G"
                [ -n "$OWNER_PASS_5G" ] && RADIO_OWNER_PASS="$OWNER_PASS_5G"
                ;;
        esac

        OWNER_IFNAME="wowner${OWNER_IDX}"
        OWNER_SECTION=$(uci add wireless wifi-iface)
        uci set wireless."${OWNER_SECTION}".device="$radio"
        uci set wireless."${OWNER_SECTION}".mode='ap'
        uci set wireless."${OWNER_SECTION}".network="$OWNER_IFACE_NAME"
        uci set wireless."${OWNER_SECTION}".ssid="$RADIO_OWNER_SSID"
        uci set wireless."${OWNER_SECTION}".disabled='0'
        uci set wireless."${OWNER_SECTION}".encryption='psk2'
        uci set wireless."${OWNER_SECTION}".key="$RADIO_OWNER_PASS"
        uci set wireless."${OWNER_SECTION}".ifname="$OWNER_IFNAME"
        uci add_list network.owner_br.ports="$OWNER_IFNAME"
        uci -q set wireless."${radio}".disabled='0' || true
        echo "  创建 Owner wifi-iface: ${OWNER_SECTION} (radio=${radio}, band=${BAND})"
        if [ "$OWNER_IDX" -eq 0 ]; then
            OWNER_SSID_LIST="$RADIO_OWNER_SSID"
            FIRST_OWNER_PASS="$RADIO_OWNER_PASS"
        else
            OWNER_SSID_LIST="${OWNER_SSID_LIST}\n${RADIO_OWNER_SSID}"
        fi
        OWNER_IDX=$((OWNER_IDX + 1))
    done

    uci set dhcp.owner=dhcp
    uci set dhcp.owner.interface='owner'
    uci set dhcp.owner.start='100'
    uci set dhcp.owner.limit='150'
    uci set dhcp.owner.leasetime='12h'

    uci set firewall.owner_zone=zone
    uci set firewall.owner_zone.name='owner'
    uci set firewall.owner_zone.input='ACCEPT'
    uci set firewall.owner_zone.output='ACCEPT'
    uci set firewall.owner_zone.forward='ACCEPT'
    uci add_list firewall.owner_zone.network='owner'
    uci set firewall.owner_forward=forwarding
    uci set firewall.owner_forward.src='owner'
    uci set firewall.owner_forward.dest='wan'

    printf 'SSID: %b\nPassword: %s\nGateway: %s\n' \
        "$OWNER_SSID_LIST" "$FIRST_OWNER_PASS" "$OWNER_GATEWAY" > "$OWNER_PWD_FILE"
    chmod 600 "$OWNER_PWD_FILE"

    echo "[*] Owner WiFi 已创建，网关 ${OWNER_GATEWAY}"
}

prepare_radios() {
    RADIO_DEVS=$(uci show wireless 2>/dev/null | awk -F'[.=]' '/=wifi-device/{print $2}')
    if [ -z "$RADIO_DEVS" ]; then
        echo "错误：未检测到任何无线物理设备，未修改任何配置。" >&2
        exit 1
    fi
}

generate_random_password() {
    GENERATED_PASS=$(tr -dc 'A-Za-z0-9' < /dev/urandom | dd bs=1 count=12 2>/dev/null)
    while [ "$(printf '%s' "$GENERATED_PASS" | wc -c)" -lt 12 ]; do
        EXTRA_PASS=$(tr -dc 'A-Za-z0-9' < /dev/urandom | dd bs=1 count=12 2>/dev/null)
        GENERATED_PASS="${GENERATED_PASS}${EXTRA_PASS}"
    done
    printf '%s' "$GENERATED_PASS" | cut -c1-12
}

owner_exists() {
    OWNER_IFACES=$(uci show wireless 2>/dev/null | awk -F'[.=]' '/=wifi-iface/{print $2}')
    for sec in $OWNER_IFACES; do
        CUR_NET=$(uci -q get wireless."${sec}".network || echo "")
        case " $CUR_NET " in
            *" ${OWNER_IFACE_NAME} "*) return 0 ;;
        esac
    done
    return 1
}

cleanup_legacy_admin() {
    delete_managed_wifi "$LEGACY_IFACE_NAME" "旧版 Admin"
    delete_managed_services "$LEGACY_IFACE_NAME"
    rm -f "$LEGACY_PWD_FILE"
}

write_owner_credentials_from_config() {
    OWNER_SSID_LIST=""
    FIRST_OWNER_PASS=""
    OWNER_IFACES=$(uci show wireless 2>/dev/null | awk -F'[.=]' '/=wifi-iface/{print $2}')
    for sec in $OWNER_IFACES; do
        CUR_NET=$(uci -q get wireless."${sec}".network || echo "")
        case " $CUR_NET " in
            *" ${OWNER_IFACE_NAME} "*) ;;
            *) continue ;;
        esac
        CURRENT_SSID=$(uci -q get wireless."${sec}".ssid || echo "")
        CURRENT_PASS=$(uci -q get wireless."${sec}".key || echo "")
        if [ -z "$OWNER_SSID_LIST" ]; then
            OWNER_SSID_LIST="$CURRENT_SSID"
            FIRST_OWNER_PASS="$CURRENT_PASS"
        else
            OWNER_SSID_LIST="${OWNER_SSID_LIST}\n${CURRENT_SSID}"
        fi
    done
    CURRENT_GATEWAY=$(uci -q get network.owner.ipaddr || echo "")
    printf 'SSID: %b\nPassword: %s\nGateway: %s\n' \
        "$OWNER_SSID_LIST" "$FIRST_OWNER_PASS" "$CURRENT_GATEWAY" > "$OWNER_PWD_FILE"
    chmod 600 "$OWNER_PWD_FILE"
}

set_auto_owner_defaults() {
    BR_LAN_MAC=$(cat /sys/class/net/br-lan/address 2>/dev/null || echo "")
    if [ -z "$BR_LAN_MAC" ]; then
        echo "错误：无法读取 br-lan MAC 地址。" >&2
        exit 1
    fi
    MAC_SUFFIX=$(printf '%s' "$BR_LAN_MAC" | tr -d ':' | grep -o '......$')
    OWNER_SSID="ShareWifi_${MAC_SUFFIX}_admin"
    OWNER_SSID_2G="ShareWifi_${MAC_SUFFIX}_admin_2G"
    OWNER_SSID_5G="ShareWifi_${MAC_SUFFIX}_admin_5G"
    OWNER_PASSWORD=$(generate_random_password)
}

auto_create_owner() {
    cleanup_legacy_admin
    if owner_exists; then
        sync_aw_firewall_include
        touch "$SETUP_DONE"
        commit_and_reload
        echo "检测到已存在 Owner WiFi；旧版 Admin 已清理，未重复创建。"
        return 0
    fi

    prepare_radios
    set_auto_owner_defaults
    delete_managed_wifi owner Owner
    delete_managed_services owner
    create_owner_wifi
    sync_aw_firewall_include
    touch "$SETUP_DONE"
    commit_and_reload
    echo "[*] 自动创建 Owner 完成。"
}

modify_owner() {
    cleanup_legacy_admin

    if ! owner_exists; then
        echo "未找到 Owner WiFi，将按本次参数创建。"
        prepare_radios
        set_auto_owner_defaults
        [ -n "$NEW_SSID" ] && OWNER_SSID="$NEW_SSID" && OWNER_SSID_2G="" && OWNER_SSID_5G=""
        [ -n "$NEW_SSID_2G" ] && OWNER_SSID_2G="$NEW_SSID_2G"
        [ -n "$NEW_SSID_5G" ] && OWNER_SSID_5G="$NEW_SSID_5G"
        [ -n "$NEW_PASSWORD" ] && OWNER_PASSWORD="$NEW_PASSWORD"
        [ -n "$NEW_PASS_2G" ] && OWNER_PASS_2G="$NEW_PASS_2G"
        [ -n "$NEW_PASS_5G" ] && OWNER_PASS_5G="$NEW_PASS_5G"
        OWNER_GATEWAY_REQUESTED="$NEW_GATEWAY"
        delete_managed_services owner
        create_owner_wifi
        sync_aw_firewall_include
        touch "$SETUP_DONE"
        commit_and_reload
        echo "[*] Owner 创建完成。"
        return 0
    fi

    OWNER_IFACES=$(uci show wireless 2>/dev/null | awk -F'[.=]' '/=wifi-iface/{print $2}')
    for sec in $OWNER_IFACES; do
        CUR_NET=$(uci -q get wireless."${sec}".network || echo "")
        case " $CUR_NET " in
            *" ${OWNER_IFACE_NAME} "*) ;;
            *) continue ;;
        esac
        RADIO=$(uci -q get wireless."${sec}".device || echo "")
        BAND=$(radio_band "$RADIO")
        TARGET_SSID="$NEW_SSID"
        TARGET_PASS="$NEW_PASSWORD"
        case "$BAND" in
            2G)
                [ -n "$NEW_SSID_2G" ] && TARGET_SSID="$NEW_SSID_2G"
                [ -n "$NEW_PASS_2G" ] && TARGET_PASS="$NEW_PASS_2G"
                ;;
            5G)
                [ -n "$NEW_SSID_5G" ] && TARGET_SSID="$NEW_SSID_5G"
                [ -n "$NEW_PASS_5G" ] && TARGET_PASS="$NEW_PASS_5G"
                ;;
        esac
        if [ -n "$TARGET_SSID" ]; then
            uci set wireless."${sec}".ssid="$TARGET_SSID"
            echo "  [${BAND}] SSID 已更新: ${TARGET_SSID}"
        fi
        if [ -n "$TARGET_PASS" ]; then
            uci set wireless."${sec}".encryption='psk2'
            uci set wireless."${sec}".key="$TARGET_PASS"
            echo "  [${BAND}] 密码已更新"
        fi
    done

    if [ -n "$NEW_GATEWAY" ]; then
        uci set network.owner.ipaddr="$NEW_GATEWAY"
        echo "  网关已更新: ${NEW_GATEWAY}"
    fi
    sync_aw_firewall_include
    write_owner_credentials_from_config
    commit_and_reload
    echo "[*] Owner 修改完成。"
}

teardown_secondary() {
    delete_managed_wifi owner Owner
    delete_managed_services owner
    delete_managed_wifi "$LEGACY_IFACE_NAME" "旧版 Admin"
    delete_managed_services "$LEGACY_IFACE_NAME"
    delete_managed_state_files
    sync_aw_firewall_include
    commit_and_reload
    echo "[*] Owner 和旧版 Admin 已清除。"
}

commit_and_reload() {
    uci commit wireless
    uci commit network
    uci commit dhcp
    uci commit firewall

    /etc/init.d/network reload 2>/dev/null || true
    /etc/init.d/dnsmasq reload 2>/dev/null || true
    /etc/init.d/firewall restart 2>/dev/null || true
    if ! wifi reload; then
        echo "错误：无线配置已写入，但 wifi reload 失败。" >&2
        echo "请运行 logread -e hostapd -e netifd 查看具体原因。" >&2
        exit 1
    fi
}

# 三个位置参数：开放主 SSID + 创建加密 Owner SSID。
if [ $# -eq 3 ]; then
    case "$1" in
        -*) ;;
        *)
            OPERATION="create_owner"
            MAIN_SSID="$1"
            OWNER_SSID="$2"
            OWNER_PASSWORD="$3"
            shift 3
            ;;
    esac
fi

# 两个位置参数：加密主 SSID + 删除副 WiFi。
if [ -z "$OPERATION" ] && [ $# -eq 2 ]; then
    case "$1" in
        -*) ;;
        *)
            OPERATION="delete_owner"
            MAIN_SSID="$1"
            MAIN_PASSWORD="$2"
            shift 2
            ;;
    esac
fi

while [ $# -gt 0 ]; do
    case "$1" in
        --guest-disable)
            request_operation "guest_disable"
            shift
            ;;
        --guest-enable)
            request_operation "guest_enable"
            shift
            ;;
        --guest-modify)
            request_operation "guest_modify"
            shift
            ;;
        --owner-disable)
            request_operation "owner_disable"
            shift
            ;;
        --owner-enable)
            request_operation "owner_enable"
            shift
            ;;
        --owner-modify|--modify|-m)
            request_operation "modify_owner"
            shift
            ;;
        --teardown|-r)
            request_operation "teardown"
            shift
            ;;
        --ssid)
            [ $# -ge 2 ] || { usage; exit 1; }
            MAIN_SSID="$2"
            NEW_SSID="$2"
            shift 2
            ;;
        --ssid2g)
            [ $# -ge 2 ] || { usage; exit 1; }
            NEW_SSID_2G="$2"
            shift 2
            ;;
        --ssid5g)
            [ $# -ge 2 ] || { usage; exit 1; }
            NEW_SSID_5G="$2"
            shift 2
            ;;
        --password|--pass)
            [ $# -ge 2 ] || { usage; exit 1; }
            MAIN_PASSWORD="$2"
            NEW_PASSWORD="$2"
            shift 2
            ;;
        --pass2g)
            [ $# -ge 2 ] || { usage; exit 1; }
            NEW_PASS_2G="$2"
            shift 2
            ;;
        --pass5g)
            [ $# -ge 2 ] || { usage; exit 1; }
            NEW_PASS_5G="$2"
            shift 2
            ;;
        --gateway)
            [ $# -ge 2 ] || { usage; exit 1; }
            NEW_GATEWAY="$2"
            shift 2
            ;;
        --help|-h)
            usage
            exit 0
            ;;
        *)
            echo "未知参数: $1" >&2
            usage
            exit 1
            ;;
    esac
done

if [ -n "$EXPLICIT_OPERATION" ]; then
    [ -z "$OPERATION" ] || { echo "错误：位置参数模式不能与操作参数同时使用。" >&2; exit 1; }
    OPERATION="$EXPLICIT_OPERATION"
elif [ -z "$OPERATION" ] && [ -n "$MAIN_SSID$MAIN_PASSWORD" ]; then
    OPERATION="delete_owner"
elif [ -z "$OPERATION" ]; then
    OPERATION="auto_owner"
fi

case "$OPERATION" in
    guest_disable)
        echo "[*] 关闭 Guest SSID..."
        set_wifi_state lan 1 Guest
        echo "[*] Guest SSID 已关闭。"
        ;;
    guest_enable)
        echo "[*] 开启 Guest SSID..."
        set_wifi_state lan 0 Guest
        echo "[*] Guest SSID 已开启。"
        ;;
    guest_modify)
        [ -n "$NEW_SSID" ] || { echo "错误：--guest-modify 必须指定 --ssid。" >&2; exit 1; }
        [ -z "$NEW_SSID_2G$NEW_SSID_5G$NEW_PASSWORD$NEW_PASS_2G$NEW_PASS_5G$NEW_GATEWAY" ] || {
            echo "错误：Guest 修改只支持 --ssid。" >&2
            exit 1
        }
        validate_ssid "$NEW_SSID" "Guest SSID"
        modify_guest
        ;;
    owner_disable)
        echo "[*] 关闭 Owner SSID..."
        set_wifi_state owner 1 Owner
        echo "[*] Owner SSID 已关闭。"
        ;;
    owner_enable)
        echo "[*] 开启 Owner SSID..."
        set_wifi_state owner 0 Owner
        echo "[*] Owner SSID 已开启。"
        ;;
    delete_owner)
        validate_ssid "$MAIN_SSID" "主 SSID"
        validate_password "$MAIN_PASSWORD" "主 SSID 密码"
        find_main_ifaces
        set_main_encrypted
        delete_managed_wifi owner Owner
        delete_managed_services owner
        delete_managed_wifi "$LEGACY_IFACE_NAME" "旧版 Admin"
        delete_managed_services "$LEGACY_IFACE_NAME"
        delete_managed_state_files
        sync_aw_firewall_include
        commit_and_reload
        echo "[*] 完成：主 SSID 已加密，副 WiFi 已删除。"
        ;;
    create_owner)
        validate_ssid "$MAIN_SSID" "主 SSID"
        validate_ssid "$OWNER_SSID" "Owner SSID"
        validate_password "$OWNER_PASSWORD" "Owner SSID 密码"
        prepare_radios
        find_main_ifaces
        set_main_open
        delete_managed_wifi owner Owner
        delete_managed_services owner
        cleanup_legacy_admin
        delete_managed_state_files
        create_owner_wifi
        sync_aw_firewall_include
        touch "$SETUP_DONE"
        commit_and_reload
        echo "[*] 完成：主 SSID 已开放，Owner 已创建。"
        ;;
    auto_owner)
        auto_create_owner
        ;;
    modify_owner)
        if [ -z "$NEW_SSID$NEW_SSID_2G$NEW_SSID_5G$NEW_PASSWORD$NEW_PASS_2G$NEW_PASS_5G$NEW_GATEWAY" ]; then
            echo "错误：--modify 未指定任何修改项。" >&2
            exit 1
        fi
        [ -z "$NEW_SSID" ] || validate_ssid "$NEW_SSID" "Owner SSID"
        [ -z "$NEW_SSID_2G" ] || validate_ssid "$NEW_SSID_2G" "2.4G Owner SSID"
        [ -z "$NEW_SSID_5G" ] || validate_ssid "$NEW_SSID_5G" "5G Owner SSID"
        [ -z "$NEW_PASSWORD" ] || validate_password "$NEW_PASSWORD" "Owner密码"
        [ -z "$NEW_PASS_2G" ] || validate_password "$NEW_PASS_2G" "2.4G Owner密码"
        [ -z "$NEW_PASS_5G" ] || validate_password "$NEW_PASS_5G" "5G Owner密码"
        modify_owner
        ;;
    teardown)
        teardown_secondary
        ;;
esac
