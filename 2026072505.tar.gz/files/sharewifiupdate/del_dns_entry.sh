#!/bin/sh

# 接收要删除的域名（如 .bilibili.com 或 baidu.com）
DOMAIN=$1

# 目标配置文件
DNSMASQ_CONF="/etc/dnsmasq.conf"

# 格式化域名：如果是裸域名则加前缀 .
if [ "$(echo "$DOMAIN" | grep -o "\." | wc -l)" -lt 2 ]; then
    DOMAIN=".$DOMAIN"
fi

# 删除配置文件中匹配的行
sed -i "/^address=\/$DOMAIN\/127.0.0.1$/d" "$DNSMASQ_CONF"

# 重启 dnsmasq 服务以生效
/etc/init.d/dnsmasq restart
