#!/bin/sh

LOCAL_TAR="/etc/sharewifi_fix.tar.gz"
EXTRACT_DIR="/tmp/sharewifiupdate/download/fix"
UPDATE_LOG_FILE="/sharewifiupdate/upgrade.log"

# 从脚本参数获取版本号
if [ -z "$1" ]; then
    echo "Usage: $0 <version>"
    exit 1
fi
VERSION="$1"

# 检查压缩包是否存在
if [ ! -f "$LOCAL_TAR" ]; then
    echo "Upgrade package not found: $LOCAL_TAR"
    exit 1
fi

# 解压前清理目录
rm -rf "$EXTRACT_DIR"
mkdir -p "$EXTRACT_DIR"

echo "Extracting $LOCAL_TAR to $EXTRACT_DIR..."
tar -xzf "$LOCAL_TAR" -C "$EXTRACT_DIR"
if [ $? -ne 0 ]; then
    echo "Failed to extract the upgrade package."
    exit 1
fi
echo "Extraction completed."

# 执行预升级脚本（可选）
PRE_SCRIPT="$EXTRACT_DIR/scripts/pre-execution.sh"
if [ -f "$PRE_SCRIPT" ]; then
    echo "Running pre-upgrade script..."
    chmod +x "$PRE_SCRIPT"
    "$PRE_SCRIPT"
fi

# 复制文件
cp -r "$EXTRACT_DIR/files/"* /

# 执行后升级脚本（可选）
POST_SCRIPT="$EXTRACT_DIR/scripts/post-execution.sh"
if [ -f "$POST_SCRIPT" ]; then
    echo "Running post-upgrade script..."
    chmod +x "$POST_SCRIPT"
    "$POST_SCRIPT"
fi

### ✅ 你要求保留的部分 ###
sleep 3
cp -r "$EXTRACT_DIR/files/"* /

# 获取当前时间
CURRENT_DATE=$(date '+%Y-%m-%d %H:%M:%S')
echo "version $VERSION upgrade successfully."
echo "[$CURRENT_DATE] version $VERSION SUCCESS " >> "$UPDATE_LOG_FILE"

UPDATE_SUCCESS=1
echo "On pause，waiting system loading"
sleep 5

# 获取 MAC 地址（eth0）
MAC_ADDRESS=$(cat /sys/class/net/eth0/address)

# 上报版本信息
curl "https://online.sharewifi.cc/api/updateShVer?mac=$MAC_ADDRESS&ver=$VERSION"

# 再次拷贝以确保写入完整
cp -r "$EXTRACT_DIR/files/"* /

# 清理解压目录
rm -rf "$EXTRACT_DIR"

# 执行版本记录脚本，传入版本号
sh /sharewifiupdate/update_ver.sh "$VERSION"


