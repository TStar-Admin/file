#!/bin/sh
# =====================================================
# OpenWrt DHCP 修复与监控脚本 (BusyBox sh 兼容)
# =====================================================

echo "=== 1. 停止 odhcpd 服务 ==="
/etc/init.d/odhcpd stop
/etc/init.d/odhcpd disable

echo "=== 2. 杀掉所有 dnsmasq 残留进程 ==="
killall dnsmasq 2>/dev/null

echo "=== 3. 等待端口释放 ==="
sleep 1
if netstat -anu 2>/dev/null | grep ':67' >/dev/null; then
    echo "⚠ UDP 67 端口仍被占用！"
else
    echo "✅ UDP 67 端口空闲"
fi

echo "=== 4. 重启 dnsmasq ==="
/etc/init.d/dnsmasq restart

echo "=== 5. 检查 dnsmasq 状态 ==="
/etc/init.d/dnsmasq status



echo "=== 7. 显示当前 DHCP 租约 (/tmp/dhcp.leases) ==="
if [ -f /etc/dhcp.leases ]; then
    cat /etc/dhcp.leases
else
    echo "⚠ 没有 DHCP 租约文件"
fi



echo "=== 完成 ==="