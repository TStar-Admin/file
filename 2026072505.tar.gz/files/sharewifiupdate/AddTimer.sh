#!/bin/sh
TASK_FILE="/sharewifiupdate/timer_tasks.txt"
LOCK_DIR="${TASK_FILE}.lock"

if [ $# -lt 2 ]; then
    echo "Usage: AddTimer <seconds_from_now> <command>"
    exit 1
fi

DELAY=$1
shift
CMD="$*"
CMD_BODY="$CMD"
EXEC_TIME=$(( $(date +%s) + DELAY ))

# 确保文件存在
[ -f "$TASK_FILE" ] || touch "$TASK_FILE"

while ! mkdir "$LOCK_DIR" 2>/dev/null; do
    sleep 1
done

cleanup() {
    [ -n "$TMP_FILE" ] && [ -f "$TMP_FILE" ] && rm -f "$TMP_FILE"
    rmdir "$LOCK_DIR" 2>/dev/null
}

trap cleanup EXIT INT TERM

TMP_FILE=$(mktemp "${TASK_FILE}.XXXXXX") || exit 1

# 只按命令本体去重，忽略时间字段，
# 注意：OpenWrt 使用 BusyBox awk，不支持 [[:space:]] 等 POSIX 字符类
awk -v cmd_body="$CMD_BODY" '
{
    # 跳过空行
    if ($0 ~ /^[ \t]*$/) { next }

    # 找到第一个 | 的位置
    idx = index($0, "|")
    if (idx == 0) { print; next }

    # 提取 | 前的时间戳部分，去掉空格后判断是否是纯数字
    ts_part = substr($0, 1, idx - 1)
    gsub(/[ \t]/, "", ts_part)
    if (ts_part !~ /^[0-9]+$/) { print; next }

    # 提取 | 后的命令本体，去掉尾部空格
    cmd_part = substr($0, idx + 1)
    sub(/[ \t]+$/, "", cmd_part)

    # 命令本体相同则跳过（去重）
    if (cmd_part == cmd_body) { next }

    print
}
' "$TASK_FILE" > "$TMP_FILE"

printf '%s|%s\n' "$EXEC_TIME" "$CMD" >> "$TMP_FILE"
mv "$TMP_FILE" "$TASK_FILE"
TMP_FILE=""

echo "Task added: will run at $(date -d @$EXEC_TIME) -> $CMD"
