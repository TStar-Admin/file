#!/bin/sh
#
# setup_sharewifi_admin.sh
# 创建 admin 网络（192.168.X.1/24，X 随机 10~99）+ DHCP + 独立防火墙区域
# 自动适配所有无线设备，SSID=ShareWifi_<br-lan MAC后6位>_admin_<2G/5G>
# 兼容 BusyBox ash，不依赖 od/hexdump
#
# 用法：
#   sh admin-ssid.sh                                      # 正常创建
#   sh admin-ssid.sh --teardown                           # 清除所有已创建的内容
#   sh admin-ssid.sh --modify [--ssid <名>] [--ssid2g <名>] [--ssid5g <名>]
#                              [--pass <密码>] [--pass2g <密码>] [--pass5g <密码>]
#                              [--gateway <IP>]
#

set -e

PWD_FILE="/etc/ShareWifi_admin_pwd.txt"
SETUP_DONE="/etc/admin-ssid-setup.done"
IFACE_NAME="admin"

# ---------- 参数解析 ----------
TEARDOWN_ONLY=0
MODIFY_ONLY=0
NEW_SSID=""
NEW_SSID_2G=""
NEW_SSID_5G=""
NEW_PASSWORD=""
NEW_PASS_2G=""
NEW_PASS_5G=""
NEW_GATEWAY=""

while [ $# -gt 0 ]; do
    case "$1" in
        --teardown|-r) TEARDOWN_ONLY=1 ;;
        --modify|-m)   MODIFY_ONLY=1 ;;
        --ssid)        NEW_SSID="$2"; shift ;;
        --ssid2g)      NEW_SSID_2G="$2"; shift ;;
        --ssid5g)      NEW_SSID_5G="$2"; shift ;;
        --pass)        NEW_PASSWORD="$2"; shift ;;
        --pass2g)      NEW_PASS_2G="$2"; shift ;;
        --pass5g)      NEW_PASS_5G="$2"; shift ;;
        --gateway)     NEW_GATEWAY="$2"; shift ;;
        *)             echo "未知参数: $1" >&2; exit 1 ;;
    esac
    shift
done

# ---------- 清除函数 ----------
teardown() {
    echo "[*] 开始清除 admin WiFi 相关配置..."

    # 1. 删除所有关联的 wifi-iface
    #    方式 A：按 SSID 模式匹配（ShareWifi_*_admin* / ShareWifi_admin）
    #    方式 B：按 network=admin 匹配（兜底，防止用户改名后漏删）
    EXISTING_IFACES=$(uci show wireless 2>/dev/null | awk -F'[.=]' '/=wifi-iface/{print $2}')
    for sec in $EXISTING_IFACES; do
        CUR_SSID=$(uci -q get wireless."${sec}".ssid || echo "")
        CUR_NET=$(uci -q get wireless."${sec}".network || echo "")
        SHOULD_DELETE=0
        case "$CUR_SSID" in
            ShareWifi_*_admin*|ShareWifi_admin) SHOULD_DELETE=1 ;;
        esac
        [ "$CUR_NET" = "$IFACE_NAME" ] && SHOULD_DELETE=1
        if [ "$SHOULD_DELETE" -eq 1 ]; then
            echo "  删除 wifi-iface: ${sec} (SSID=${CUR_SSID})"
            uci delete wireless."${sec}"
        fi
    done

    # 2. 删除 network 接口 & bridge 设备
    for net_sec in "${IFACE_NAME}" "${IFACE_NAME}_br"; do
        if uci -q get network."${net_sec}" >/dev/null 2>&1; then
            echo "  删除 network: ${net_sec}"
            uci delete network."${net_sec}"
        fi
    done

    # 3. 删除 DHCP
    if uci -q get dhcp."${IFACE_NAME}" >/dev/null 2>&1; then
        echo "  删除 dhcp: ${IFACE_NAME}"
        uci delete dhcp."${IFACE_NAME}"
    fi

    # 4. 删除防火墙 zone 和 forwarding（按 name=admin 查找）
    FW_ZONES=$(uci show firewall 2>/dev/null | awk -F'[.=]' '/=zone$/{print $2}')
    for z in $FW_ZONES; do
        ZNAME=$(uci -q get firewall."${z}".name || echo "")
        if [ "$ZNAME" = "$IFACE_NAME" ]; then
            echo "  删除 firewall zone: ${z}"
            uci delete firewall."${z}"
        fi
    done
    for z in $FW_ZONES; do
        ZNAME=$(uci -q get firewall."${z}".name || echo "")
        if [ "$ZNAME" = "lan" ]; then
            uci -q del_list firewall."${z}".network="${IFACE_NAME}" || true
        fi
    done
    FW_FWDS=$(uci show firewall 2>/dev/null | awk -F'[.=]' '/=forwarding$/{print $2}')
    for f in $FW_FWDS; do
        F_SRC=$(uci -q get firewall."${f}".src || echo "")
        [ "$F_SRC" = "$IFACE_NAME" ] && echo "  删除 firewall forwarding: ${f}" && uci delete firewall."${f}"
    done

    # 5. 删除持久化文件
    for f in "$PWD_FILE" "$SETUP_DONE"; do
        if [ -f "$f" ]; then
            echo "  删除文件: ${f}"
            rm -f "$f"
        fi
    done

    # 7. 提交并重载
    uci commit wireless 2>/dev/null || true
    uci commit network  2>/dev/null || true
    uci commit dhcp     2>/dev/null || true
    uci commit firewall 2>/dev/null || true

    /etc/init.d/network reload 2>/dev/null || true
    /etc/init.d/dnsmasq reload 2>/dev/null || true
    /etc/init.d/firewall reload 2>/dev/null || true
    wifi reload 2>/dev/null || true

    echo "[*] 清除完成。"
}

if [ "$TEARDOWN_ONLY" -eq 1 ]; then
    teardown
    exit 0
fi

# ---------- 辅助：根据 radio 判断频段 ----------
radio_band() {
    radio="$1"
    BAND=$(uci -q get wireless."${radio}".band)
    if [ -z "$BAND" ]; then
        HWMODE=$(uci -q get wireless."${radio}".hwmode)
        case "$HWMODE" in
            11g|11n) BAND="2G" ;;
            11a|11ac|11ax) BAND="5G" ;;
            *) BAND="2G" ;;
        esac
    else
        case "$BAND" in
            2g|2) BAND="2G" ;;
            5g|5) BAND="5G" ;;
            *) BAND="2G" ;;
        esac
    fi
    echo "$BAND"
}

# ---------- 修改函数 ----------
modify() {
    echo "[*] 开始修改 admin WiFi 配置..."

    # 找到所有 network=admin 的 wifi-iface，记录频段
    ADMIN_IFACES=""
    EXISTING_IFACES=$(uci show wireless 2>/dev/null | awk -F'[.=]' '/=wifi-iface/{print $2}')
    for sec in $EXISTING_IFACES; do
        CUR_NET=$(uci -q get wireless."${sec}".network || echo "")
        [ "$CUR_NET" = "$IFACE_NAME" ] && ADMIN_IFACES="${ADMIN_IFACES} ${sec}"
    done

    if [ -z "$ADMIN_IFACES" ]; then
        echo "错误：未找到 admin WiFi 接口，请先运行脚本创建。" >&2
        exit 1
    fi

    CHANGED=0

    # 修改 SSID 和密码（逐接口处理，支持按频段单独设置）
    for sec in $ADMIN_IFACES; do
        RADIO=$(uci -q get wireless."${sec}".device || echo "")
        BAND=$(radio_band "$RADIO")

        # 确定该频段的 SSID：频段专用 > 全局 > 不改
        TARGET_SSID=""
        case "$BAND" in
            2G) [ -n "$NEW_SSID_2G" ] && TARGET_SSID="$NEW_SSID_2G" ;;
            5G) [ -n "$NEW_SSID_5G" ] && TARGET_SSID="$NEW_SSID_5G" ;;
        esac
        [ -z "$TARGET_SSID" ] && [ -n "$NEW_SSID" ] && TARGET_SSID="$NEW_SSID"

        if [ -n "$TARGET_SSID" ]; then
            uci set wireless."${sec}".ssid="${TARGET_SSID}"
            echo "  [${BAND}] SSID 已更新: ${TARGET_SSID}"
            CHANGED=1
        fi

        # 确定该频段的密码：频段专用 > 全局 > 不改
        TARGET_PASS=""
        case "$BAND" in
            2G) [ -n "$NEW_PASS_2G" ] && TARGET_PASS="$NEW_PASS_2G" ;;
            5G) [ -n "$NEW_PASS_5G" ] && TARGET_PASS="$NEW_PASS_5G" ;;
        esac
        [ -z "$TARGET_PASS" ] && [ -n "$NEW_PASSWORD" ] && TARGET_PASS="$NEW_PASSWORD"

        if [ -n "$TARGET_PASS" ]; then
            uci set wireless."${sec}".key="${TARGET_PASS}"
            echo "  [${BAND}] 密码已更新"
            CHANGED=1
        fi
    done

    # 修改网关 IP
    if [ -n "$NEW_GATEWAY" ]; then
        uci set network."${IFACE_NAME}".ipaddr="${NEW_GATEWAY}"
        echo "  网关 IP 已更新: ${NEW_GATEWAY}"
        CHANGED=1
    fi

    if [ "$CHANGED" -eq 0 ]; then
        echo "未指定任何修改项 (--ssid / --ssid2g / --ssid5g / --pass / --pass2g / --pass5g / --gateway)" >&2
        exit 1
    fi

    uci commit wireless
    uci commit network

    # 重写密码文件
    SSID_LIST=""
    for sec in $ADMIN_IFACES; do
        S=$(uci -q get wireless."${sec}".ssid || echo "")
        if [ -z "$SSID_LIST" ]; then
            SSID_LIST="$S"
        else
            SSID_LIST="${SSID_LIST}\n${S}"
        fi
    done
    FIRST_SEC=$(echo "$ADMIN_IFACES" | awk '{print $1}')
    CUR_PASS=$(uci -q get wireless."${FIRST_SEC}".key || echo "")
    CUR_GW=$(uci -q get network."${IFACE_NAME}".ipaddr || echo "")

    printf 'SSID: %b\nPassword: %s\nGateway: %s\n' \
        "$SSID_LIST" "$CUR_PASS" "$CUR_GW" > "$PWD_FILE"
    chmod 600 "$PWD_FILE"
    echo "  密码文件已更新: ${PWD_FILE}"

    /etc/init.d/network reload 2>/dev/null || true
    /etc/init.d/dnsmasq reload 2>/dev/null || true
    wifi reload 2>/dev/null || true

    echo "[*] 修改完成。"
}

if [ "$MODIFY_ONLY" -eq 1 ]; then
    modify
    exit 0
fi

# ---------- 0. 防重复执行 ----------
if [ -f "$SETUP_DONE" ]; then
    echo "检测到已完成标记 (${SETUP_DONE})，脚本已执行过，跳过。" >&2
    exit 0
fi

EXISTING_ADMIN=$(uci show wireless 2>/dev/null | grep "ShareWifi_.*_admin_" | head -n1)
if [ -n "$EXISTING_ADMIN" ]; then
    echo "检测到已存在 admin WiFi 接口，脚本已执行过，跳过。" >&2
    exit 0
fi

# ---------- 1. 生成第三段 IP（10~99） ----------
# 不用 od：直接从 /dev/urandom 过滤出数字字符，取 4 位再模 90 加 10
RAND_DIGITS=$(tr -dc '0-9' < /dev/urandom | dd bs=1 count=4 2>/dev/null)
# 兜底：确保非空
[ -z "$RAND_DIGITS" ] && RAND_DIGITS=$(date +%N | tr -dc '0-9' | cut -c1-4)
[ -z "$RAND_DIGITS" ] && RAND_DIGITS="1234"
THIRD_OCTET=$(awk -v n="$RAND_DIGITS" 'BEGIN{print 10 + (n % 90)}')
GATEWAY_IP="192.168.${THIRD_OCTET}.1"
NETMASK="255.255.255.0"

# ---------- 2. 生成 12 位复杂密码 ----------
WIFI_PASS=$(tr -dc 'A-Za-z0-9' < /dev/urandom | dd bs=1 count=12 2>/dev/null)
while [ "$(printf '%s' "$WIFI_PASS" | wc -c)" -lt 12 ]; do
    EXTRA=$(tr -dc 'A-Za-z0-9' < /dev/urandom | dd bs=1 count=12 2>/dev/null)
    WIFI_PASS="${WIFI_PASS}${EXTRA}"
done
WIFI_PASS=$(printf '%s' "$WIFI_PASS" | cut -c1-12)

# ---------- 3. 从 br-lan MAC 后 6 位生成 SSID 前缀 ----------
BR_LAN_MAC=$(cat /sys/class/net/br-lan/address 2>/dev/null || echo "")
if [ -z "$BR_LAN_MAC" ]; then
    echo "错误：无法读取 br-lan 的 MAC 地址，脚本终止。" >&2
    exit 1
fi
MAC_SUFFIX=$(echo "$BR_LAN_MAC" | tr -d ':' | grep -o '......$')

# ---------- 4. 探测所有 wifi-device ----------
RADIO_DEVS=$(uci show wireless 2>/dev/null | grep '=wifi-device' | awk -F'[.=]' '{print $2}')
if [ -z "$RADIO_DEVS" ]; then
    echo "错误：未检测到任何无线物理设备 (wifi-device)，脚本终止。" >&2
    exit 1
fi

echo "检测到无线设备：${RADIO_DEVS}"
echo "管理网络网关 IP：${GATEWAY_IP}"

# ---------- 5. 创建 bridge 设备 + network.admin 接口 ----------
uci -q delete network.admin_br || true
uci set network.admin_br=device
uci set network.admin_br.type='bridge'
uci set network.admin_br.name='br-admin'

uci -q delete network."${IFACE_NAME}" || true
uci set network."${IFACE_NAME}"=interface
uci set network."${IFACE_NAME}".proto='static'
uci set network."${IFACE_NAME}".device='br-admin'
uci set network."${IFACE_NAME}".ipaddr="${GATEWAY_IP}"
uci set network."${IFACE_NAME}".netmask="${NETMASK}"

# ---------- 6. 清理旧 admin SSID ----------
EXISTING_IFACES=$(uci show wireless | awk -F'[.=]' '/=wifi-iface/{print $2}')
for sec in $EXISTING_IFACES; do
    CUR_SSID=$(uci -q get wireless."${sec}".ssid || echo "")
    case "$CUR_SSID" in
        ShareWifi_*_admin*|ShareWifi_admin)
            echo "清理旧 SSID：${CUR_SSID}"
            uci delete wireless."${sec}"
            ;;
    esac
done

# ---------- 7. 为每个 radio 创建对应频段的 wifi-iface ----------
WADMIN_IDX=0

for radio in $RADIO_DEVS; do
    BAND=$(radio_band "$radio")

    SSID_NAME="ShareWifi_${MAC_SUFFIX}_admin_${BAND}"
    echo "创建 ${BAND} 频段 SSID：${SSID_NAME}（设备：${radio}）"

    IFNAME="wadmin${WADMIN_IDX}"

    NEW_SECTION=$(uci add wireless wifi-iface)
    uci set wireless."${NEW_SECTION}".device="${radio}"
    uci set wireless."${NEW_SECTION}".mode='ap'
    uci set wireless."${NEW_SECTION}".network="${IFACE_NAME}"
    uci set wireless."${NEW_SECTION}".ssid="${SSID_NAME}"
    uci set wireless."${NEW_SECTION}".encryption='psk2'
    uci set wireless."${NEW_SECTION}".key="${WIFI_PASS}"
    uci set wireless."${NEW_SECTION}".ifname="${IFNAME}"

    uci -q set wireless."${radio}".disabled='0' || true

    # 将 ifname 加入 bridge 端口列表
    uci add_list network.admin_br.ports="${IFNAME}"

    # 记录 SSID（用于密码文件）
    if [ $WADMIN_IDX -eq 0 ]; then
        SSID_LIST="${SSID_NAME}"
    else
        SSID_LIST="${SSID_LIST}\n${SSID_NAME}"
    fi

    WADMIN_IDX=$((WADMIN_IDX + 1))
done

if [ "$WADMIN_IDX" -eq 0 ]; then
    echo "错误：未能为任何 radio 创建 wifi-iface，脚本终止。" >&2
    exit 1
fi

# ---------- 8. 配置 DHCP（让客户端自动拿 IP） ----------
uci -q delete dhcp."${IFACE_NAME}" || true
uci set dhcp."${IFACE_NAME}"=dhcp
uci set dhcp."${IFACE_NAME}".interface="${IFACE_NAME}"
uci set dhcp."${IFACE_NAME}".start='100'
uci set dhcp."${IFACE_NAME}".limit='150'
uci set dhcp."${IFACE_NAME}".leasetime='12h'

# ---------- 9. 创建独立 admin 防火墙区域（与 lan 隔离） ----------
# 9a. 清理：如果 admin 曾被加入 lan 区域，先移除（兼容旧脚本）
LAN_ZONE_SEC=""
FW_ZONES=$(uci show firewall | awk -F'[.=]' '/=zone$/{print $2}')
for z in $FW_ZONES; do
    ZNAME=$(uci -q get firewall."${z}".name || echo "")
    if [ "$ZNAME" = "lan" ]; then
        LAN_ZONE_SEC="$z"
        break
    fi
done
if [ -n "$LAN_ZONE_SEC" ]; then
    uci -q del_list firewall."${LAN_ZONE_SEC}".network="${IFACE_NAME}" || true
fi

# 9b. 删除旧 admin zone（幂等），重建
ADMIN_ZONE_SEC=""
for z in $(uci show firewall 2>/dev/null | awk -F'[.=]' '/=zone$/{print $2}'); do
    ZNAME=$(uci -q get firewall."${z}".name || echo "")
    if [ "$ZNAME" = "$IFACE_NAME" ]; then
        ADMIN_ZONE_SEC="$z"
        break
    fi
done
uci -q delete firewall."${IFACE_NAME}"_zone || true
[ -n "$ADMIN_ZONE_SEC" ] && uci -q delete firewall."${ADMIN_ZONE_SEC}" || true

uci set firewall."${IFACE_NAME}"_zone=zone
uci set firewall."${IFACE_NAME}"_zone.name="${IFACE_NAME}"
uci set firewall."${IFACE_NAME}"_zone.input='ACCEPT'
uci set firewall."${IFACE_NAME}"_zone.output='ACCEPT'
uci set firewall."${IFACE_NAME}"_zone.forward='ACCEPT'
uci add_list firewall."${IFACE_NAME}"_zone.network="${IFACE_NAME}"

# 9c. 允许 admin 访问外网
uci -q delete firewall."${IFACE_NAME}"_forward || true
uci set firewall."${IFACE_NAME}"_forward=forwarding
uci set firewall."${IFACE_NAME}"_forward.src="${IFACE_NAME}"
uci set firewall."${IFACE_NAME}"_forward.dest='wan'

echo "已创建独立防火墙区域：${IFACE_NAME}（与 lan 隔离，可访问外网）"

# ---------- 10. 提交所有配置 ----------
uci commit network
uci commit wireless
uci commit dhcp
uci commit firewall

# ---------- 11. 写入密码文件 ----------
printf 'SSID: %b\nPassword: %s\nGateway: %s\n' \
    "$SSID_LIST" "$WIFI_PASS" "$GATEWAY_IP" > "$PWD_FILE"
chmod 600 "$PWD_FILE"
echo "密码已写入：${PWD_FILE}"

# ---------- 12. 标记完成 ----------
touch "$SETUP_DONE"

# ---------- 13. 重载服务 ----------
/etc/init.d/network reload
/etc/init.d/dnsmasq reload 2>/dev/null || true
/etc/init.d/firewall reload 2>/dev/null || true
wifi reload

echo "完成：${WADMIN_IDX} 个 admin WiFi 已创建并绑定到 ${IFACE_NAME} (${GATEWAY_IP})。"
