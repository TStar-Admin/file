#!/bin/sh
set -e

DOMAIN="online.sharewifi.cc"
HOSTS_FILE="/etc/hosts"
RAW_URL="https://raw.githubusercontent.com/TStar-Admin/domain_check/refs/heads/main/adf32422055u"

echo "🌐 正在从 GitHub 获取 IP 列表..."
IP_LIST=$(wget -qO- "$RAW_URL")

if [ -z "$IP_LIST" ]; then
    echo "❌ 获取失败，IP 为空"
    exit 1
fi

echo "✅ 获取到以下 IP："
echo "$IP_LIST"

# 删除旧记录
sed -i "/$DOMAIN/d" "$HOSTS_FILE"

# 添加新记录
for ip in $IP_LIST; do
    echo "$ip $DOMAIN" >> "$HOSTS_FILE"
done

echo "📝 已写入 /etc/hosts"
/etc/init.d/dnsmasq restart
echo "🎉 完成！"

