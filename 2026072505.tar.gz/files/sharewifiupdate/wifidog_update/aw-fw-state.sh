#!/bin/sh
# ---------------------------------------------------------------------------
# aw-fw-state.sh
#
# Companion to aw-fw-setup.sh. Two jobs:
#
#   1. backup    On first run, snapshot the current nftables ruleset to a
#                file so it can be restored later. Subsequent runs are no-ops
#                unless -f is given (force re-snapshot).
#
#   2. apply     Run an nft command (or a file of nft commands), and on
#                success re-snapshot so the backup file stays in sync with
#                the live ruleset.
#
# This is the "one knob, two effects" interface: every change goes through
# `apply`, so the on-disk backup is always a faithful image of what's
# currently loaded. Restoring is just `nft -f <backup>`.
#
# Usage:
#   sh aw-fw-state.sh backup  [-f]                  # snapshot
#   sh aw-fw-state.sh apply   <nft args...>         # one-shot nft command
#   sh aw-fw-state.sh apply-f <file>                # batch from file
#   sh aw-fw-state.sh restore [-y]                  # nft -f backup
#   sh aw-fw-state.sh show                          # cat backup
#   sh aw-fw-state.sh diff                          # live vs. backup
#
# Examples:
#   sh aw-fw-state.sh backup
#   sh aw-fw-state.sh apply add element inet fw4 set_wifidogx_trust_clients_out '{ aa:bb:cc:dd:ee:ff }'
#   sh aw-fw-state.sh apply delete element inet fw4 set_wifidogx_gateway '{ 10.11.12.1 }'
#   sh aw-fw-state.sh apply-f /tmp/extra_rules.nft
#
# Environment:
#   AWFW_BACKUP   override backup path (default /etc/wifidogx/fw_backup.nft)
#
# POSIX shell — runs on BusyBox ash (OpenWrt).
# ---------------------------------------------------------------------------

set -u

BACKUP="${AWFW_BACKUP:-/etc/wifidogx/fw_backup.nft}"
BACKUP_DIR="$(dirname "$BACKUP")"

[ "$(id -u)" -eq 0 ] || { echo "must run as root" >&2; exit 1; }
command -v nft >/dev/null 2>&1 || { echo "nft not found" >&2; exit 1; }

mkdir -p "$BACKUP_DIR" 2>/dev/null || true

usage() {
    sed -n '2,38p' "$0"
    exit 1
}

# ---------------------------------------------------------------------------
# Snapshot the current ruleset atomically (write to .tmp, rename).
# Stable file is critical: a half-written backup is worse than no backup.
# ---------------------------------------------------------------------------
do_snapshot() {
    tmp="$BACKUP.tmp.$$"
    if ! nft -s list ruleset > "$tmp" 2>/dev/null; then
        # -s (stateless) drops counter values so noisy diffs don't churn the
        # file. Fall back to a plain dump if -s isn't supported on this nft.
        nft list ruleset > "$tmp" || {
            rm -f "$tmp"
            echo "snapshot failed" >&2
            return 1
        }
    fi
    # Add a header so humans know what they're looking at.
    {
        echo "# wifidogx firewall snapshot"
        echo "# generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
        echo "# host:      $(uname -n)"
        echo "#"
        cat "$tmp"
    } > "$tmp.hdr" && mv "$tmp.hdr" "$BACKUP"
    rm -f "$tmp"
    return 0
}

cmd_backup() {
    force=0
    [ "${1:-}" = "-f" ] && force=1

    if [ -f "$BACKUP" ] && [ "$force" -eq 0 ]; then
        echo "[*] backup exists at $BACKUP (use 'backup -f' to overwrite)"
        return 0
    fi

    echo "[*] snapshotting nftables ruleset -> $BACKUP"
    do_snapshot && echo "[*] backup ok ($(wc -l < "$BACKUP") lines)"
}

# ---------------------------------------------------------------------------
# Apply one nft command (its args are appended verbatim), then re-snapshot.
# If the live apply fails, the backup is left untouched.
# ---------------------------------------------------------------------------
cmd_apply() {
    [ "$#" -gt 0 ] || { echo "apply needs nft arguments" >&2; exit 1; }

    # Make sure we have a backup to update (first-run safety).
    if [ ! -f "$BACKUP" ]; then
        echo "[*] no backup yet, taking one first"
        do_snapshot || exit 1
    fi

    echo "[*] nft $*"
    if ! nft "$@"; then
        echo "[!] nft failed; backup unchanged" >&2
        exit 1
    fi

    echo "[*] re-syncing backup"
    do_snapshot
}

cmd_apply_f() {
    file="${1:-}"
    [ -n "$file" ] && [ -f "$file" ] || { echo "apply-f needs a readable file" >&2; exit 1; }

    if [ ! -f "$BACKUP" ]; then
        echo "[*] no backup yet, taking one first"
        do_snapshot || exit 1
    fi

    echo "[*] nft -f $file"
    if ! nft -f "$file"; then
        echo "[!] nft -f failed; backup unchanged" >&2
        exit 1
    fi

    echo "[*] re-syncing backup"
    do_snapshot
}

# ---------------------------------------------------------------------------
# Restore: flush + load the backup. Destructive — confirm unless -y.
# ---------------------------------------------------------------------------
cmd_restore() {
    [ -f "$BACKUP" ] || { echo "no backup at $BACKUP" >&2; exit 1; }

    yes=0
    [ "${1:-}" = "-y" ] && yes=1
    if [ "$yes" -eq 0 ]; then
        printf "this will flush the live ruleset and reload %s — continue? [y/N] " "$BACKUP"
        read -r ans
        case "$ans" in y|Y|yes) ;; *) echo "aborted"; exit 0 ;; esac
    fi

    echo "[*] flush ruleset"
    nft flush ruleset || { echo "flush failed" >&2; exit 1; }
    echo "[*] loading $BACKUP"
    nft -f "$BACKUP" || { echo "load failed" >&2; exit 1; }
    echo "[*] restored"
}

cmd_show() {
    [ -f "$BACKUP" ] || { echo "no backup at $BACKUP" >&2; exit 1; }
    cat "$BACKUP"
}

# Quick drift check between live and backup. Useful after manual nft edits
# to detect that someone bypassed `apply`.
cmd_diff() {
    [ -f "$BACKUP" ] || { echo "no backup at $BACKUP" >&2; exit 1; }
    tmp="/tmp/awfw-live.$$"
    nft -s list ruleset 2>/dev/null > "$tmp" || nft list ruleset > "$tmp"

    if command -v diff >/dev/null 2>&1; then
        # strip the header before diffing so the timestamp doesn't always show.
        diff -u \
            "$(grep -nv '^#' "$BACKUP" | head -n1 >/dev/null; echo "$BACKUP")" \
            "$tmp" \
          | sed '1,2d'  # drop the +++/--- header
    else
        echo "diff(1) not available; raw cmp:"
        cmp "$BACKUP" "$tmp" && echo "identical"
    fi
    rm -f "$tmp"
}

# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------
sub="${1:-}"
[ -n "$sub" ] || usage
shift

case "$sub" in
    backup)   cmd_backup   "$@" ;;
    apply)    cmd_apply    "$@" ;;
    apply-f)  cmd_apply_f  "$@" ;;
    restore)  cmd_restore  "$@" ;;
    show)     cmd_show     "$@" ;;
    diff)     cmd_diff     "$@" ;;
    -h|--help|help) usage ;;
    *) echo "unknown subcommand: $sub" >&2; usage ;;
esac
