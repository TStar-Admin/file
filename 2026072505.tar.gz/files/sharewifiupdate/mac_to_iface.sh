#!/bin/sh

# 默认检测的桥接接口，通常是 br-lan
BRIDGE="br-lan"

# 检查桥接接口是否存在
if [ ! -d "/sys/class/net/$BRIDGE" ]; then
    echo "错误: 找不到桥接接口 $BRIDGE"
    exit 1
fi

echo "正在扫描 $BRIDGE 上的设备对应接口..."
echo "-----------------------------------------------------"
printf "%-20s | %-10s | %s\n" "MAC Address" "Port ID" "Physical Interface"
echo "-----------------------------------------------------"

# 1. 抓取 brctl showmacs 结果
# 2. 过滤掉 is local? 为 yes 的本机接口 ($3 == "no")
# 3. 提取端口号 ($1) 和 MAC地址 ($2)
brctl showmacs "$BRIDGE" | awk '$3 == "no" {print $1, $2}' | while read port_dec mac_addr; do
    
    # 略过可能解析错误的空行
    [ -z "$port_dec" ] && continue

    # 将十进制端口号转换为十六进制 (因为 /sys/class/... 里的 port_no 是十六进制)
    port_hex=$(printf "0x%x" "$port_dec")
    iface_name="未知接口"

    # 遍历桥接目录下的所有物理接口
    for brif_dir in /sys/class/net/"$BRIDGE"/brif/*; do
        if [ -f "$brif_dir/port_no" ]; then
            current_port_hex=$(cat "$brif_dir/port_no")
            # 比对十六进制端口号
            if [ "$current_port_hex" = "$port_hex" ]; then
                iface_name=$(basename "$brif_dir")
                break
            fi
        fi
    done

    # 打印最终结果
    printf "%-20s | %-10s | %s\n" "$mac_addr" "$port_dec" "$iface_name"
done

echo "-----------------------------------------------------"
