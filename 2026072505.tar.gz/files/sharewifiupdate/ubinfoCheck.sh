#!/bin/bash

# 获取 Current maximum erase counter value
erase_counter=$(ubinfo -a| grep "Current maximum erase counter value" | awk -F': ' '{print $2}')



# 如果值大于30，则每隔60秒改变一次LED颜色
if [ "$erase_counter" -gt 30 ]; then
    echo "Erase counter is greater than 30. Starting LED color change loop."
    
    # 初始化颜色状态（假设有两个颜色，可以根据实际情况调整）
    color="0"  # 初始颜色
    
    while true; do
        # 根据颜色状态切换 LED
        if [ "$color" == "0" ]; then
           echo "1" > "/sys/class/leds/blue:net/brightness"
            echo "1" > "/sys/class/leds/blue:sys/brightness"
            echo "1" > "/sys/class/leds/yellow:net/brightness"
            echo "1" > "/sys/class/leds/yellow:net/brightness"
            color="1"  # 切换到下一颜色
        elif [ "$color" == "1" ]; then
           echo "0" > "/sys/class/leds/blue:net/brightness"
echo "0" > "/sys/class/leds/blue:sys/brightness"
echo "0" > "/sys/class/leds/yellow:net/brightness"
echo "0" > "/sys/class/leds/yellow:net/brightness"
            color="0"  # 切换到下一颜色
       
        fi
        
        # 等待60秒后改变颜色
        sleep 1
    done
else
    echo "1" > "/sys/class/leds/blue:net/brightness"
    echo "1" > "/sys/class/leds/blue:sys/brightness"
    echo "1" > "/sys/class/leds/yellow:net/brightness"
    echo "1" > "/sys/class/leds/yellow:net/brightness"
    echo "Erase counter is less than or equal to 30. No action taken."
fi
