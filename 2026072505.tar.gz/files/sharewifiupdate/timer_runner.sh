#!/bin/sh
TASK_FILE="/sharewifiupdate/timer_tasks.txt"
TMP_FILE="/sharewifiupdate/timer_tasks_tmp.txt"
NOW=$(date +%s)

# ��������ļ��������򴴽�
[ -f "$TASK_FILE" ] || touch "$TASK_FILE"

# �����ʱ�ļ�
> "$TMP_FILE"

while IFS='|' read -r timestamp cmd; do
    [ -z "$timestamp" ] && continue
    if [ "$timestamp" -le "$NOW" ]; then
        echo "[$(date)] Executing: $cmd"
        sh -c "$cmd" &
    else
        echo "$timestamp|$cmd" >> "$TMP_FILE"
    fi
done < "$TASK_FILE"

mv "$TMP_FILE" "$TASK_FILE"
