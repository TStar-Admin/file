#!/bin/sh

CMD="$*"

#       nft            ӳ  0-45s   ִ  
echo "$CMD" | grep -q "nft list set inet fw4 set_wifidogx_trust_clients_out"
if [ $? -eq 0 ]; then
    RAND_DELAY=$((RANDOM % 46))
    sleep "$RAND_DELAY"
fi

# ִ      
RESULT=$(eval "$CMD" 2>&1)

TARGET_URL="http://10.11.12.1/pages/portal_v3/portal_v3"

# 1. curl    
echo "$CMD" | grep -q "$TARGET_URL"
if [ $? -eq 0 ]; then
    echo "$RESULT" | grep -q "500 Internal Server Error"
    if [ $? -eq 0 ]; then
        echo "1"
    else
        echo "0"
    fi
    exit 0
fi

# 2. iw station dump            mac;iface;rx_bytes;tx_bytes;signal;signal_avg;connected_time  
#                =========;uptime
echo "$CMD" | grep -q "station dump"
if [ $? -eq 0 ]; then
    echo "$RESULT" | grep -q "command failed"
    if [ $? -eq 0 ]; then
        echo "$RESULT"
        exit 0
    fi

    UP_TIME=$(echo "$RESULT" | awk '
    BEGIN{after_sep=0}
    /^=========/{
        if (index($0, ";") > 0) { split($0,a,";"); print a[2]; exit }
        if (NF >= 2) { print $2; exit }
        after_sep=1; next
    }
    after_sep==1 && $0 ~ /^[0-9]+$/ { print $0; exit }
    ')

    echo "$RESULT" | awk '
    /^=========/ { next }

    $0 ~ /^[ \t]*Station[ \t]+/ {
        mac=$2
        iface=$4
        gsub(/[()]/, "", iface)
        rx=""; tx=""; sig=""; savg=""; ctime=""
        next
    }

    $0 ~ /^[ \t]*rx bytes:/ { rx=$3; next }
    $0 ~ /^[ \t]*tx bytes:/ { tx=$3; next }

    $0 ~ /^[ \t]*signal avg:/ { savg=$3; next }
    $0 ~ /^[ \t]*signal:/ { sig=$2; next }

    $0 ~ /^[ \t]*connected time:/ {
        ctime=$3
        if (mac != "") {
            printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\n", mac, iface, rx, tx, sig, savg, ctime
        }
        next
    }'

    echo "=========${UP_TIME}"
    exit 0
fi

# 3. ip neigh show 仅保留 REACHABLE/DELAY，再提取 ip 和 mac
CMD_TRIM=$(printf "%s" "$CMD" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
if [ "$CMD_TRIM" = "ip neigh show" ]; then
    FILTERED=$(echo "$RESULT" | grep -E "REACHABLE|DELAY")
    PARSED=$(echo "$FILTERED" | awk '
    {
        ip=$1
        mac=""
        for (i=1; i<=NF; i++) {
            if ($i == "lladdr") {
                mac=$(i+1)
                break
            }
        }
        if (ip ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ && mac ~ /^[0-9a-fA-F]{2}(:[0-9a-fA-F]{2}){5}$/) {
            printf "%s\t%s\n", ip, tolower(mac)
        }
    }')
    if [ -n "$PARSED" ]; then
        echo "$PARSED"
    fi
    exit 0
fi

# 3.1 兼容历史命令：ip neigh show | grep -E 'REACHABLE|DELAY'
echo "$CMD" | grep -q "ip neigh show"
if [ $? -eq 0 ]; then
    echo "$CMD" | grep -q "REACHABLE|DELAY"
    if [ $? -eq 0 ]; then
        PARSED=$(echo "$RESULT" | awk '
        {
            ip=$1
            mac=""
            for (i=1; i<=NF; i++) {
                if ($i == "lladdr") {
                    mac=$(i+1)
                    break
                }
            }
            if (ip ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ && mac ~ /^[0-9a-fA-F]{2}(:[0-9a-fA-F]{2}){5}$/) {
                printf "%s\t%s\n", ip, tolower(mac)
            }
        }')
        if [ -n "$PARSED" ]; then
            echo "$PARSED"
        fi
        exit 0
    fi
fi

# 4. nft     ɣ ֻҪ          set_wifidogx_trust_clients_out  ͽ     ֻ     mac;packets  
echo "$CMD" | grep -q "set_wifidogx_trust_clients_out"
if [ $? -eq 0 ]; then
    echo "$RESULT" | awk '
    {
        for (i=1; i<=NF; i++) {
            if (tolower($i) ~ /^[0-9a-f]{2}(:[0-9a-f]{2}){5}$/) {
                mac = tolower($i)
            }
            if ($i == "packets") {
                packets = $(i+1)
                gsub(/[^0-9]/, "", packets)
                if (mac != "" && packets != "") {
                    printf "%s\t%s\n", mac, packets
                    mac = ""
                    packets = ""
                }
            }
        }
    }'
    exit 0
fi

# 5. arp            name;ip;mac  
echo "$CMD" | grep -q "arp"
if [ $? -eq 0 ]; then
    PARSED=$(echo "$RESULT" | awk '
    {
        name=$1
        ip=$2
        mac=""

        gsub(/[()]/, "", ip)

        for (i=1; i<=NF; i++) {
            if (tolower($i) ~ /^[0-9a-f]{2}(:[0-9a-f]{2}){5}$/) {
                mac=tolower($i)
                break
            }
        }

        if (name == "?" || name == "") {
            name="'\'''\''"
        }

        if (ip ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ && mac != "") {
            printf "%s\t%s\t%s\n", name, ip, mac
        }
    }')

    if [ -n "$PARSED" ]; then
        echo "$PARSED"
    else
        echo "$RESULT"
    fi
    exit 0
fi

# 6. wdctlx status: 如果输出包含 apfree wifidog status 返回 0，否则返回 1
CMD_TRIM=$(printf "%s" "$CMD" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
if [ "$CMD_TRIM" = "wdctlx status" ]; then
    echo "$RESULT" | grep -q "apfree wifidog status"
    if [ $? -eq 0 ]; then
        echo "0"
    else
        echo "1"
    fi
    exit 0
fi

# 7. wdctlx show domain     
echo "$CMD" | grep -q "wdctlx show domain"
if [ $? -eq 0 ]; then
    echo "$RESULT" | awk '
    BEGIN { domain=""; has_ip=0 }

    /^Domain:/ {
        if (domain != "" && has_ip == 1) {
            printf "%s\t", domain
        }
        domain=$2
        has_ip=0
        next
    }

    /^[ \t]*[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/ { has_ip=1 }

    END {
        if (domain != "" && has_ip == 1) {
            printf "%s", domain
        }
    }'
    echo ""
    exit 0
fi

# 8.         
echo "$RESULT"
