#!/bin/sh
# OpenWrt script: check portal / wifidog and manage bypass rules
# Cron: */1 * * * * /usr/bin/check_portal.sh

LOG_TAG="check_portal"

WIFIDOG_OK=1
PORTAL_OK=1

# 1. 检查 wifidog 状态
# WDCTLX_OUTPUT=$(wdctlx status 2>&1)
# if ! echo "$WDCTLX_OUTPUT" | grep -q "apfree wifidog status"; then
#     logger -t "$LOG_TAG" "wifidog abnormal"
#     WIFIDOG_OK=0
# fi

# 2. 检查 portal.html 内容
PORTAL_FILE="/www/portal.html"
if [ -f "$PORTAL_FILE" ]; then
    CONTENT=$(cat "$PORTAL_FILE" 2>/dev/null)

    HAS_META=$(echo "$CONTENT" | grep -c 'pages/portal_v3/portal_v3')
    HAS_BUTTON=$(echo "$CONTENT" | grep -c 'http://10.11.12.1:30099/cgi-bin/wifi-diag')

    if [ "$HAS_META" -eq 0 ] || [ "$HAS_BUTTON" -eq 0 ]; then
        logger -t "$LOG_TAG" "portal.html missing content (meta=$HAS_META button=$HAS_BUTTON)"
        PORTAL_OK=0
    fi
else
    logger -t "$LOG_TAG" "portal.html not found"
    PORTAL_OK=0
fi

# 3. 根据状态增删规则
RULE_EXISTS=$(nft list set inet fw4 set_wifidogx_bypass_clients 2>/dev/null | grep -c '10.11.12.0/24')

if [ "$WIFIDOG_OK" -eq 1 ] && [ "$PORTAL_OK" -eq 1 ]; then
    # 一切正常，删除 bypass 规则
    if [ "$RULE_EXISTS" -gt 0 ]; then
        nft delete element inet fw4 set_wifidogx_bypass_clients '{ 10.11.12.0/24 }' 2>/dev/null
        if [ $? -eq 0 ]; then
            logger -t "$LOG_TAG" "all normal, bypass rule removed"
        else
            logger -t "$LOG_TAG" "failed to remove bypass rule"
        fi
    fi
else
    # 异常，添加 bypass 规则
    if [ "$RULE_EXISTS" -gt 0 ]; then
        logger -t "$LOG_TAG" "bypass rule already exists, skip"
    else
        nft add element inet fw4 set_wifidogx_bypass_clients '{ 10.11.12.0/24 }' 2>/dev/null
        if [ $? -eq 0 ]; then
            logger -t "$LOG_TAG" "bypass rule added: 10.11.12.0/24"
        else
            logger -t "$LOG_TAG" "failed to add bypass rule"
        fi
    fi
fi

exit 0
