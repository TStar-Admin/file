#!/bin/sh

# ================= 配置区域 =================
# 固定目标设备
MTD_DEV="mtd2"
MTD_BLOCK="/dev/${MTD_DEV}"

# 写入的固定偏移量 (0x0560 转换为十进制是 1376)
OFFSET=$((0x0560))

# 标准 MAC 地址字符串 (XX:XX:XX:XX:XX:XX) 占用 17 字节
ID_LEN=17
# ============================================

# 获取 mtd2 的真实分区名称 (用于 mtd write 命令)
PART_NAME=$(grep "^${MTD_DEV}:" /proc/mtd | cut -d'"' -f2)

if [ -z "$PART_NAME" ]; then
    echo "错误: 系统中不存在 $MTD_DEV 分区！"
    exit 1
fi

# 获取当前设备实际的 br-lan MAC 地址
CURRENT_MAC=$(cat /sys/class/net/br-lan/address 2>/dev/null)
if [ -z "$CURRENT_MAC" ]; then
    echo "错误: 无法获取 br-lan 的 MAC 地址！"
    exit 1
fi

echo "检测目标: $MTD_DEV (别名: $PART_NAME), 偏移量: $OFFSET (0x0560)"

# 检查当前闪存位置数据
HEX_DATA=$(dd if=$MTD_BLOCK bs=1 skip=$OFFSET count=$ID_LEN 2>/dev/null | hexdump -v -e '/1 "%02X"')
BLANK_HEX_FF=$(printf '%0.sF' $(seq 1 $((ID_LEN * 2))))
BLANK_HEX_00=$(printf '%0.s0' $(seq 1 $((ID_LEN * 2))))

# ================= 场景1：该位置已有数据 =================
if [ "$HEX_DATA" != "$BLANK_HEX_FF" ] && [ "$HEX_DATA" != "$BLANK_HEX_00" ]; then
    EXISTING_MAC=$(dd if=$MTD_BLOCK bs=1 skip=$OFFSET count=$ID_LEN 2>/dev/null)
    
    echo "=================================================="
    echo "检测到该位置已有数据！保持闪存原样。"
    echo "闪存中读取到的数据为: $EXISTING_MAC"
    
    # 验证读取到的数据是否是合法 MAC 地址格式
    if echo "$EXISTING_MAC" | grep -qE '^([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}$'; then
        echo "格式校验通过。"

        # 比较闪存 MAC 与当前 br-lan MAC，相同则跳过
        if [ "$EXISTING_MAC" = "$CURRENT_MAC" ]; then
            echo "闪存 MAC 与当前 br-lan MAC 一致 ($CURRENT_MAC)，无需替换。"
            echo "=================================================="
            exit 0
        fi

        echo "闪存 MAC ($EXISTING_MAC) 与当前 br-lan MAC ($CURRENT_MAC) 不一致，开始替换..."
        
        # 1. 适配新版 DSA 架构：查找并修改底层 device 区块的 MAC
        # 自动抓取包含 name='br-lan' 的 device 编号 (例如 @device[0])
        DEVICE_SECTION=$(uci show network | grep -E "name='br-lan'|name=\"br-lan\"" | cut -d'.' -f2 | head -n 1)
        
        if [ -n "$DEVICE_SECTION" ]; then
            echo "检测到新版 device 架构，更新区块: $DEVICE_SECTION"
            uci set network."$DEVICE_SECTION".macaddr="$EXISTING_MAC"
        fi
        
        # 2. 兼容老版本架构：修改 interface 区块的 MAC
        uci set network.lan.macaddr="$EXISTING_MAC"
        
        # 3. 提交所有 uci 更改
        uci commit network
        
        # 4. 直接重启网络服务，让配置文件全面生效
        echo "正在重启网络服务应用新配置..."
        /etc/init.d/network restart
        /etc/init.d/start_mqtt_client stop
        /etc/init.d/start_mqtt_client start
        echo "操作完成！本机的 br-lan MAC 已成功变更为: $EXISTING_MAC"
    else
        echo "警告: 闪存中读取到的数据不是合法的 MAC 地址格式！"
        echo "为保护系统网络不崩溃，跳过 MAC 替换操作。"
    fi
    echo "=================================================="
    exit 0
fi

# ================= 场景2：该位置为空 =================
echo "指定位置状态为空 (全0或全F)，准备将当前 br-lan 的 MAC ($CURRENT_MAC) 写入闪存..."

TMP_FILE="/tmp/${MTD_DEV}_backup.bin"

echo "1. 正在将 $MTD_DEV 完整备份到内存 ($TMP_FILE) ..."
dd if=$MTD_BLOCK of=$TMP_FILE 2>/dev/null

echo "2. 正在内存中替换 0x0560 处的数据..."
# 将当前的 br-lan MAC 写入备份文件对应偏移处
echo -n "$CURRENT_MAC" | dd of=$TMP_FILE bs=1 seek=$OFFSET count=$ID_LEN conv=notrunc 2>/dev/null

echo "3. 准备写入闪存..."
# 尝试解除系统级别的写保护 (如果安装了 kmod-mtd-rw)
if [ -e /lib/modules/*/mtd-rw.ko ]; then
    insmod mtd-rw i_want_a_brick=1 2>/dev/null
fi

echo "正在执行 mtd write ..."
mtd write $TMP_FILE "$PART_NAME"

if [ $? -eq 0 ]; then
    echo "=================================================="
    echo "写入成功！正在校验..."
    VERIFY=$(dd if=$MTD_BLOCK bs=1 skip=$OFFSET count=$ID_LEN 2>/dev/null)
    if [ "$VERIFY" = "$CURRENT_MAC" ]; then
        echo "校验通过！已成功将 br-lan MAC 写入闪存: $VERIFY"
    else
        echo "校验失败！读取到的数据为: $VERIFY"
    fi
    echo "=================================================="
else
    echo "=================================================="
    echo "写入失败！你的固件对 $MTD_DEV 开启了底层写保护。"
    echo "请执行以下命令安装解锁插件后再次运行本脚本："
    echo "  opkg update"
    echo "  opkg install kmod-mtd-rw"
    echo "  insmod mtd-rw i_want_a_brick=1"
    echo "=================================================="
fi

# 清理临时文件
rm -f $TMP_FILE
echo "完成。"

# 日后可以单独用以下命令验证写入的数据，注意 count 修改为了 17
# dd if=/dev/mtd2 bs=1 skip=1376 count=17 2>/dev/null; echo