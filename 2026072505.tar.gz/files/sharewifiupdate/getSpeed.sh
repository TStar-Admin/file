#!/bin/sh

iface="wan"
interval=60

#while true; do
  rx1=$(grep "$iface" /proc/net/dev | awk '{print $2}')
  tx1=$(grep "$iface" /proc/net/dev | awk '{print $10}')
  sleep $interval
  rx2=$(grep "$iface" /proc/net/dev | awk '{print $2}')
  tx2=$(grep "$iface" /proc/net/dev | awk '{print $10}')

  rx_rate=$(( (rx2 - rx1) * 8 / 1000000 / 60 )) # ......... Mbps
  tx_rate=$(( (tx2 - tx1) * 8 / 1000000 / 60 ))

  echo "Download: $rx_rate Mbps | Upload: $tx_rate Mbps"
