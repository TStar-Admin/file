#!/bin/bash

WATCHDOG_FILE="/tmp/apfree/mqtt-watchdog"
LED_CONTROL="/sys/class/leds/yellow:net/brightness"

while true; do
    CURRENT_TIME=$(date +%s)

    if [ -f "$WATCHDOG_FILE" ]; then
        WATCHDOG_TIME=$(cat "$WATCHDOG_FILE" | tr -d '[:space:]')
    else
        WATCHDOG_TIME=0
    fi

    if [ -n "$WATCHDOG_TIME" ] && [ "$WATCHDOG_TIME" -eq "$WATCHDOG_TIME" ] 2>/dev/null && [ "$WATCHDOG_TIME" -lt "$CURRENT_TIME" ]; then
        echo "1" > "$LED_CONTROL"
        sleep 1
        echo "0" > "$LED_CONTROL"
      
    else
        echo "0" > "$LED_CONTROL"
    fi

    sleep 1
done
