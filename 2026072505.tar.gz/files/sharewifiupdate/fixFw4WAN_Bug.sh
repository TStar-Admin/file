nft flush chain inet fw4 output_wan
nft add rule inet fw4  output_wan counter accept