#!/bin/sh

CONFIG="/etc/config/mqtt_config"
STATE_FILE="/tmp/mqtt/mqtt_state"
HEARTBEAT_FILE="/tmp/apfree/mqtt-watchdog"

MQTT_SERVERS="8.212.166.134 mq.hirechat.net"
MQTT_PORTS="1883 8181 8081 80"

NOW=$(date +%s)
YEAR2026=1767225600   # 2026-01-01 00:00:00

echo "[MQTT] check start"

# ---------------------------
# 确保目录存在
# ---------------------------
mkdir -p /tmp/mqtt
mkdir -p /tmp/apfree

# ---------------------------
# 1. 读取心跳时间
# ---------------------------
if [ -f "$HEARTBEAT_FILE" ]; then
    HB_TIME=$(date -r "$HEARTBEAT_FILE" +%s 2>/dev/null || echo 0)
else
    HB_TIME=0
fi

if [ -z "$HB_TIME" ]; then
    HB_TIME=0
fi

AGE=$((NOW - HB_TIME))

echo "[DEBUG] NOW       = $NOW ($(date -d @$NOW 2>/dev/null || date -r $NOW))"
echo "[DEBUG] HB_TIME   = $HB_TIME ($(date -d @$HB_TIME 2>/dev/null || date -r $HB_TIME))"
echo "[DEBUG] AGE       = $AGE seconds"




# ---------------------------
# 最强硬重启逻辑.机器运行60分钟，mqtt失联10分钟，强制重启。
# ---------------------------
UPTIME_SEC=$(cut -d. -f1 /proc/uptime)
HB_MOD_TIME=0
if [ -f "$HEARTBEAT_FILE" ]; then
    HB_MOD_TIME=$(date -r "$HEARTBEAT_FILE" +%s 2>/dev/null || echo 0)
fi
HB_AGE=$((NOW - HB_MOD_TIME))

if [ "$UPTIME_SEC" -gt 3600 ] && [ "$HB_AGE" -gt 600 ]; then
    echo "[MQTT] Heartbeat stale ($HB_AGE sec) and uptime $UPTIME_SEC sec > 20min, hard rebooting system!"
    
    # 打开 sysrq 功能
    echo 1 > /proc/sys/kernel/sysrq 2>/dev/null
    
    # 强制立即重启，不等待任何进程
    echo b > /proc/sysrq-trigger
    
    # 如果 sysrq 不可用，再用 fallback
    /sbin/reboot -f 2>/dev/null
fi






# ---------------------------
# 2. 判断是否需要切换
# ---------------------------
NEED_SWITCH=0
if [ "$NOW" -lt "$YEAR2026" ]; then
    echo "[MQTT] system time invalid (<2026), switch"
    NEED_SWITCH=1
elif [ "$AGE" -gt 180 ]; then
    echo "[MQTT] heartbeat timeout ($AGE sec), switch"
    NEED_SWITCH=1
else
    echo "[MQTT] MQTT healthy, no switch"
    exit 0
fi

# ---------------------------
# 3. 读取当前 index，确保是数字
# ---------------------------
if [ -f "$STATE_FILE" ]; then
    read IDX < "$STATE_FILE"
    # 检查是否是数字
    case "$IDX" in
        ''|*[!0-9]*)
            echo "[DEBUG] Invalid IDX content, resetting to 0"
            IDX=0
            ;;
    esac
else
    IDX=0
fi

echo "[DEBUG] Current IDX = $IDX"

# ---------------------------
# 4. 计算下一个 server/port
# ---------------------------
set -- $MQTT_SERVERS
SERVER_COUNT=$#

set -- $MQTT_PORTS
PORT_COUNT=$#

IDX=$((IDX + 1))

SERVER_IDX=$((IDX % SERVER_COUNT))
PORT_IDX=$((IDX % PORT_COUNT))

echo "[DEBUG] SERVER_IDX = $SERVER_IDX, PORT_IDX = $PORT_IDX"

# ---------------------------
# 5. 获取对应值
# ---------------------------
i=0
for s in $MQTT_SERVERS; do
    if [ "$i" -eq "$SERVER_IDX" ]; then
        SERVER="$s"
    fi
    i=$((i+1))
done

i=0
for p in $MQTT_PORTS; do
    if [ "$i" -eq "$PORT_IDX" ]; then
        PORT="$p"
    fi
    i=$((i+1))
done

echo "[DEBUG] Switching to SERVER:PORT = $SERVER:$PORT"

# ---------------------------
# 6. 修改 config（兼容 busybox sed）
# ---------------------------
sed -i "s/option host .*/option host '$SERVER'/" "$CONFIG"
sed -i "s/option port .*/option port '$PORT'/" "$CONFIG"

# ---------------------------
# 7. 保存 index
# ---------------------------
echo "$IDX" > "$STATE_FILE"

# ---------------------------
# 8. 重启 MQTT
# ---------------------------
/etc/init.d/start_mqtt_client restart

# ---------------------------
# 9. 发送 heartbeat
# ---------------------------
sendMQTTHeartbeat() {
    MAC_ADDRESS=$(cat /sys/class/net/br-lan/address)
    UPTIME_SEC=$(cut -d. -f1 /proc/uptime)
    TOPIC="r/s/$MAC_ADDRESS/h"
    PAYLOAD=$(printf "%s\t%s:%s" "$UPTIME_SEC" "$SERVER" "$PORT")
    mqtt_send "$TOPIC" "$PAYLOAD"
    echo "MQTT heartbeat sent to topic: $TOPIC"
}  

sleep 5
sendMQTTHeartbeat

echo "[MQTT] done"