#!/bin/sh

# 精确MAC地址限速脚本
# 用法:
# 设置MAC限速:        ./limit_bandwidth.sh AA:BB:CC:DD:EE:FF 5
# 设置多个MAC限速:    ./limit_bandwidth.sh AA:BB:CC:DD:EE:FF 5 XX:YY:ZZ:AA:BB:CC 10
# 清除MAC限速:        ./limit_bandwidth.sh AA:BB:CC:DD:EE:FF 0
# 网段限速:           ./limit_bandwidth.sh subnet 10.11.12.0/24 50
# 清除网段限速:       ./limit_bandwidth.sh subnet 10.11.12.0/24 0
# 清除所有限速:       ./limit_bandwidth.sh clearall

IFACE="br-lan"

if [ -z "$1" ]; then
  echo "用法: $0 <MAC> <限速Mbps> [<MAC2> <限速Mbps2> ...]"
  echo "       $0 subnet <网段/CIDR> <限速Mbps>"
  echo "       $0 clearall"
  echo ""
  echo "示例: $0 AA:BB:CC:DD:EE:FF 5"
  echo "       $0 AA:BB:CC:DD:EE:FF 5 XX:YY:ZZ:11:22:33 10"
  echo "       $0 subnet 10.11.12.0/24 50"
  echo "       $0 clearall"
  exit 1
fi

if [ "$1" = "clearall" ]; then
  tc qdisc del dev $IFACE root 2>/dev/null
  tc qdisc del dev $IFACE ingress 2>/dev/null
  tc qdisc del dev ifb0 root 2>/dev/null
  ip link set dev ifb0 down 2>/dev/null
  echo "✅ 已清除所有限速规则"
  exit 0
fi

init_root() {
  if ! tc qdisc show dev $IFACE | grep -q "htb 1:"; then
    echo "[INFO] 初始化root qdisc"
    tc qdisc add dev $IFACE root handle 1: htb default 30
    tc class add dev $IFACE parent 1: classid 1:1 htb rate 1000Mbps ceil 1000Mbps
  fi
}

apply_subnet() {
  SUBNET="$1"
  SPEED="$2"
  LIMIT_KBIT=$(( (SPEED+0) * 1000 ))

  NETWORK="${SUBNET%/*}"
  THIRD_OCTET=$(echo "$NETWORK" | awk -F. '{print $3}')

  if [ -z "$THIRD_OCTET" ] || [ "$THIRD_OCTET" -lt 1 ] 2>/dev/null; then
    echo "❌ 网段格式错误: $SUBNET，示例: 10.11.12.0/24"
    return 1
  fi

  CLASSID="1:$((500 + THIRD_OCTET))"
  PRIO="$((300 + THIRD_OCTET))"

  echo "[INFO] 网段 $SUBNET → classid=$CLASSID"

  tc filter del dev $IFACE parent 1: protocol ip prio $PRIO >/dev/null 2>&1
  tc qdisc del dev $IFACE parent $CLASSID >/dev/null 2>&1
  tc class del dev $IFACE classid $CLASSID >/dev/null 2>&1

  if [ "$SPEED" -gt 0 ]; then
    tc class add dev $IFACE parent 1:1 classid $CLASSID htb rate ${LIMIT_KBIT}kbit ceil ${LIMIT_KBIT}kbit burst 15k cburst 15k
    tc filter add dev $IFACE parent 1: protocol ip prio $PRIO u32 match ip dst $SUBNET flowid $CLASSID
    tc qdisc add dev $IFACE parent $CLASSID fq_codel
    echo "✅ 网段 $SUBNET 限速 ${SPEED}Mbps"
  else
    echo "✅ 已清除网段 $SUBNET 的限速规则"
  fi
}

apply_limit() {
  MAC="$1"
  SPEED="$2"
  LIMIT_KBIT=$(( (SPEED+0) * 1000 ))

  IP=$(arp -an | grep -i "$MAC" \
    | awk '{gsub("[()]", "", $2); ip=$2; split(ip, a, "."); if (a[1]=="10" && a[2]=="11" && a[3]>=12 && a[3]<=15) print ip}' \
    | head -n1)

  if [ -z "$IP" ]; then
    echo "❌ 找不到MAC=$MAC对应的10.11.12.1 → 10.11.15.254 IP，请确保该设备在该网段在线"
    return 1
  fi

  IP_SUFFIX=$(echo "$IP" | awk -F. '{print $4}')
  case "$IP_SUFFIX" in
    ''|*[!0-9]*) IP_SUFFIX=0 ;;
  esac

  CLASSID="1:$((100 + IP_SUFFIX))"
  FILTER_PRIO="$IP_SUFFIX"

  echo "[INFO] MAC=$MAC → IP=$IP → classid=$CLASSID"

  tc filter del dev $IFACE parent 1: protocol ip prio $FILTER_PRIO u32 match ip dst $IP flowid $CLASSID >/dev/null 2>&1
  tc qdisc del dev $IFACE parent $CLASSID >/dev/null 2>&1

  if ! tc filter show dev $IFACE parent 1: | grep -q "flowid $CLASSID"; then
    tc class del dev $IFACE classid $CLASSID >/dev/null 2>&1
  fi

  if [ "$SPEED" -gt 0 ]; then
    if tc class show dev $IFACE | grep -q "class htb $CLASSID "; then
      tc class change dev $IFACE parent 1:1 classid $CLASSID htb rate ${LIMIT_KBIT}kbit ceil ${LIMIT_KBIT}kbit burst 15k cburst 15k
    else
      tc class add dev $IFACE parent 1:1 classid $CLASSID htb rate ${LIMIT_KBIT}kbit ceil ${LIMIT_KBIT}kbit burst 15k cburst 15k
    fi

    tc filter add dev $IFACE parent 1: protocol ip prio $FILTER_PRIO u32 match ip dst $IP flowid $CLASSID
    tc qdisc add dev $IFACE parent $CLASSID fq_codel

    echo "✅ MAC=$MAC 限速 ${SPEED}Mbps"
  else
    echo "✅ 已清除 MAC=$MAC 的限速规则"
  fi
}

##############################
## 主入口
##############################
init_root

if [ "$1" = "subnet" ]; then
  if [ -z "$2" ] || [ -z "$3" ]; then
    echo "用法: $0 subnet <网段/CIDR> <限速Mbps>"
    exit 1
  fi
  apply_subnet "$2" "$3"
  echo ""
  tc class show dev $IFACE
  tc filter show dev $IFACE
  tc qdisc show dev $IFACE | grep -v "clsact"
  exit 0
fi

if [ $(( $# % 2 )) -ne 0 ]; then
  echo "❌ 参数必须成对出现"
  exit 1
fi

while [ $# -ge 2 ]; do
  apply_limit "$1" "$2" || HAS_ERROR=1
  shift 2
done

echo ""
echo "[DEBUG] 当前限速设置:"
tc class show dev $IFACE
tc filter show dev $IFACE
tc qdisc show dev $IFACE | grep -v "clsact"

exit $HAS_ERROR
