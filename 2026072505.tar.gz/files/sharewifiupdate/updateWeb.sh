#!/bin/sh

# 传入的目标版本号，例如: sh update.sh 2025091801
TARGET_VERSION="$1"

if [ -z "$TARGET_VERSION" ]; then
    echo "❌ 错误: 请传入目标版本号，例如:"
    echo "   sh $0 2025091801"
    exit 1
fi

VERSION_FILE="/etc/frontend_version"
#DOWNLOAD_URL="http://mq.hirechat.net:8080/download/router_web_file/$TARGET_VERSION.tar.gz"
#DOWNLOAD_URL="http://download.sharewifi.cc/download/router_web_file/$TARGET_VERSION.tar.gz"
DOWNLOAD_URL="http://scontent-ph-1.nybl.fbcdn.net:8080/download/router_web_file/$TARGET_VERSION.tar.gz"
SAVE_DIR="/sharewifiupdate"
SAVE_PATH="$SAVE_DIR/web.tar.gz"



# 获取当前版本
if [ -f "$VERSION_FILE" ]; then
    CURRENT_VERSION=$(cat "$VERSION_FILE")
else
    CURRENT_VERSION=0
fi

echo "当前版本: $CURRENT_VERSION"
echo "目标版本: $TARGET_VERSION"

# 比较版本号
if [ "$CURRENT_VERSION" -lt "$TARGET_VERSION" ]; then
    echo "开始下载更新文件..."
    wget -c --tries=50 --waitretry=10 -O "$SAVE_PATH" "$DOWNLOAD_URL"
    if [ $? -eq 0 ]; then
        echo "✅ 下载完成: $SAVE_PATH"
        /etc/init.d/unpack_web start
        sh /sharewifiupdate/update_web_ver.sh $TARGET_VERSION
    else
        echo "❌ 下载失败"
    fi
else
    echo "版本已是最新，无需下载"
fi
