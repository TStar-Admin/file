#!/bin/sh
echo "当前限速设备："
tc filter show dev br-lan parent 1:0 protocol ip | grep "match" | while read line; do
  HEX=$(echo "$line" | grep -o 'match [0-9a-f]\+' | awk '{print $2}')
  IP=$(printf "%d.%d.%d.%d\n" 0x${HEX:0:2} 0x${HEX:2:2} 0x${HEX:4:2} 0x${HEX:6:2})
  CLASSID=$(echo "$line" | grep -o 'flowid [^ ]*' | awk '{print $2}')
  echo "IP: $IP, CLASSID: $CLASSID"
done

