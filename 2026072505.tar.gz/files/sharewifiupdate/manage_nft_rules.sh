﻿#!/bin/sh

# 管理wifidogx可信客户端脚本
# 用法: 
#   添加设备: ./manage_trust.sh auth <MAC地址> <过期时间(秒)>
#   删除设备: ./manage_trust.sh del <MAC地址>
#   查看设备: ./manage_trust.sh list

# 参数检查
if [ $# -lt 2 ]; then
    echo "用法:"
    echo "  添加设备: $0 auth <MAC地址> <过期时间(秒)>"
    echo "  删除设备: $0 del <MAC地址>"
    echo "  查看设备: $0 list"
    echo ""
    echo "示例:"
    echo "  $0 auth 5e:cf:a9:4c:a9:07 3600    # 添加设备，1小时后过期"
    echo "  $0 auth c8:5a:cf:a5:af:f5 86400   # 添加设备，1天后过期"
    echo "  $0 del 5e:cf:a9:4c:a9:07          # 删除设备"
    echo "  $0 list                            # 查看可信设备"
    exit 1
fi

ACTION=$1
MAC_ADDR=$(echo "$2" | tr '[:upper:]' '[:lower:]')
TABLE_NAME="inet fw4"
SET_NAME="set_wifidogx_trust_clients_out"

# 查找nft命令路径
NFT_CMD=""
for cmd in nft /usr/sbin/nft /sbin/nft; do
    if [ -f "$cmd" ] && [ -x "$cmd" ]; then
        NFT_CMD="$cmd"
        break
    fi
done

if [ -z "$NFT_CMD" ]; then
    echo "错误：未找到nft命令"
    echo "请安装: opkg update && opkg install nftables"
    exit 1
fi

# 验证MAC地址格式（支持大小写）
validate_mac() {
    echo "$1" | grep -Eiq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$'
    return $?
}

# 将秒数转换为nftables的timeout格式
convert_seconds_to_nft_time() {
    local seconds=$1
    local days=$((seconds / 86400))
    local remaining=$((seconds % 86400))
    local hours=$((remaining / 3600))
    remaining=$((remaining % 3600))
    local minutes=$((remaining / 60))
    local secs=$((remaining % 60))
    
    local result=""
    [ $days -gt 0 ] && result="${result}${days}d"
    [ $hours -gt 0 ] && result="${result}${hours}h"
    [ $minutes -gt 0 ] && result="${result}${minutes}m"
    [ $secs -gt 0 ] && result="${result}${secs}s"
    
    # 如果结果为空，使用秒数
    [ -z "$result" ] && result="${seconds}s"
    
    echo "$result"
}

# 添加设备
add_device() {
    local mac=$1
    local seconds=$2
    
    # 验证MAC地址
    if ! validate_mac "$mac"; then
        echo "错误：MAC地址格式不正确"
        echo "正确格式示例: c8:5a:cf:a5:af:f5"
        return 1
    fi
    
    # 验证过期时间
    if ! echo "$seconds" | grep -Eq '^[0-9]+$' || [ "$seconds" -le 0 ]; then
        echo "错误：过期时间必须是正整数（秒）"
        echo "示例: 3600 (1小时), 86400 (1天)"
        return 1
    fi
    
    # 转换时间格式
    local nft_timeout=$(convert_seconds_to_nft_time $seconds)
    
    echo "========================"
    echo "操作: 添加设备"
    echo "MAC地址: $mac"
    echo "过期时间: $seconds 秒 ($nft_timeout)"
    echo "========================"
    
    # 检查集合是否存在
    if ! $NFT_CMD list set $TABLE_NAME $SET_NAME >/dev/null 2>&1; then
        echo "错误：集合 $TABLE_NAME $SET_NAME 不存在"
        return 1
    fi
    
    # 构建并执行添加命令
    local add_cmd="$NFT_CMD add element $TABLE_NAME $SET_NAME { $mac counter packets 0 bytes 0 timeout $nft_timeout }"
    
    echo "执行命令: $add_cmd"
    echo ""
    
    # 执行nft添加命令
    local nft_result=0
    if $add_cmd; then
        echo "[OK] 设备 $mac 添加成功"
        echo ""
        # 显示刚添加的设备
        echo "验证添加结果:"
        $NFT_CMD list set $TABLE_NAME $SET_NAME | grep -i "$mac"
    else
        echo "[FAIL] 设备添加失败"
        echo ""
        echo "可能的原因:"
        echo "1. MAC地址已存在且未过期"
        echo "2. 权限不足（需要root权限）"
        echo "3. 语法错误"
        nft_result=1
    fi
    
    # 执行额外的认证脚本 (对应 ClientController.php 1291-1292) - 无论nft命令是否成功都执行
    echo ""
    echo "执行用户认证脚本..."
    local auth_msg='{"user":[{"serial":"AS310","time":"'$seconds'","mac":"'$mac'","nat":0}]}'
    wdctlx apfree user_auth "$auth_msg" && echo "user_mac:$mac" && rm -f /etc/bypass_user_list.json
    if [ $? -eq 0 ]; then
        echo "[OK] 用户认证脚本执行成功"
    else
        echo "[WARN] 用户认证脚本执行失败或部分失败"
    fi
    
    return $nft_result
}

# 删除设备
del_device() {
    local mac=$1
    
    # 验证MAC地址
    if ! validate_mac "$mac"; then
        echo "错误：MAC地址格式不正确"
        echo "正确格式示例: c8:5a:cf:a5:af:f5"
        return 1
    fi
    
    echo "========================"
    echo "操作: 删除设备"
    echo "MAC地址: $mac"
    echo "========================"
    
    # 检查设备是否存在（仅用于提示，不影响后续执行）
    local device_exists=0
    if $NFT_CMD list set $TABLE_NAME $SET_NAME | grep -qi "$mac"; then
        device_exists=1
    else
        echo "警告：设备 $mac 不在集合中"
        echo ""
        echo "当前集合中的设备:"
        $NFT_CMD list set $TABLE_NAME $SET_NAME | grep -E "([0-9a-f]{2}:){5}[0-9a-f]{2}" || echo "  无"
        echo ""
    fi
    
    # 执行踢用户下线脚本 (对应 ClientController.php 1219-1220) - 无论设备是否存在都执行
    echo "执行踢用户下线脚本..."
    if [ -f "/sharewifiupdate/kickOffline.sh" ]; then
        sh /sharewifiupdate/kickOffline.sh "$mac"
        if [ $? -eq 0 ]; then
            echo "[OK] 踢用户下线脚本执行成功"
        else
            echo "[WARN] 踢用户下线脚本执行失败"
        fi
    else
        echo "[WARN] 踢用户下线脚本不存在: /sharewifiupdate/kickOffline.sh"
    fi
    echo ""
    
    # 构建并执行删除命令 - 无论设备是否存在都执行
    local del_cmd="$NFT_CMD delete element $TABLE_NAME $SET_NAME { $mac }"
    
    echo "执行命令: $del_cmd"
    echo ""
    
    local del_result=0
    if $del_cmd; then
        echo "[OK] 设备 $mac 删除成功"
    else
        echo "[FAIL] 设备删除失败"
        echo ""
        echo "可能的原因:"
        echo "1. 权限不足（需要root权限）"
        echo "2. 设备不存在"
        del_result=1
    fi
    
    return $del_result
}

# 列出可信设备
list_devices() {
    echo "========================"
    echo "可信客户端列表"
    echo "========================"
    
    if ! $NFT_CMD list set $TABLE_NAME $SET_NAME >/dev/null 2>&1; then
        echo "错误：集合 $TABLE_NAME $SET_NAME 不存在"
        return 1
    fi
    
    local devices=$($NFT_CMD list set $TABLE_NAME $SET_NAME | grep -E "([0-9a-f]{2}:){5}[0-9a-f]{2}")
    
    if [ -z "$devices" ]; then
        echo "当前没有可信设备"
    else
        echo "$devices" | while read -r line; do
            # 提取MAC地址
            mac=$(echo "$line" | grep -oE '([0-9a-f]{2}:){5}[0-9a-f]{2}')
            # 提取timeout信息
            timeout=$(echo "$line" | grep -oE 'timeout [0-9]+[smhd]' | awk '{print $2}')
            # 提取expires信息
            expires=$(echo "$line" | grep -oE 'expires [0-9]+[smhd]+[0-9]*[smhd]*[0-9]*ms?' | sed 's/expires //')
            
            if [ -n "$mac" ]; then
                echo "  $mac"
                [ -n "$timeout" ] && echo "    超时: $timeout"
                [ -n "$expires" ] && echo "    剩余: $expires"
            fi
        done
    fi
    
    echo ""
    echo "总计设备数: $(echo "$devices" | grep -cE '([0-9a-f]{2}:){5}[0-9a-f]{2}')"
    return 0
}

# 主逻辑
case $ACTION in
    auth)
        if [ $# -ne 3 ]; then
            echo "使用auth命令需要MAC地址和过期时间"
            echo "用法: $0 auth <MAC地址> <过期时间(秒)>"
            exit 1
        fi
        add_device "$MAC_ADDR" "$3"
        ;;
    del)
        if [ $# -ne 2 ]; then
            echo "使用del命令需要MAC地址"
            echo "用法: $0 del <MAC地址>"
            exit 1
        fi
        del_device "$MAC_ADDR"
        ;;
    list)
        list_devices
        ;;
    *)
        echo "未知命令 '$ACTION'"
        echo "支持的命令: auth, del, list"
        echo ""
        echo "用法:"
        echo "  添加设备: $0 auth <MAC地址> <过期时间(秒)>"
        echo "  删除设备: $0 del <MAC地址>"
        echo "  查看设备: $0 list"
        exit 1
        ;;
esac

exit $?
