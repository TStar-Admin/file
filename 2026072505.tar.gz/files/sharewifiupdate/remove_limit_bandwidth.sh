#!/bin/sh

MAC="$1"
IFACE="br-lan"  # 根据你实际情况改成 eth0 或 wlan0

if [ -z "$MAC" ]; then
  echo "❌ 用法: ./remove_limit_by_mac.sh AA:BB:CC:DD:EE:FF"
  exit 1
fi

# 获取 IP
IP=$(ip neigh | grep -i "$MAC" | awk '{print $1}')

if [ -z "$IP" ]; then
  echo "❌ 找不到 MAC=$MAC 对应的 IP，确保设备在线"
  exit 1
fi

echo "🔍 MAC=$MAC → IP=$IP"

# 根据你的添加逻辑，classid 是由 IP 最后一个字段组成，例如 192.168.1.101 → classid 1:201
IP_SUFFIX=$(echo "$IP" | awk -F. '{print $4}')
CLASSID="1:$((100 + IP_SUFFIX))"

echo "🧹 清除 classid: $CLASSID"

tc filter delete dev $IFACE parent 1:0 protocol ip prio 1 u32 match ip dst $IP flowid $CLASSID
tc class delete dev $IFACE classid $CLASSID

echo "✅ 限速规则清除完毕（MAC: $MAC，IP: $IP）"


