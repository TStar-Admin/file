#!/bin/sh

MAC_ADDRESS=$(cat /sys/class/net/eth0/address)  

if [ -z "$MAC_ADDRESS" ]; then
    echo "Unable to get the MAC address."
    exit 1
fi


API_URL="https://online.sharewifi.cc/api/batchAuth?mac=$MAC_ADDRESS"


curl "$API_URL"


echo "GET request sent successfully with MAC address: $MAC_ADDRESS"
