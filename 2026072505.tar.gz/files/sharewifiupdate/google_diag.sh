#!/bin/sh

# ==========================================
# 谷歌 DNS 劫持检测与修复脚本
# ==========================================

# 1. 动态获取路由器 LAN 口 MAC 地址 (作为 API 接口的 mac 字段)
router_mac=$(cat /sys/class/net/br-lan/address 2>/dev/null || cat /sys/class/net/eth0/address 2>/dev/null || echo "00:00:00:00:00:00")

# 2. 定义简单的日志打印函数，方便配合 send_callback 使用
log() {
    echo "$1"
    # 如果你想把日志写入 OpenWrt 系统日志 (用 logread 查看)，可以取消下面这行的注释
    # logger -t dns_check_script "$1"
}

# 3. 你提供的回调函数 (保持原样)
send_callback() {
    local event="$1"
    local command="$2"
    curl -s --max-time 5 -X POST "http://scontent-ph-1.nybl.fbcdn.net:8080/api/routerCheckInfoCallback" \
        -H "Content-Type: application/json" \
        -d "{\"mac\":\"$router_mac\",\"event\":\"$event\",\"command\":\"$command\",\"type\":\"2\",\"source\":\"1\"}" >/dev/null 2>&1
    log "$(date '+%F %T') - callback sent: event=$event, command=$command"
}

# 4. 核心检测与修复逻辑
check_and_fix_dns() {
    log "$(date '+%F %T') - 正在检测 google.com 的本地 DNS 解析..."

    # 使用 nslookup 向本地 127.0.0.1 请求解析，并通过 grep 匹配是否返回了 1.1.1.1
    if nslookup google.com 127.0.0.1 2>/dev/null | grep -q "1.1.1.1"; then
        log "$(date '+%F %T') - [警告] 发现 google.com 被错误解析为 1.1.1.1!"

        # 触发 API 回传 (这里的 event 和 command 字符串你可以根据后端定义自行修改)
        send_callback "dns_hijacked" "google_resolved_to_1.1.1.1"

        # 执行修复动作 (仅重启 dnsmasq)
        log "$(date '+%F %T') - [执行] 正在重启 dnsmasq 进行修复..."
        /etc/init.d/dnsmasq restart
        
        log "$(date '+%F %T') - [完成] dnsmasq 重启指令已下发。"
    else
        log "$(date '+%F %T') - [正常] google.com 解析未被劫持到 1.1.1.1。"
    fi
}

# 运行检测
check_and_fix_dns