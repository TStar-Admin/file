#!/bin/sh

# 脚本：set_version.sh
# 作用：将输入参数写入 /etc/sh_version

# 检查是否传入参数
if [ -z "$1" ]; then
    echo "用法: $0 <版本号>"
    exit 1
fi

VERSION="$1"
TARGET_FILE="/etc/sh_version"

# 检查写权限
if [ ! -w "$TARGET_FILE" ] && [ ! -w "$(dirname "$TARGET_FILE")" ]; then
    echo "错误：没有权限写入 $TARGET_FILE"
    exit 2
fi

# 写入版本号
echo "$VERSION" > "$TARGET_FILE"

# 提示成功
echo "版本号已写入：$TARGET_FILE"
