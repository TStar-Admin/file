#!/bin/sh



# 获取第一次采样数据
read cpu user nice system idle iowait irq softirq steal guest < /proc/stat
total1=$((user + nice + system + idle + iowait + irq + softirq + steal))
idle1=$idle

# 等待一段时间
sleep 1

# 获取第二次采样数据
read cpu user nice system idle iowait irq softirq steal guest < /proc/stat
total2=$((user + nice + system + idle + iowait + irq + softirq + steal))
idle2=$idle

# 计算差值
total_diff=$((total2 - total1))
idle_diff=$((idle2 - idle1))

# 计算CPU使用率
if [ "$total_diff" -ne 0 ]; then
  usage=$(( (100 * (total_diff - idle_diff)) / total_diff ))
else
  usage=0
fi

echo "CPU Usage: $usage%"

