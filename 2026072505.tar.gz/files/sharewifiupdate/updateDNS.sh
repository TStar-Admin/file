#!/bin/bash

# 步骤 1: 删除旧的DNS解析记录
echo "Deleting old DNS record for Localrouter.sharewifi.cc and crmeb.sharewifi.cc..."
uci delete dhcp.@domain[0]  # 假设`Localrouter.sharewifi.cc`是第一个记录，可以根据需要修改
uci delete dhcp.@domain[1]  # 假设`crmeb.sharewifi.cc`是第二个记录，可以根据需要修改

# 步骤 2: 获取LAN口的IP地址
LAN_IP=$(uci get network.lan.ipaddr)

# 步骤 3: 更新DNS解析记录
echo "Adding new DNS record for Localrouter.sharewifi.cc with IP: $LAN_IP"
uci add dhcp domain
uci set dhcp.@domain[-1].name="Localrouter.sharewifi.cc"
uci set dhcp.@domain[-1].ip=$LAN_IP

echo "Adding new DNS record for crmeb.sharewifi.cc with IP: $LAN_IP"
uci add dhcp domain
uci set dhcp.@domain[-1].name="crmeb.sharewifi.cc"
uci set dhcp.@domain[-1].ip=$LAN_IP

uci commit dhcp

# 步骤 4: 重启DNSMasq服务
echo "Restarting DNSMasq service..."
/etc/init.d/dnsmasq restart

# 完成
echo "DNS records for Localrouter.sharewifi.cc and crmeb.sharewifi.cc have been updated successfully!"
