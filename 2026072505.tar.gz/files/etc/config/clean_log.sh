#!/bin/ash
rm -f /root/log/messages
sync

