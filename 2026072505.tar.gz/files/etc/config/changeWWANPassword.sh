#!/bin/sh

# Check if the first parameter (password) is provided
if [ -z "$1" ]; then
    echo "Error: No password provided. Please provide a password as the first argument."
    exit 1
fi

# Define the file path and password
FILE_PATH="/etc/config/wifi_config"
PASSWORD="$1"
# 记录密码是否更新
PASSWORD_UPDATED=0
MAC_ADDRESS=$(cat /sys/class/net/eth0/address)

# Check if the file exists
if [ ! -f "$FILE_PATH" ]; then
    # File does not exist, create it and set the password
    cat <<EOF >"$FILE_PATH"
config wifi_config
    option password '$PASSWORD'
EOF
    echo "File created and password set."
    PASSWORD_UPDATED=1
else
    # File exists, use UCI to set the password
    uci set wifi_config.@wifi_config[0].password="$PASSWORD"
    uci commit wifi_config
    echo "Password set using UCI."
    PASSWORD_UPDATED=1
fi


