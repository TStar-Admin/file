#!/bin/bash



SSID_NAME="$1"      

uci set wireless.default_radio0.ssid="$SSID_NAME"
uci set wireless.radio0.bss_transition='1'  
uci set wireless.radio0.legacy_rates='0'
uci set wireless.radio0.ieee80211k='1'
uci set wireless.radio0.ieee80211v='1'
uci set wireless.radio0.uapsd='0'

uci set wireless.default_radio1.ssid="$SSID_NAME"
uci set wireless.radio1.bss_transition='1'
uci set wireless.radio1.ieee80211k='1'
uci set wireless.radio1.ieee80211v='1'
uci set wireless.radio1.uapsd='0'



# 保存配置
uci commit wireless

# 重新加载 Wi-Fi
echo "重新启动 Wi-Fi..."
wifi reload