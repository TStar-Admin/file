#!/bin/sh
opkg remove apfree-wifidog --force-removal-of-dependent-packages